# Reglas obligatorias del agente local y del puente WhatsApp (modo humano)

Estas reglas aplican a cualquier agente (Codex, opencode, Claude u otro) y a cualquier persona que cambie
`packages/local-agent`. No son sugerencias: un cambio que las debilite se rechaza, aunque mejore métricas.
Solo Pedro puede cambiarlas, y por escrito.

## 1. Ritmo humano (anti-baneo)
- Los valores de `src/vendor/pymeagents/human/profiles.cjs` para WhatsApp son el mínimo: 60 s entre envíos,
  máx. 10 por hora, máx. 30 por día, franja activa 08:00–21:00 hora local, máx. 900 caracteres y 1 enlace por mensaje.
  Se pueden endurecer; nunca aflojar.
- Escritura como persona (`typing.cjs`): pausa de lectura antes de escribir, velocidad por carácter variable,
  pausas en comas y puntos, mensajes largos partidos en párrafos con pausas aleatorias. Nada de pegar texto de golpe.
- Calentamiento (`warmup.cjs`) antes de enviar, y tiempos aleatorios entre vueltas del puente. Nada de intervalos fijos.
- Un mismo texto no se envía más de 3 veces al día (`pacing.cjs`). Varía el texto.
- No se usan atajos que eviten el ritmo: ni envíos en bloque, ni reintentos en ráfaga, ni abrir muchos chats a la vez
  (máx. 12 por vuelta).

## 2. Solo responder, nunca iniciar
- El puente responde únicamente a quien escribió primero o a quien el servidor autorizó (`hasPriorChat`, consentimiento).
- Toda respuesta pasa por aprobación humana en el operador (`ENVIO`). No hay envío automático.
- BAJA saca al contacto de inmediato; ALTA lo reactiva. Nunca se escribe a quien pidió BAJA.

## 3. Privacidad
- Un chat se abre solo si está en permitidos, ya fue autorizado, o su vista previa menciona AutoMant o un código AMP-.
  Los chats personales, de familia y grupos no se abren, no se leen y no se envían a ningún modelo.
- Números y nombres no salen del equipo salvo el número y el texto de chats que pasaron el filtro, hacia el servidor.
  Los nombres nunca salen. Los registros muestran números enmascarados (`masked()`).
- `data/` (sesión de WhatsApp, estado, permitidos, evaluaciones) nunca va a Git ni al ZIP. Archivos con permiso 0600.
- Las pruebas usan solo datos sintéticos (`+593 99 000 00xx`, nombres ficticios). Nunca contactos reales.

## 4. Seguridad operativa
- `memoria/` guarda reglas aprobadas por Pedro: se agregan, nunca se borran ni se reescriben al regenerar un archivo. Hay pruebas que lo vigilan.
- Prohibido en producción (automantpro.app): seed, db push, limpiezas, envíos de prueba.
- Prohibido sin permiso explícito de Pedro: commit, reset, stash, checkout, force-push, borrar archivos.
- No tocar `.env`, `node_modules/`, `*.lock`. No escribir tokens ni claves en código, chat o Git.
- `npm test` dentro de `packages/local-agent` debe pasar antes de entregar.
