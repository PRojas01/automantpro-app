import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
// Portable, uncompressed ZIP; only an explicit allowlist, never .env or logs.
const root = fileURLToPath(new URL('../', import.meta.url));
const files = ['package.json', '.env.example', '.gitignore', 'README.md', 'src/client.mjs', 'src/main.mjs', 'scripts/bundle.mjs', 'scripts/install-ubuntu.sh', 'test/client.node-test.mjs'];
function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}
const chunks = [], central = [];
let offset = 0;
for (const file of files) {
  const body = await readFile(resolve(root, file));
  const name = Buffer.from(`automantpro-local-agent/${file}`);
  const crc = crc32(body), header = Buffer.alloc(30), directory = Buffer.alloc(46);
  header.writeUInt32LE(0x04034b50); header.writeUInt16LE(20, 4); header.writeUInt16LE(0x21, 12);
  header.writeUInt32LE(crc, 14); header.writeUInt32LE(body.length, 18); header.writeUInt32LE(body.length, 22); header.writeUInt16LE(name.length, 26);
  directory.writeUInt32LE(0x02014b50); directory.writeUInt16LE(20, 4); directory.writeUInt16LE(20, 6); directory.writeUInt16LE(0x21, 14);
  directory.writeUInt32LE(crc, 16); directory.writeUInt32LE(body.length, 20); directory.writeUInt32LE(body.length, 24);
  directory.writeUInt16LE(name.length, 28); directory.writeUInt32LE(offset, 42);
  chunks.push(header, name, body); central.push(directory, name); offset += header.length + name.length + body.length;
}
const directory = Buffer.concat(central), end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
const zip = Buffer.concat([...chunks, directory, end]);
await mkdir(resolve(root, 'dist'), { recursive: true });
await writeFile(resolve(root, 'dist/automantpro-local-agent.zip'), zip);
await writeFile(resolve(root, 'dist/automantpro-local-agent.zip.sha256'), `${createHash('sha256').update(zip).digest('hex')}  automantpro-local-agent.zip\n`);
console.log('dist/automantpro-local-agent.zip (sin credenciales)');
