import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
// Portable, uncompressed ZIP; only an explicit allowlist, never .env, data/ or logs.
// Every module that src/ or scripts/ imports must be listed here (test/bundle.node-test.mjs checks it).
const root = fileURLToPath(new URL('../', import.meta.url));
const files = [
  'package.json',
  '.env.example',
  '.gitignore',
  'README.md',
  'AGENTS.md',
  'MEJORAS.md',
  'memoria/comandos.md',
  'memoria/preguntas-frecuentes.md',
  'memoria/servicios.md',
  'memoria/tono.md',
  'src/actions.mjs',
  'src/approval-inbox.mjs',
  'src/bridge-core.mjs',
  'src/client.mjs',
  'src/contacts-store.mjs',
  'src/drafter.mjs',
  'src/guard.mjs',
  'src/jobs.mjs',
  'src/learning.mjs',
  'src/main.mjs',
  'src/memory-db.mjs',
  'src/readiness.mjs',
  'src/rules.mjs',
  'src/run-job.mjs',
  'src/secondary.mjs',
  'src/task-types.mjs',
  'src/task-worker.mjs',
  'src/whatsapp-bridge.mjs',
  'src/whatsapp-export-scan.mjs',
  'src/whatsapp-history-scan.mjs',
  'src/whatsapp-import.mjs',
  'src/scripts/capturas.mjs',
  'src/vendor/pymeagents/automantpro/agent.mjs',
  'src/vendor/pymeagents/automantpro/tools.mjs',
  'src/vendor/pymeagents/automantpro/README.md',
  'src/vendor/pymeagents/browser/actions/whatsapp.cjs',
  'src/vendor/pymeagents/browser/actions/whatsapp-selectors.cjs',
  'src/vendor/pymeagents/human/typing.cjs',
  'src/vendor/pymeagents/human/warmup.cjs',
  'src/vendor/pymeagents/human/profiles.cjs',
  'src/vendor/pymeagents/human/pacing.cjs',
  'src/vendor/pymeagents/human/consent.cjs',
  'scripts/bandeja.mjs',
  'scripts/bundle.mjs',
  'scripts/ciclo-nocturno.mjs',
  'scripts/doctor.mjs',
  'scripts/eval-agente.mjs',
  'scripts/install-ubuntu.sh',
  'scripts/listo.mjs',
  'scripts/migrar.mjs',
  'scripts/reglas.mjs',
  'scripts/secundaria.mjs',
  'test/actions.node-test.mjs',
  'test/approval-inbox.node-test.mjs',
  'test/bridge-core.node-test.mjs',
  'test/bundle.node-test.mjs',
  'test/client.node-test.mjs',
  'test/drafter-chain.node-test.mjs',
  'test/eval-agent.node-test.mjs',
  'test/memory-db.node-test.mjs',
  'test/migrar.node-test.mjs',
  'test/fixtures/conversaciones.json',
];
function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}
const chunks = [], central = [];
let offset = 0;
for (const file of files) {
  const body = await readFile(resolve(root, file));
  const name = Buffer.from(`automantpro-local-agent/${file}`);
  const crc = crc32(body), header = Buffer.alloc(30), directory = Buffer.alloc(46);
  header.writeUInt32LE(0x04034b50); header.writeUInt16LE(20, 4); header.writeUInt16LE(0x21, 12);
  header.writeUInt32LE(crc, 14); header.writeUInt32LE(body.length, 18); header.writeUInt32LE(body.length, 22); header.writeUInt16LE(name.length, 26);
  directory.writeUInt32LE(0x02014b50); directory.writeUInt16LE(20, 4); directory.writeUInt16LE(20, 6); directory.writeUInt16LE(0x21, 14);
  directory.writeUInt32LE(crc, 16); directory.writeUInt32LE(body.length, 20); directory.writeUInt32LE(body.length, 24);
  directory.writeUInt16LE(name.length, 28); directory.writeUInt32LE(offset, 42);
  chunks.push(header, name, body); central.push(directory, name); offset += header.length + name.length + body.length;
}
const directory = Buffer.concat(central), end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
const zip = Buffer.concat([...chunks, directory, end]);
await mkdir(resolve(root, 'dist'), { recursive: true });
await writeFile(resolve(root, 'dist/automantpro-local-agent.zip'), zip);
await writeFile(resolve(root, 'dist/automantpro-local-agent.zip.sha256'), `${createHash('sha256').update(zip).digest('hex')}  automantpro-local-agent.zip\n`);
console.log('dist/automantpro-local-agent.zip (sin credenciales)');
