#!/usr/bin/env node
// Digiere un manual del propietario o de taller en este equipo y deja, para revisar, el CSV del plan por
// componentes que se importa en /admin → Importar componentes (o en el panel del taller).
//
//   npm run manual -- --archivo "C:\Manuales\wingle5.pdf" --marca "Great Wall" --modelo "Wingle 5" \
//     --desde 2012 --hasta 2017 --combustible diesel --titulo "Manual del propietario Wingle 5 (2014)" \
//     --url "https://…/manual.pdf" [--tipo propietario|taller] [--paginas 120-128] [--extractor claude|ollama]
//     [--hibrido] [--motor 4JA1] [--sin-memoria] [--salida carpeta]
//
// Gasta lo mínimo: las tablas en matriz se leen por código (sin modelo), las páginas sin intervalos no se envían
// y cada respuesta se guarda en <salida>/.memoria para no pagar dos veces la misma página. --motor filtra las
// filas escritas para otros motores.
//
// Extrae con Claude Haiku (bajo costo; envía el texto de las páginas del manual). Con --extractor ollama todo
// queda en el equipo (0 créditos, pero un 7B sin GPU tarda minutos por página y ocupa 5 GB de memoria).
// Con --hibrido, Claude revisa además las filas dudosas.
// Nunca importa ni escribe en la base: deja revision.json, revision.md y plan.csv en data/manuales/<marca-modelo>/.
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { askModel } from '../src/drafter.mjs';
import { askOllama, digestManual, extractPages } from '../src/manual-digest.mjs';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => { if (a.startsWith('--')) acc.push([a.slice(2), all[i + 1] && !all[i + 1].startsWith('--') ? all[i + 1] : true]); return acc; }, []));
const need = ['archivo', 'marca', 'modelo', 'desde', 'hasta', 'titulo'];
const missing = need.filter(k => !args[k] || args[k] === true);
if (missing.length) { console.error(`Faltan: ${missing.map(k => `--${k}`).join(' ')}`); process.exit(2); }
const range = String(args.paginas || '').match(/^(\d+)-(\d+)$/);
const meta = {
  marca: String(args.marca), modelo: String(args.modelo), anioDesde: Number(args.desde), anioHasta: Number(args.hasta),
  combustible: args.combustible ? String(args.combustible) : null, titulo: String(args.titulo).slice(0, 200),
  url: typeof args.url === 'string' && /^https?:\/\//.test(args.url) ? args.url : null,
  fecha: new Date().toISOString().slice(0, 10),
  paginas: range ? Array.from({ length: Number(range[2]) - Number(range[1]) + 1 }, (_, i) => Number(range[1]) + i) : null,
  tipo: args.tipo === 'taller' ? 'taller' : 'propietario',
};
if (args.tipo && !['propietario', 'taller'].includes(args.tipo)) { console.error('--tipo debe ser propietario o taller.'); process.exit(2); }
if (!Number.isInteger(meta.anioDesde) || !Number.isInteger(meta.anioHasta) || meta.anioDesde > meta.anioHasta) { console.error('Años inválidos.'); process.exit(2); }

const pages = await extractPages(resolve(String(args.archivo)));
console.log(`Manual leído: ${pages.length} páginas.`);
const verify = args.hibrido ? prompt => askModel('claude', prompt, { claudeModel: process.env.MANUAL_CLAUDE_MODEL || 'haiku', timeoutMs: 120_000 }) : null;
const extractor = args.extractor === 'ollama' ? 'ollama' : 'claude';
if (args.extractor && !['claude', 'ollama'].includes(args.extractor)) { console.error('--extractor debe ser claude u ollama.'); process.exit(2); }
const claude = prompt => askModel('claude', prompt, { claudeModel: process.env.MANUAL_CLAUDE_MODEL || 'haiku', timeoutMs: 180_000 });
console.log(`Extractor: ${extractor}.`);
const root = typeof args.salida === 'string' ? resolve(args.salida) : join(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'manuales');
const memory = join(root, '.memoria');
await mkdir(memory, { recursive: true });
let reused = 0, sent = 0;
const remember = (ask) => async (prompt) => {
  const file = join(memory, `${createHash('sha256').update(`${extractor}\n${prompt}`).digest('hex')}.txt`);
  if (!args['sin-memoria']) { const saved = await readFile(file, 'utf8').catch(() => null); if (saved) { reused++; return saved; } }
  sent += prompt.length;
  const out = await ask(prompt);
  if (out) await writeFile(file, out, 'utf8');
  return out;
};
const usage = {};
const result = await digestManual(pages, meta, { ask: remember(extractor === 'ollama' ? prompt => askOllama(prompt) : claude), verify: verify ? remember(verify) : null, motor: typeof args.motor === 'string' ? args.motor : null, usage, log: m => console.log(`  · ${m}`) });
console.log(`Costo: ${usage.porCodigo} página(s) por código, ${usage.alModelo} al modelo (${reused} ya guardadas, ${sent} caracteres enviados), ${usage.sinIntervalos} sin intervalos.`);

const slug = `${meta.marca}-${meta.modelo}-${meta.anioDesde}-${meta.anioHasta}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const out = join(root, `${slug}-${meta.tipo}`);
await mkdir(out, { recursive: true });
await writeFile(join(out, 'plan.csv'), result.csv, 'utf8');
// Árbol de sistemas del manual, como referencia (los códigos van también en cada fila de plan.csv).
const cell = v => { const t = String(v ?? ''); return `"${(/^[=+\-@]/.test(t) ? `'${t}` : t).replace(/"/g, '""')}"`; };
const systems = [...new Set(result.rows.filter(r => r.sistemaFabricante || r.codigoSistema).map(r => `${cell(r.codigoSistema)},${cell(r.sistemaFabricante)}`))].sort();
await writeFile(join(out, 'sistemas.csv'), `codigo_sistema,sistema_fabricante\n${systems.join('\n')}\n`, 'utf8');
await writeFile(join(out, 'revision.json'), JSON.stringify({ meta, ...result, csv: undefined }, null, 2), 'utf8');
const extras = r => [r.inspeccionKm || r.inspeccionMeses ? `revisar ${r.inspeccionKm ?? '—'} km / ${r.inspeccionMeses ?? '—'} m` : '', r.severoKm || r.severoMeses ? `severo ${r.severoKm ?? '—'} km / ${r.severoMeses ?? '—'} m` : '', r.operacion ? `operación (resumen del modelo, verificar): ${r.operacion}` : '', r.especificacion, r.torque, ...(r.repuestos ?? []).map(p => `${p.cantidad} × ${p.nombre} ${p.codigo}`)].filter(Boolean).join('; ').replace(/\|/g, '/');
const line = r => `| ${r.estado} | ${r.item ?? r.componente} | ${r.km ?? '—'} | ${r.months ?? '—'} | ${r.paginas?.join(', ') ?? r.page} | ${String(r.cita).replace(/\|/g, '/')} | ${[r.motivo, r.revision, extras(r)].filter(Boolean).join('; ')} |`;
await writeFile(join(out, 'revision.md'), [`# ${meta.titulo}`, '', `${meta.marca} ${meta.modelo} ${meta.anioDesde}–${meta.anioHasta}${meta.combustible ? ` · ${meta.combustible}` : ''} · leído ${meta.fecha} · páginas ${result.pagesRead.join(', ') || 'ninguna'}`, '',
  `Aceptadas ${result.counts.aceptadas} · conflicto ${result.counts.conflicto} · sin mapear ${result.counts.sin_mapear} · descartadas ${result.counts.descartadas}`, '',
  'Revisa cada fila contra el manual antes de importar plan.csv en /admin → Importar componentes. Sin URL de la fuente, las filas quedan «referenciales».', '',
  '| Estado | Componente | km | Meses | Pág. | Cita del manual | Nota |', '|---|---|---|---|---|---|---|', ...result.rows.map(line), ''].join('\n'), 'utf8');
console.log(`Listo: ${result.counts.aceptadas} aceptadas, ${result.counts.conflicto} en conflicto, ${result.counts.sin_mapear} sin mapear, ${result.counts.descartadas} descartadas.`);
console.log(`Revisa ${join(out, 'revision.md')} y luego importa ${join(out, 'plan.csv')}.`);
