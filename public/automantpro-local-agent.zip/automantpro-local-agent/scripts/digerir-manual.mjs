#!/usr/bin/env node
// Digiere un manual del propietario o de taller en este equipo y deja, para revisar, el CSV del plan por
// componentes que se importa en /admin → Importar componentes (o en el panel del taller).
//
//   npm run manual -- --archivo "C:\Manuales\wingle5.pdf" --marca "Great Wall" --modelo "Wingle 5" \
//     --desde 2012 --hasta 2017 --combustible diesel --titulo "Manual del propietario Wingle 5 (2014)" \
//     --url "https://…/manual.pdf" [--tipo propietario|taller] [--paginas 120-128] [--hibrido] [--salida carpeta]
//
// Local primero (Ollama, 0 créditos). Con --hibrido, Claude (Haiku) revisa solo las filas dudosas.
// Nunca importa ni escribe en la base: deja revision.json, revision.md y plan.csv en data/manuales/<marca-modelo>/.
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { askModel } from '../src/drafter.mjs';
import { askOllama, digestManual, extractPages } from '../src/manual-digest.mjs';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => { if (a.startsWith('--')) acc.push([a.slice(2), all[i + 1] && !all[i + 1].startsWith('--') ? all[i + 1] : true]); return acc; }, []));
const need = ['archivo', 'marca', 'modelo', 'desde', 'hasta', 'titulo'];
const missing = need.filter(k => !args[k] || args[k] === true);
if (missing.length) { console.error(`Faltan: ${missing.map(k => `--${k}`).join(' ')}`); process.exit(2); }
const range = String(args.paginas || '').match(/^(\d+)-(\d+)$/);
const meta = {
  marca: String(args.marca), modelo: String(args.modelo), anioDesde: Number(args.desde), anioHasta: Number(args.hasta),
  combustible: args.combustible ? String(args.combustible) : null, titulo: String(args.titulo).slice(0, 200),
  url: typeof args.url === 'string' && /^https?:\/\//.test(args.url) ? args.url : null,
  fecha: new Date().toISOString().slice(0, 10),
  paginas: range ? Array.from({ length: Number(range[2]) - Number(range[1]) + 1 }, (_, i) => Number(range[1]) + i) : null,
  tipo: args.tipo === 'taller' ? 'taller' : 'propietario',
};
if (args.tipo && !['propietario', 'taller'].includes(args.tipo)) { console.error('--tipo debe ser propietario o taller.'); process.exit(2); }
if (!Number.isInteger(meta.anioDesde) || !Number.isInteger(meta.anioHasta) || meta.anioDesde > meta.anioHasta) { console.error('Años inválidos.'); process.exit(2); }

const pages = await extractPages(resolve(String(args.archivo)));
console.log(`Manual leído: ${pages.length} páginas.`);
const verify = args.hibrido ? prompt => askModel('claude', prompt, { claudeModel: process.env.MANUAL_CLAUDE_MODEL || 'haiku', timeoutMs: 120_000 }) : null;
const result = await digestManual(pages, meta, { ask: prompt => askOllama(prompt), verify, log: m => console.log(`  · ${m}`) });

const slug = `${meta.marca}-${meta.modelo}-${meta.anioDesde}-${meta.anioHasta}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const root = typeof args.salida === 'string' ? resolve(args.salida) : join(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'manuales');
const out = join(root, `${slug}-${meta.tipo}`);
await mkdir(out, { recursive: true });
await writeFile(join(out, 'plan.csv'), result.csv, 'utf8');
// Árbol de sistemas del manual, como referencia (los códigos van también en cada fila de plan.csv).
const cell = v => { const t = String(v ?? ''); return `"${(/^[=+\-@]/.test(t) ? `'${t}` : t).replace(/"/g, '""')}"`; };
const systems = [...new Set(result.rows.filter(r => r.sistemaFabricante || r.codigoSistema).map(r => `${cell(r.codigoSistema)},${cell(r.sistemaFabricante)}`))].sort();
await writeFile(join(out, 'sistemas.csv'), `codigo_sistema,sistema_fabricante\n${systems.join('\n')}\n`, 'utf8');
await writeFile(join(out, 'revision.json'), JSON.stringify({ meta, ...result, csv: undefined }, null, 2), 'utf8');
const extras = r => [r.inspeccionKm || r.inspeccionMeses ? `revisar ${r.inspeccionKm ?? '—'} km / ${r.inspeccionMeses ?? '—'} m` : '', r.severoKm || r.severoMeses ? `severo ${r.severoKm ?? '—'} km / ${r.severoMeses ?? '—'} m` : '', r.operacion ? `operación (resumen del modelo, verificar): ${r.operacion}` : '', r.especificacion, r.torque, ...(r.repuestos ?? []).map(p => `${p.cantidad} × ${p.nombre} ${p.codigo}`)].filter(Boolean).join('; ').replace(/\|/g, '/');
const line = r => `| ${r.estado} | ${r.item ?? r.componente} | ${r.km ?? '—'} | ${r.months ?? '—'} | ${r.paginas?.join(', ') ?? r.page} | ${String(r.cita).replace(/\|/g, '/')} | ${[r.motivo, r.revision, extras(r)].filter(Boolean).join('; ')} |`;
await writeFile(join(out, 'revision.md'), [`# ${meta.titulo}`, '', `${meta.marca} ${meta.modelo} ${meta.anioDesde}–${meta.anioHasta}${meta.combustible ? ` · ${meta.combustible}` : ''} · leído ${meta.fecha} · páginas ${result.pagesRead.join(', ') || 'ninguna'}`, '',
  `Aceptadas ${result.counts.aceptadas} · conflicto ${result.counts.conflicto} · sin mapear ${result.counts.sin_mapear} · descartadas ${result.counts.descartadas}`, '',
  'Revisa cada fila contra el manual antes de importar plan.csv en /admin → Importar componentes. Sin URL de la fuente, las filas quedan «referenciales».', '',
  '| Estado | Componente | km | Meses | Pág. | Cita del manual | Nota |', '|---|---|---|---|---|---|---|', ...result.rows.map(line), ''].join('\n'), 'utf8');
console.log(`Listo: ${result.counts.aceptadas} aceptadas, ${result.counts.conflicto} en conflicto, ${result.counts.sin_mapear} sin mapear, ${result.counts.descartadas} descartadas.`);
console.log(`Revisa ${join(out, 'revision.md')} y luego importa ${join(out, 'plan.csv')}.`);
