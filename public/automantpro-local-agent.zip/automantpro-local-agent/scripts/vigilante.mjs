// Vigilante: lo lanza una tarea programada cada 5 minutos. Avisa; reinicia solo con VIGILANTE_REINICIAR=1 en .env.
import { execFile } from 'node:child_process';
import { appendFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { evaluarVigilancia, leerEstado } from '../src/supervision.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
try { process.loadEnvFile(join(root, '.env')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
const dataDir = resolve(root, process.env.WHATSAPP_DATA_DIR || 'data');
const run = promisify(execFile);
const TAREAS = { puente: 'AutoMantPro Puente', operador: 'AutoMantPro Operador' };

await mkdir(dataDir, { recursive: true, mode: 0o700 });
const stateFile = join(dataDir, 'vigilante.json');
const previo = await readFile(stateFile, 'utf8').then(JSON.parse).catch(() => ({}));
const { alertas, reiniciar } = evaluarVigilancia(await leerEstado(dataDir));
const codigos = alertas.map(a => a.codigo).sort().join(',');
const reinicios = { ...(previo.reinicios ?? {}) };
const hechos = [];
if (process.env.VIGILANTE_REINICIAR === '1' && process.platform === 'win32') {
  for (const proceso of reiniciar) {
    // Como mucho un reinicio cada 30 minutos por proceso: sin ráfagas ante un fallo que no se arregla solo.
    if (Date.now() - (reinicios[proceso] ?? 0) < 30 * 60_000) continue;
    await run('schtasks', ['/End', '/TN', TAREAS[proceso]]).catch(() => {});
    await run('schtasks', ['/Run', '/TN', TAREAS[proceso]]).then(() => hechos.push(proceso), () => {});
    reinicios[proceso] = Date.now();
  }
}
const nuevo = codigos && (codigos !== previo.codigos || Date.now() - (previo.avisado ?? 0) > 60 * 60_000);
if (nuevo || hechos.length) {
  const texto = `${codigos}${hechos.length ? ` · reiniciado: ${hechos.join(', ')}` : ''}`;
  await appendFile(join(dataDir, 'alertas.log'), `${new Date().toISOString()} ${texto}\n`, { mode: 0o600 });
  if (process.platform === 'win32') await run('msg', ['*', '/TIME:120', `AutoMantPro vigilante: ${texto}`]).catch(() => {});
}
await writeFile(stateFile, JSON.stringify({ fecha: new Date().toISOString(), codigos, avisado: nuevo ? Date.now() : previo.avisado ?? 0, reinicios, alertas }, null, 1), { mode: 0o600 });
process.stdout.write(`${codigos || 'Sin alertas'}\n`);
