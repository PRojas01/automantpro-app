import { createMemoryDb } from '../src/memory-db.mjs';
import { approveRule } from '../src/rules.mjs';

const [verb, id] = process.argv.slice(2);
const db = await createMemoryDb();
try {
  if (verb === 'listar') process.stdout.write(`${JSON.stringify(db.listarReglas(), null, 2)}\n`);
  else if (['aprobar','rechazar'].includes(verb) && /^\d+$/.test(id ?? '')) {
    const numericId = Number(id);
    const ok = verb === 'aprobar' ? await approveRule(db, numericId) : db.decidirRegla(numericId, 'rechazada');
    if (!ok) throw new Error('RULE_NOT_PENDING');
    process.stdout.write(`Regla ${numericId}: ${verb === 'aprobar' ? 'aprobada' : 'rechazada'}.\n`);
  } else { process.stderr.write('Uso: node scripts/reglas.mjs listar | aprobar <id> | rechazar <id>\n'); process.exitCode = 2; }
} catch (error) { process.stderr.write(`No se pudo gestionar la regla: ${error.message}\n`); process.exitCode = 1; }
finally { db.cerrar(); }
