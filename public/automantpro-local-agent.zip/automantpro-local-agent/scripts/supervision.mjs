// Informe de supervisión: lo imprime y lo deja en data/supervision.md. Uso: node scripts/supervision.mjs [horas]
import { writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { informeSupervision } from '../src/supervision.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = resolve(root, process.env.WHATSAPP_DATA_DIR || 'data');
const horas = Number(process.argv[2]) > 0 ? Number(process.argv[2]) : 24;
const informe = await informeSupervision(dataDir, { horas });
await writeFile(join(dataDir, 'supervision.md'), informe, { mode: 0o600 }).catch(() => {});
process.stdout.write(informe);
