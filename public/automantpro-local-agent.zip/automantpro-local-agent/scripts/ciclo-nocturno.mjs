import { chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createMemoryDb } from '../src/memory-db.mjs';
import { runEvaluation } from './eval-agente.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const dataDir = join(here, '../data');
const casesPath = join(dataDir, 'eval/casos-reales.json');
const mainRun = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];

export async function exportCorrectedCases(db, path = casesPath) {
  const root = dirname(path);
  await mkdir(root, { recursive: true, mode: 0o700 }); await chmod(root, 0o700);
  let cases = [];
  try { cases = JSON.parse(await readFile(path, 'utf8')); if (!Array.isArray(cases)) throw new Error('INVALID_EVAL_CASES'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  const ids = new Set(cases.map(item => String(item.id)));
  for (const event of db.eventosCorregidosNoExportados()) {
    const item = db.guardarCasoCorregido({ eventoId: event.id, habilidad: event.habilidad, mensaje: event.accion_propuesta, sugerido: '', final: event.texto_final_anon });
    if (!ids.has(item.id)) { cases.push(item); ids.add(item.id); }
    db.marcarEventoEvalExportado(event.id);
  }
  if (cases.length || await readFile(path, 'utf8').then(() => true).catch(() => false)) { await writeFile(path, `${JSON.stringify(cases, null, 2)}\n`, { mode: 0o600 }); await chmod(path, 0o600); }
  return cases.length;
}

export async function runNightCycle({ db, dataDir: targetDataDir = dataDir, evaluate = runEvaluation } = {}) {
  const ownedDb = db ? null : await createMemoryDb({ dataDir: targetDataDir });
  const memory = db || ownedDb;
  try {
    const caseCount = await exportCorrectedCases(memory, join(targetDataDir, 'eval/casos-reales.json'));
    const result = await evaluate({ agent: 'codex', useAgent: true, review: true, db: memory, dataDir: targetDataDir });
    const todayNotes = memory.listarNotas().filter(note => note.fecha === result.fecha.slice(0, 10));
    process.stdout.write(`Ciclo nocturno: ${caseCount} casos reales; evaluación ${result.casos} casos; ${todayNotes.length} notas por habilidad; ${memory.listarReglas('propuesta').length} propuestas pendientes.\n`);
    return { result, notes: todayNotes, proposals: memory.listarReglas('propuesta').length };
  } finally { ownedDb?.cerrar(); }
}

if (mainRun) await runNightCycle();
