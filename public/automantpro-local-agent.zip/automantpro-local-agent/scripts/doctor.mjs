import { access, constants, stat } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { execFile } from 'node:child_process';
import { validateBaseUrl } from '../src/client.mjs';

/**
 * Checks this computer before the first shift: Node, private .env, server reachability,
 * WhatsApp Web bridge dependencies and the optional Claude CLI. Never prints the token.
 */
const require = createRequire(import.meta.url);
const results = [];
const check = (ok, label, hint = '') => { results.push({ ok, label, hint }); };
const exists = async path => { try { await access(path, constants.X_OK); return true; } catch { return false; } };
const run = (cmd, args) => new Promise(done => execFile(cmd, args, { timeout: 15_000 }, (error, stdout) => done(error ? null : String(stdout).trim())));

check(Number(process.versions.node.split('.')[0]) === 22, `Node.js ${process.versions.node}`, 'Se requiere Node.js 22.');
try {
  const info = await stat(resolve('.env'));
  check(process.platform === 'win32' || (info.mode & 0o077) === 0, '.env privado (0600)', 'Ejecute: chmod 600 .env');
  process.loadEnvFile(resolve('.env'));
} catch { check(false, '.env presente', 'Copie .env.example a .env y edite URL y clave.'); }

let origin = null;
try { origin = validateBaseUrl(process.env.LOCAL_AGENT_URL); check(true, `Servidor ${origin}`); }
catch { check(false, 'LOCAL_AGENT_URL', 'Use https://automantpro.app o http://localhost para pruebas.'); }
const token = process.env.LOCAL_AGENT_TOKEN || '';
const tokenReady = /^[A-Za-z0-9_-]{32,200}$/.test(token) && token !== 'replace-with-dedicated-server-token';
check(tokenReady, 'Clave del agente configurada', 'Genérela en /admin/local-agent y péguela en LOCAL_AGENT_TOKEN.');

if (origin) {
  try {
    const health = await fetch(`${origin}/health`, { signal: AbortSignal.timeout(10_000), redirect: 'error' });
    check(health.ok, `Servidor responde /health (${health.status})`, 'Revise la URL y la conexión a Internet.');
  } catch { check(false, 'Servidor responde /health', 'Revise la URL y la conexión a Internet.'); }
  if (tokenReady) {
    try {
      const ping = await fetch(`${origin}/api/v1/local-agent/ping`, { headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10_000), redirect: 'error' });
      const body = await ping.json().catch(() => null);
      check(ping.status !== 401, 'Clave aceptada por el servidor', 'La clave fue rotada o revocada: genere otra en /admin/local-agent.');
      check(ping.ok, 'Agente habilitado en el servidor', 'Active el equipo en /admin/local-agent.');
      if (ping.ok) check(body?.data?.whatsappDelivery === 'bridge' || !process.argv.includes('--whatsapp'), `Canal WhatsApp del servidor: ${body?.data?.whatsappDelivery ?? 'desconocido'}`, 'Para usar el puente, el hosting debe tener WHATSAPP_DELIVERY=bridge.');
    } catch { check(false, 'Consulta autenticada al servidor', 'Revise la conexión.'); }
  }
}

if (process.argv.includes('--whatsapp')) {
  try { require.resolve('playwright-core'); check(true, 'playwright-core instalado'); }
  catch { check(false, 'playwright-core instalado', 'Ejecute: npm install --omit=dev (o el instalador con --whatsapp).'); }
  const browser = process.env.WHATSAPP_BROWSER_PATH || '/usr/bin/google-chrome';
  check(await exists(browser), `Navegador ${browser}`, 'Instale Google Chrome o Chromium y ajuste WHATSAPP_BROWSER_PATH.');
}
if (process.argv.includes('--claude') || process.env.LOCAL_AGENT_DRAFTER === 'claude') {
  const version = await run(process.env.LOCAL_AGENT_DRAFTER_COMMAND || 'claude', ['--version']);
  check(!!version, `Claude Code CLI ${version ?? ''}`.trim(), 'Instale Claude Code e inicie sesión una vez con: claude');
}

for (const r of results) process.stdout.write(`${r.ok ? '✔' : '✘'} ${r.label}${r.ok || !r.hint ? '' : ` — ${r.hint}`}\n`);
const failed = results.filter(r => !r.ok).length;
process.stdout.write(failed ? `\n${failed} punto(s) por resolver.\n` : '\nTodo listo.\n');
process.exitCode = failed ? 1 : 0;
