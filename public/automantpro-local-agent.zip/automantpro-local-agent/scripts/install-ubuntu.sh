#!/usr/bin/env bash
set -euo pipefail
if [[ "$(uname -s)" != Linux ]]; then
  printf 'Este instalador es para Linux; use instalación portable en macOS/Windows.\n' >&2
  exit 1
fi
if ! command -v node >/dev/null || [[ "$(node -p 'process.versions.node.split(".")[0]')" != 22 ]]; then
  printf 'Instale Node.js 22 con el mecanismo aprobado de su equipo y repita este comando.\n' >&2
  exit 1
fi
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
install_dir="${1:-${XDG_DATA_HOME:-$HOME/.local/share}/automantpro-local-agent}"
bin_dir="${LOCAL_AGENT_BIN_DIR:-$HOME/.local/bin}"
mkdir -p -- "$install_dir/src" "$install_dir/test" "$install_dir/scripts" "$bin_dir"
chmod 700 -- "$install_dir"
if [[ "$(cd -- "$install_dir" && pwd)" != "$source_dir" ]]; then
  cp -- "$source_dir/src/client.mjs" "$source_dir/src/main.mjs" "$install_dir/src/"
  cp -- "$source_dir/package.json" "$source_dir/README.md" "$source_dir/.env.example" "$install_dir/"
  cp -- "$source_dir/test/client.node-test.mjs" "$install_dir/test/"
  cp -- "$source_dir/scripts/install-ubuntu.sh" "$source_dir/scripts/bundle.mjs" "$install_dir/scripts/"
fi
umask 077
if [[ ! -e "$install_dir/.env" ]]; then
  cp -- "$source_dir/.env.example" "$install_dir/.env"
fi
chmod 600 -- "$install_dir/.env"
launcher="$bin_dir/automantpro-agent"
{
  printf '#!/usr/bin/env bash\nset -euo pipefail\ncd -- %q\nexec node src/main.mjs\n' "$install_dir"
} > "$launcher"
chmod 700 -- "$launcher"
printf 'Instalado sin root. Edite URL/token en %s/.env (no se ha mostrado ningún secreto).\n' "$install_dir"
printf 'Inicie en terminal: %q\nNo se instala systemd: cada respuesta exige aprobación humana.\n' "$launcher"
