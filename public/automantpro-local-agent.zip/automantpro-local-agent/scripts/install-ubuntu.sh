#!/usr/bin/env bash
# Instalador del agente local de AutoMantPro para un equipo Ubuntu aparte, sin root.
# Uso: bash scripts/install-ubuntu.sh [--whatsapp] [--claude] [carpeta-de-instalación]
#   --whatsapp  instala playwright-core (descarga de npm) y crea el lanzador del puente WhatsApp Web.
#   --claude    activa los borradores de Claude en la terminal del operador (requiere el CLI claude).
set -euo pipefail
if [[ "$(uname -s)" != Linux ]]; then
  printf 'Este instalador es para Linux; use instalación portable en macOS/Windows.\n' >&2
  exit 1
fi
if ! command -v node >/dev/null || [[ "$(node -p 'process.versions.node.split(".")[0]')" != 22 ]]; then
  printf 'Instale Node.js 22 con el mecanismo aprobado de su equipo y repita este comando.\n' >&2
  exit 1
fi
with_whatsapp=0
with_claude=0
install_arg=""
for arg in "$@"; do
  case "$arg" in
    --whatsapp) with_whatsapp=1 ;;
    --claude) with_claude=1 ;;
    -*) printf 'Opción desconocida: %s\n' "$arg" >&2; exit 2 ;;
    *) install_arg="$arg" ;;
  esac
done
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
install_dir="${install_arg:-${XDG_DATA_HOME:-$HOME/.local/share}/automantpro-local-agent}"
bin_dir="${LOCAL_AGENT_BIN_DIR:-$HOME/.local/bin}"
mkdir -p -- "$install_dir/src/vendor/pymeagents/browser/actions" "$install_dir/src/vendor/pymeagents/human" "$install_dir/test" "$install_dir/scripts" "$bin_dir"
install_dir="$(cd -- "$install_dir" && pwd)"
bin_dir="$(cd -- "$bin_dir" && pwd)"
chmod 700 -- "$install_dir"
if [[ "$install_dir" != "$source_dir" ]]; then
  cp -- "$source_dir/src/client.mjs" "$source_dir/src/main.mjs" "$install_dir/src/"
  cp -- "$source_dir/src/bridge-core.mjs" "$source_dir/src/drafter.mjs" "$source_dir/src/whatsapp-bridge.mjs" "$install_dir/src/"
  cp -- "$source_dir/src/vendor/pymeagents/browser/actions/"*.cjs "$install_dir/src/vendor/pymeagents/browser/actions/"
  cp -- "$source_dir/src/vendor/pymeagents/human/"*.cjs "$install_dir/src/vendor/pymeagents/human/"
  cp -- "$source_dir/package.json" "$source_dir/README.md" "$source_dir/.env.example" "$install_dir/"
  cp -- "$source_dir/test/client.node-test.mjs" "$source_dir/test/bridge-core.node-test.mjs" "$install_dir/test/"
  cp -- "$source_dir/scripts/install-ubuntu.sh" "$source_dir/scripts/bundle.mjs" "$source_dir/scripts/doctor.mjs" "$install_dir/scripts/"
fi
umask 077
if [[ ! -e "$install_dir/.env" ]]; then
  cp -- "$source_dir/.env.example" "$install_dir/.env"
fi
chmod 600 -- "$install_dir/.env"
# Adds KEY=value only when the key is not set yet; never overwrites what the operator configured.
set_default() {
  if ! grep -qE "^$1=" "$install_dir/.env"; then printf '%s=%s\n' "$1" "$2" >> "$install_dir/.env"; fi
}
write_launcher() {
  { printf '#!/usr/bin/env bash\nset -euo pipefail\ncd -- %q\nexec node %s\n' "$install_dir" "$2"; } > "$bin_dir/$1"
  chmod 700 -- "$bin_dir/$1"
}
write_launcher automantpro-agent src/main.mjs
write_launcher automantpro-doctor "scripts/doctor.mjs$([[ $with_whatsapp == 1 ]] && printf ' --whatsapp')$([[ $with_claude == 1 ]] && printf ' --claude')"
printf 'Instalado sin root en %s. Edite URL y clave en %s/.env (no se ha mostrado ningún secreto).\n' "$install_dir" "$install_dir"

if [[ $with_whatsapp == 1 ]]; then
  browser=""
  for candidate in /usr/bin/google-chrome /usr/bin/google-chrome-stable /usr/bin/chromium /usr/bin/chromium-browser /snap/bin/chromium; do
    if [[ -x "$candidate" ]]; then browser="$candidate"; break; fi
  done
  if [[ -z "$browser" ]]; then
    printf 'Aviso: no encontré Google Chrome ni Chromium. Instale uno y ajuste WHATSAPP_BROWSER_PATH en .env.\n' >&2
  else
    set_default WHATSAPP_BROWSER_PATH "$browser"
  fi
  set_default WHATSAPP_POLL_SECONDS 20
  set_default WHATSAPP_DATA_DIR data
  mkdir -p -- "$install_dir/data"
  chmod 700 -- "$install_dir/data"
  # Only the pinned dependency from package.json; no browser download.
  (cd -- "$install_dir" && PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm install --omit=dev --no-audit --no-fund --ignore-scripts)
  write_launcher automantpro-whatsapp src/whatsapp-bridge.mjs
  printf 'Puente WhatsApp: inicie %q en otra terminal y escanee el QR con el teléfono del piloto.\n' "$bin_dir/automantpro-whatsapp"
fi
if [[ $with_claude == 1 ]]; then
  set_default LOCAL_AGENT_DRAFTER claude
  if ! command -v "${LOCAL_AGENT_DRAFTER_COMMAND:-claude}" >/dev/null; then
    printf 'Aviso: no encontré el CLI claude. Instale Claude Code e inicie sesión una vez con: claude\n' >&2
  fi
fi
printf 'Compruebe el equipo con: %q\n' "$bin_dir/automantpro-doctor"
printf 'Operador: %q (terminal interactiva; cada respuesta exige ENVIO o EJECUTAR). No se instala systemd.\n' "$bin_dir/automantpro-agent"
