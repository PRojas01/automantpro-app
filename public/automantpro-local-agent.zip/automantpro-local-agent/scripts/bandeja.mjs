import { writeInboxDecision, createApprovalInbox } from '../src/approval-inbox.mjs';

const [verb, jobId, action, ...rest] = process.argv.slice(2);
const option = (name) => { const i = rest.indexOf(name); return i < 0 ? undefined : rest[i + 1]; };
try {
  if (verb === 'listar') {
    process.stdout.write(`${JSON.stringify(await createApprovalInbox().list(), null, 2)}\n`);
  } else if (verb === 'decidir') {
    const texto = option('--texto');
    await writeInboxDecision({ jobId, accion: action, ...(texto !== undefined ? { texto } : {}), ...(option('--confirmar') ? { confirmar: option('--confirmar') } : {}) });
    process.stdout.write(`Decisión guardada para ${jobId}.\n`);
  } else {
    process.stderr.write('Uso: node scripts/bandeja.mjs listar | decidir <jobId> EJECUTAR --texto "<comando propuesto>" [--confirmar SI] | decidir <jobId> <ENVIO|IGNORAR|POSPONER> [--texto "…"]\n');
    process.exitCode = 2;
  }
} catch (error) {
  process.stderr.write(`No se guardó la decisión: ${error.message}\n`);
  process.exitCode = 1;
}
