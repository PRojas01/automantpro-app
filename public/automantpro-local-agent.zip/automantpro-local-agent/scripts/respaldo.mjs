// Respaldo diario de la memoria y la configuración, sin secretos. Destino: RESPALDO_DIR o data/respaldos (14 días).
// Fuera del respaldo: sesión de WhatsApp, claves (.clave-contactos, tokens del .env) y bandeja con mensajes.
import { copyFile, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

// Lista cerrada: cualquier variable que no esté aquí (tokens, llaves, URLs con credenciales) queda oculta.
const PUBLICAS = /^(LOCAL_AGENT_(DRAFTER|DRAFTER_CHAIN|SUPERVISOR|CLAUDE_MODEL|OPENCODE_MODEL|DRAFTER_MODEL|OLLAMA_MODEL|OLLAMA_TIMEOUT_MS|OLLAMA_KEEP_ALIVE|POLL_SECONDS|MODO_PRUEBA|AUTO_RESPUESTA|DEV_JOBS|LISTO_MINUTOS)|LOCAL_CLASSIFIER_MODEL|WHATSAPP_(POLL_SECONDS|HORARIO|FORWARD|GAP_MS|MAX_HORA|MAX_DIA)|HUMAN_ACTIVE_HOURS|VIGILANTE_REINICIAR)$/;
export function envSinSecretos(text) {
  return String(text).split(/\r?\n/).flatMap(line => {
    const m = /^\s*([A-Z][A-Z0-9_]*)\s*=\s*(.*)$/.exec(line);
    if (!m) return [];
    return [`${m[1]}=${PUBLICAS.test(m[1]) ? m[2] : '<oculto>'}`];
  }).join('\n') + '\n';
}

export async function respaldar({ paquete = root, destino, fecha = new Date(), conservar = 14 } = {}) {
  const base = resolve(destino || process.env.RESPALDO_DIR || join(paquete, 'data', 'respaldos'));
  const dir = join(base, fecha.toISOString().slice(0, 10));
  await rm(dir, { recursive: true, force: true });
  await mkdir(dir, { recursive: true, mode: 0o700 });
  const copiados = [];
  const copiar = async rel => {
    const src = join(paquete, rel);
    if (!(await stat(src).catch(() => null))?.isFile()) return;
    await mkdir(dirname(join(dir, rel)), { recursive: true, mode: 0o700 });
    await copyFile(src, join(dir, rel));
    copiados.push(rel);
  };
  for (const name of await readdir(join(paquete, 'memoria')).catch(() => [])) await copiar(`memoria/${name}`);
  for (const rel of ['data/permitidos.json', 'data/permitidos.txt', 'data/human/consent.json', 'data/memoria/aprendizaje.jsonl', 'data/eval/casos-reales.json']) await copiar(rel);
  const env = await readFile(join(paquete, '.env'), 'utf8').catch(() => null);
  if (env !== null) { await writeFile(join(dir, 'env-sin-secretos.txt'), envSinSecretos(env), { mode: 0o600 }); copiados.push('env-sin-secretos.txt'); }
  const db = join(paquete, 'data', 'memoria.db');
  if (await stat(db).catch(() => null)) {
    const { DatabaseSync } = await import('node:sqlite');
    const source = new DatabaseSync(db, { readOnly: true });
    await mkdir(join(dir, 'data'), { recursive: true, mode: 0o700 });
    try { source.prepare('VACUUM INTO ?').run(join(dir, 'data', 'memoria.db')); copiados.push('data/memoria.db'); }
    finally { source.close(); }
  }
  const viejos = (await readdir(base)).filter(n => /^\d{4}-\d{2}-\d{2}$/.test(n)).sort().slice(0, -conservar);
  for (const name of viejos) await rm(join(base, name), { recursive: true, force: true });
  return { dir, copiados };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try { process.loadEnvFile(join(root, '.env')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const { dir, copiados } = await respaldar();
  process.stdout.write(`Respaldo en ${dir} (${copiados.length} archivos).\n`);
}
