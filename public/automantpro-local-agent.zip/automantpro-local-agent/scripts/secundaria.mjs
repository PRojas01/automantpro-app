// Uso: node scripts/secundaria.mjs plan_mantenimiento '{"marca":"Marca X","modelo":"Modelo Y","anio":2018,"kilometraje":85000}'
// Deja un borrador en data/bandeja/secundarias; no envía nada.
import { SECONDARY_TYPES, draftSecondary, saveSecondaryDraft } from '../src/secondary.mjs';

const [tipo, raw = '{}'] = process.argv.slice(2);
if (!SECONDARY_TYPES.includes(tipo)) { process.stderr.write(`Tipo no permitido. Usa: ${SECONDARY_TYPES.join(', ')}\n`); process.exit(1); }
let datos;
try { datos = JSON.parse(raw); } catch { process.stderr.write('Datos JSON inválidos.\n'); process.exit(1); }
const draft = await draftSecondary({ tipo, datos });
if (!draft) { process.stderr.write('Ningún redactor (Ollama, opencode) devolvió borrador.\n'); process.exit(1); }
process.stdout.write(`Borrador (${draft.agente}) guardado en ${await saveSecondaryDraft(draft)}:\n${draft.texto}\n`);
