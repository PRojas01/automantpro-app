import { createCipheriv, createDecipheriv, createHash, randomBytes, scrypt as scryptCb } from 'node:crypto';
import { promisify } from 'node:util';
import { createReadStream } from 'node:fs';
import { chmod, lstat, mkdir, mkdtemp, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stdin, stdout } from 'node:process';
import { tmpdir } from 'node:os';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const scrypt = promisify(scryptCb);
const MAGIC = Buffer.from('AMPMIG1\0');
const SALT_BYTES = 16, NONCE_BYTES = 12, TAG_BYTES = 16;
const SAFE_FILES = ['package.json', '.env.example', '.gitignore', 'README.md', 'AGENTS.md', 'MEJORAS.md'];
export const migracionExcluye = path => path === '.env' || path.startsWith('data/whatsapp-profile/') || path.startsWith('node_modules/') || path.endsWith('.log') || path.endsWith('.lock');

export async function cifrarPaquete(plaintext, passphrase) {
  const salt = randomBytes(SALT_BYTES), nonce = randomBytes(NONCE_BYTES), key = await scrypt(passphrase, salt, 32);
  const cipher = createCipheriv('aes-256-gcm', key, nonce), encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return Buffer.concat([MAGIC, salt, nonce, cipher.getAuthTag(), encrypted]);
}

export async function descifrarPaquete(bytes, passphrase) {
  if (bytes.length < MAGIC.length + SALT_BYTES + NONCE_BYTES + TAG_BYTES || !bytes.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('Archivo ampkg inválido');
  let offset = MAGIC.length; const salt = bytes.subarray(offset, offset += SALT_BYTES), nonce = bytes.subarray(offset, offset += NONCE_BYTES), tag = bytes.subarray(offset, offset += TAG_BYTES);
  const key = await scrypt(passphrase, salt, 32), decipher = createDecipheriv('aes-256-gcm', key, nonce); decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(bytes.subarray(offset)), decipher.final()]);
}

export async function escribirPayload(bytes, target) {
  await mkdir(target, { recursive: true, mode: 0o700 });
  if (bytes.subarray(0, 8).toString() !== 'AMPPAY1\0') throw new Error('Formato interno inválido');
  let offset = 8;
  while (offset < bytes.length) {
    if (offset + 8 > bytes.length) throw new Error('Paquete truncado');
    const nameLength = bytes.readUInt32LE(offset), bodyLength = bytes.readUInt32LE(offset + 4); offset += 8;
    if (!nameLength || nameLength > 4096 || bodyLength > 64 * 1024 * 1024 || offset + nameLength + bodyLength > bytes.length) throw new Error('Entrada inválida');
    const name = bytes.subarray(offset, offset + nameLength).toString('utf8'); offset += nameLength;
    if (name.includes('\0') || isAbsolute(name) || name.split(/[\\/]/).includes('..') || name.split(/[\\/]/)[0] === '' || /^[A-Za-z]:/.test(name)) throw new Error(`Ruta insegura: ${name}`);
    const normalized = name.split(/[\\/]/).join(sep), destination = resolve(target, normalized);
    if (!destination.startsWith(`${resolve(target)}${sep}`)) throw new Error(`Ruta fuera del destino: ${name}`);
    await mkdir(dirname(destination), { recursive: true, mode: 0o700 });
    await writeFile(destination, bytes.subarray(offset, offset + bodyLength), { mode: 0o600, flag: 'wx' }); await chmod(destination, 0o600); offset += bodyLength;
  }
}

export async function validarPayload(bytes, target) {
  await escribirPayload(bytes, target);
  const manifest = JSON.parse(await readFile(join(target, 'MANIFIESTO.json'), 'utf8'));
  if (manifest.formato !== 1 || !Array.isArray(manifest.archivos)) throw new Error('Manifiesto inválido');
  const declared = new Set();
  for (const item of manifest.archivos) {
    if (!item || typeof item.path !== 'string' || !/^[a-f0-9]{64}$/.test(item.sha256)) throw new Error('Entrada de manifiesto inválida');
    if (declared.has(item.path) || isAbsolute(item.path) || item.path.split(/[\\/]/).includes('..')) throw new Error('Ruta de manifiesto inválida'); declared.add(item.path);
    const path = resolve(target, item.path); if (!path.startsWith(`${resolve(target)}${sep}`) || await hashFile(path) !== item.sha256) throw new Error(`SHA-256 no coincide: ${item.path}`);
  }
  const actual = (await listFiles(target)).filter(path => path !== 'MANIFIESTO.json').sort();
  if (actual.length !== manifest.archivos.length || actual.some(path => !declared.has(path))) throw new Error('El paquete contiene archivos fuera del manifiesto');
  return manifest;
}

function hideInput(prompt) {
  return new Promise((resolvePrompt, reject) => {
    stdout.write(prompt);
    if (!stdin.isTTY) { reject(new Error('Se requiere una terminal interactiva para escribir la frase')); return; }
    const onData = chunk => {
      const value = String(chunk);
      if (value.includes('\n') || value.includes('\r')) {
        // Una frase pegada llega junto con el Enter en el mismo bloque: se conserva lo anterior al salto.
        answer += value.split(/[\r\n]/)[0];
        stdin.off('data', onData); stdin.setRawMode(false); stdin.pause(); stdout.write('\n'); resolvePrompt(answer);
      } else if (value === '\u0003') { stdin.off('data', onData); stdin.setRawMode(false); reject(new Error('Cancelado')); }
      else if (value === '\u007f' || value === '\b') answer = answer.slice(0, -1);
      else answer += value;
    };
    let answer = '';
    stdin.setRawMode(true); stdin.resume(); stdin.on('data', onData);
  });
}

async function phrase() {
  const value = await hideInput('Frase de cifrado: ');
  if (value.length < 12) throw new Error('La frase debe tener al menos 12 caracteres');
  return value;
}

async function hashFile(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

async function listFiles(dir, prefix = '') {
  const result = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const name = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isSymbolicLink()) throw new Error(`No se admiten enlaces simbólicos: ${name}`);
    if (entry.isDirectory()) result.push(...await listFiles(join(dir, entry.name), name));
    else if (entry.isFile()) result.push(name);
  }
  return result.sort();
}

async function makeSnapshot(temp) {
  const payload = join(temp, 'payload'); await mkdir(payload, { mode: 0o700 });
  const bundle = await readFile(join(root, 'scripts/bundle.mjs'), 'utf8');
  const match = bundle.match(/const files = (\[[\s\S]*?\]);/);
  if (!match) throw new Error('No se pudo leer la allowlist de scripts/bundle.mjs');
  const bundled = Function(`return ${match[1]}`)();
  const codeFiles = [...new Set([...bundled, ...SAFE_FILES, 'scripts/migrar.mjs'])].sort();
  for (const rel of codeFiles) {
    if (migracionExcluye(rel) || rel.startsWith('data/') || rel.startsWith('-')) continue;
    const src = join(root, rel); try { if (!(await lstat(src)).isFile()) continue; } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    const dst = join(payload, 'codigo', rel); await mkdir(dirname(dst), { recursive: true, mode: 0o700 });
    await writeFile(dst, await readFile(src), { mode: 0o600 });
  }
  for (const dir of ['memoria']) {
    const source = join(root, dir);
    for (const rel of await listFiles(source)) {
      const dst = join(payload, 'codigo', dir, rel); await mkdir(dirname(dst), { recursive: true, mode: 0o700 });
      await writeFile(dst, await readFile(join(source, rel)), { mode: 0o600 });
    }
  }
  const dataFiles = ['permitidos.json', 'permitidos.txt', '.clave-contactos', 'eval/casos-reales.json'];
  for (const rel of dataFiles) {
    const src = join(root, 'data', rel); try { await stat(src); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    const dst = join(payload, 'data', rel); await mkdir(dirname(dst), { recursive: true, mode: 0o700 }); await writeFile(dst, await readFile(src), { mode: 0o600 });
  }
  for (const dir of ['human', 'bandeja']) {
    const source = join(root, 'data', dir); try { await stat(source); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    for (const rel of await listFiles(source)) {
      const dst = join(payload, 'data', dir, rel); await mkdir(dirname(dst), { recursive: true, mode: 0o700 }); await writeFile(dst, await readFile(join(source, rel)), { mode: 0o600 });
    }
  }
  const dbPath = join(root, 'data/memoria.db');
  try {
    await stat(dbPath);
    const { DatabaseSync } = await import('node:sqlite');
    const db = new DatabaseSync(dbPath, { readOnly: true });
    const snapshot = join(payload, 'data/memoria.db'); await mkdir(dirname(snapshot), { recursive: true, mode: 0o700 });
    db.prepare('VACUUM INTO ?').run(snapshot); db.close(); await chmod(snapshot, 0o600);
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return { payload, codeFiles };
}

async function makeLearningSnapshot(temp) {
  const payload = join(temp, 'payload'); await mkdir(payload, { mode: 0o700 });
  const { DatabaseSync } = await import('node:sqlite');
  const sourcePath = join(root, 'data/memoria.db');
  try {
    await stat(sourcePath);
    const source = new DatabaseSync(sourcePath, { readOnly: true });
    const outPath = join(payload, 'data/memoria.db'); await mkdir(dirname(outPath), { recursive: true, mode: 0o700 });
    const out = new DatabaseSync(outPath);
    out.exec(`CREATE TABLE aprendizaje(creado TEXT,rol TEXT,mensaje TEXT,sugerido TEXT,final TEXT,accion TEXT);
      CREATE TABLE reglas(creado TEXT,habilidad TEXT,texto TEXT,origen_evento INTEGER,estado TEXT,decidido TEXT);
      CREATE TABLE eventos(creado TEXT,canal TEXT,habilidad TEXT,accion_propuesta TEXT,decision TEXT,texto_final_anon TEXT,resultado TEXT);
      CREATE TABLE notas(fecha TEXT,habilidad TEXT,puntos INTEGER,total INTEGER,validos INTEGER,falsos_abiertos INTEGER);`);
    const tables = new Set(source.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(x => x.name));
    for (const [name, cols] of [['aprendizaje','creado,rol,mensaje,sugerido,final,accion'],['reglas','creado,habilidad,texto,origen_evento,estado,decidido'],['eventos','creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado'],['notas','fecha,habilidad,puntos,total,validos,falsos_abiertos']]) {
      if (!tables.has(name)) continue;
      const rows = source.prepare(`SELECT ${cols} FROM ${name}`).all();
      const placeholders = cols.split(',').map(() => '?').join(','); const insert = out.prepare(`INSERT INTO ${name} VALUES(${placeholders})`);
      for (const row of rows) insert.run(...cols.split(',').map(c => row[c] ?? null));
    }
    out.close(); source.close(); await chmod(outPath, 0o600);
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const cases = join(root, 'data/eval/casos-reales.json');
  try { await stat(cases); const dst=join(payload,'data/eval/casos-reales.json'); await mkdir(dirname(dst),{recursive:true,mode:0o700}); await writeFile(dst,await readFile(cases),{mode:0o600}); } catch(error) { if(error.code!=='ENOENT') throw error; }
  return payload;
}

async function exportPackage(output, passphrase, learningOnly = false) {
  const temp = await mkdtemp(join(root, '.migrar-'));
  try {
    const payload = learningOnly ? await makeLearningSnapshot(temp) : (await makeSnapshot(temp)).payload;
    const files = await listFiles(payload), entries = [];
    for (const path of files) entries.push({ path, sha256: await hashFile(join(payload, path)) });
    let commit = 'desconocido';
    try { const { execFileSync } = await import('node:child_process'); commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch { /* paquete exportable fuera de Git */ }
    const manifest = { formato: 1, tipo: learningOnly ? 'solo-aprendizaje' : 'completo', version: JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).version, commit, fecha: new Date().toISOString(), archivos: entries };
    await writeFile(join(payload, 'MANIFIESTO.json'), `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600 });
    const plaintext = await packDirectory(payload), result = await cifrarPaquete(plaintext, passphrase);
    await mkdir(dirname(resolve(output)), { recursive: true, mode: 0o700 }); await writeFile(resolve(output), result, { mode: 0o600, flag: 'wx' }); await chmod(resolve(output), 0o600);
    console.log(`Exportado: ${resolve(output)} (${entries.length} archivos)`);
  } finally { await rm(temp, { recursive: true, force: true }); }
}

async function packDirectory(dir) {
  const files = await listFiles(dir), parts = [Buffer.from('AMPPAY1\0')];
  for (const path of files) { const name = Buffer.from(path), body = await readFile(join(dir, path)); const head = Buffer.alloc(8); head.writeUInt32LE(name.length, 0); head.writeUInt32LE(body.length, 4); parts.push(head, name, body); }
  return Buffer.concat(parts);
}

async function unpackDirectory(bytes, target) {
  await escribirPayload(bytes, target);
}

async function decrypt(file, passphrase) {
  return descifrarPaquete(await readFile(file), passphrase);
}

async function validatePayload(bytes, temp) {
  const staged = join(temp, 'staged'); await mkdir(staged, { mode: 0o700 });
  const manifest = await validarPayload(bytes, staged);
  return { staged, manifest };
}

async function verify(file, passphrase) {
  const bytes = await decrypt(file, passphrase), temp = await mkdtemp(join(root, '.migrar-'));
  try { const { manifest } = await validatePayload(bytes, temp); console.log(JSON.stringify(manifest, null, 2)); }
  finally { await rm(temp, { recursive: true, force: true }); }
}

export async function importarValidado(bytes, destination, force = false) {
  const temp = await mkdtemp(join(tmpdir(), 'local-agent-import-'));
  try {
    const { staged } = await validatePayload(bytes, temp), target = resolve(destination);
    await mkdir(target, { recursive: true, mode: 0o700 }); await chmod(target, 0o700);
    const dataTarget = join(target, 'data'); let existingData = false;
    try { await stat(dataTarget); existingData = true; } catch (error) { if (error.code !== 'ENOENT') throw error; }
    if (existingData && !force) throw new Error('Ya existe data/; use --forzar para incorporar archivos (sin borrar datos ajenos)');
    for (const [area, payloadPrefix] of [['codigo', 'codigo'], ['data', 'data']]) {
      const from = join(staged, payloadPrefix); try { await stat(from); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
      for (const rel of await listFiles(from)) {
        const dst = area === 'codigo' ? join(target, rel) : join(target, 'data', rel); await mkdir(dirname(dst), { recursive: true, mode: 0o700 }); await chmod(dirname(dst), 0o700);
        let exists = false; try { await stat(dst); exists = true; } catch (error) { if (error.code !== 'ENOENT') throw error; }
        if (exists && area === 'codigo' && force) continue;
        if (exists && !(area === 'data' && force)) throw new Error(`El archivo ya existe: ${dst}`);
        if (exists && area === 'data' && force) {
          const tempFile = `${dst}.migracion-nueva-${randomBytes(6).toString('hex')}`; await writeFile(tempFile, await readFile(join(from, rel)), { mode: 0o600, flag: 'wx' });
          const { rename } = await import('node:fs/promises'); await rename(tempFile, dst); await chmod(dst, 0o600);
        } else { await writeFile(dst, await readFile(join(from, rel)), { mode: 0o600, flag: 'wx' }); await chmod(dst, 0o600); }
      }
    }
    const env = join(target, '.env'); try { await stat(env); } catch (error) { if (error.code !== 'ENOENT') throw error; const example = join(target, '.env.example'); await writeFile(env, await readFile(example), { mode: 0o600, flag: 'wx' }); await chmod(env, 0o600); }
    await chmod(target, 0o700);
    return target;
  } finally { await rm(temp, { recursive: true, force: true }); }
}

async function importPackage(file, destination, force, passphrase) {
  const bytes = await decrypt(file, passphrase), temp = await mkdtemp(join(root, '.migrar-'));
  try {
    const target = await importarValidado(bytes, destination, force);
    console.log(`Importación verificada y aplicada en ${target}. Pasos pendientes:\n1. Completar .env con LOCAL_AGENT_TOKEN nuevo del panel (no copiar el anterior).\n2. Ejecutar npm run doctor.\n3. Ejecutar npm run puente y vincular el QR con el teléfono oficial.\n4. Ejecutar npm run operador.\n5. Desactivar el equipo antiguo antes de operar.`);
  } finally { await rm(temp, { recursive: true, force: true }); }
}

const fingerprint = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
export async function fusionarAprendizaje(staged, destination) {
  const { DatabaseSync } = await import('node:sqlite');
  const srcPath=join(staged,'data/memoria.db'), dstPath=join(destination,'data/memoria.db');
  await mkdir(dirname(dstPath),{recursive:true,mode:0o700});
  const dst=new DatabaseSync(dstPath);
  dst.exec(`CREATE TABLE IF NOT EXISTS aprendizaje(id INTEGER PRIMARY KEY,creado TEXT NOT NULL,rol TEXT NOT NULL,mensaje TEXT NOT NULL,sugerido TEXT NOT NULL,final TEXT NOT NULL,accion TEXT NOT NULL);
    CREATE VIRTUAL TABLE IF NOT EXISTS aprendizaje_fts USING fts5(mensaje,sugerido,final,tokenize='unicode61 remove_diacritics 2');
    CREATE TABLE IF NOT EXISTS reglas(id INTEGER PRIMARY KEY,creado TEXT NOT NULL,habilidad TEXT NOT NULL,texto TEXT NOT NULL,origen_evento INTEGER,estado TEXT NOT NULL,decidido TEXT);
    CREATE TABLE IF NOT EXISTS eventos(id INTEGER PRIMARY KEY,creado TEXT NOT NULL,canal TEXT NOT NULL,habilidad TEXT NOT NULL,accion_propuesta TEXT NOT NULL,decision TEXT NOT NULL,texto_final_anon TEXT NOT NULL,resultado TEXT,clave_contacto_hmac TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS notas(fecha TEXT NOT NULL,habilidad TEXT NOT NULL,puntos INTEGER NOT NULL,total INTEGER NOT NULL,validos INTEGER NOT NULL,falsos_abiertos INTEGER NOT NULL,PRIMARY KEY(fecha,habilidad));`);
  const counts={aprendizaje:0,reglas:0,eventos:0,notas:0,casos:0};
  if (await stat(srcPath).then(()=>true,()=>false)) {
    const src=new DatabaseSync(srcPath,{readOnly:true}); dst.exec('BEGIN IMMEDIATE');
    try {
      for(const row of src.prepare('SELECT creado,rol,mensaje,sugerido,final,accion FROM aprendizaje').all()) {
        const key=fingerprint(row), have=dst.prepare('SELECT creado,rol,mensaje,sugerido,final,accion FROM aprendizaje').all().some(x=>fingerprint(x)===key);
        if(!have){ const id=dst.prepare('INSERT INTO aprendizaje(creado,rol,mensaje,sugerido,final,accion) VALUES(?,?,?,?,?,?)').run(...Object.values(row)).lastInsertRowid; dst.prepare('INSERT INTO aprendizaje_fts(rowid,mensaje,sugerido,final) VALUES(?,?,?,?)').run(id,row.mensaje,row.sugerido,row.final); counts.aprendizaje++; }
      }
      const rank={propuesta:1,aprobada:2,rechazada:3};
      for(const row of src.prepare('SELECT creado,habilidad,texto,origen_evento,estado,decidido FROM reglas').all()) {
        const textHash=createHash('sha256').update(row.texto.trim().normalize('NFKC')).digest('hex'); const existing=dst.prepare('SELECT id,estado FROM reglas WHERE habilidad=?').all(row.habilidad).find(x=>createHash('sha256').update(dst.prepare('SELECT texto FROM reglas WHERE id=?').get(x.id).texto.trim().normalize('NFKC')).digest('hex')===textHash);
        if(!existing){dst.prepare('INSERT INTO reglas(creado,habilidad,texto,origen_evento,estado,decidido) VALUES(?,?,?,?,?,?)').run(...Object.values(row));counts.reglas++;}
        else if((rank[row.estado]??0)>(rank[existing.estado]??0)){dst.prepare('UPDATE reglas SET estado=?,decidido=? WHERE id=?').run(row.estado,row.decidido,existing.id);}
      }
      for(const row of src.prepare('SELECT creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado FROM eventos').all()) {
        const key=fingerprint(row), exists=dst.prepare('SELECT creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado FROM eventos').all().some(x=>fingerprint(x)===key);
        if(!exists){dst.prepare('INSERT INTO eventos(creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado,clave_contacto_hmac) VALUES(?,?,?,?,?,?,?,\'\')').run(...Object.values(row));counts.eventos++;}
      }
      for(const row of src.prepare('SELECT fecha,habilidad,puntos,total,validos,falsos_abiertos FROM notas').all()) {
        const old=dst.prepare('SELECT puntos,total,validos,falsos_abiertos FROM notas WHERE fecha=? AND habilidad=?').get(row.fecha,row.habilidad);
        if(!old){dst.prepare('INSERT INTO notas VALUES(?,?,?,?,?,?)').run(...Object.values(row));counts.notas++;}
        else if(fingerprint(row)!==fingerprint({fecha:row.fecha,habilidad:row.habilidad,...old})) dst.prepare('UPDATE notas SET puntos=?,total=?,validos=?,falsos_abiertos=? WHERE fecha=? AND habilidad=?').run(row.puntos,row.total,row.validos,row.falsos_abiertos,row.fecha,row.habilidad);
      }
      dst.exec('COMMIT');
    } catch(error){dst.exec('ROLLBACK');throw error;} finally {src.close();}
  }
  const casesFile=join(staged,'data/eval/casos-reales.json'), targetCases=join(destination,'data/eval/casos-reales.json');
  let incoming=[];try{incoming=JSON.parse(await readFile(casesFile,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
  let current=[];try{current=JSON.parse(await readFile(targetCases,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
  const seen=new Set(current.map(fingerprint));for(const item of incoming)if(!seen.has(fingerprint(item))){current.push(item);seen.add(fingerprint(item));counts.casos++;}
  if(counts.casos){await mkdir(dirname(targetCases),{recursive:true,mode:0o700});await writeFile(targetCases,`${JSON.stringify(current,null,2)}\n`,{mode:0o600});await chmod(targetCases,0o600);}
  dst.close(); await chmod(dstPath,0o600);
  let learned='';try{learned=await readFile(join(destination,'memoria/aprendidas.md'),'utf8');}catch{}
  const d=new DatabaseSync(dstPath,{readOnly:true});const pending=d.prepare("SELECT habilidad,texto FROM reglas WHERE estado='aprobada'").all().filter(r=>!learned.includes(r.texto));d.close();
  console.log(`Fusión de aprendizaje: ${JSON.stringify(counts)}. Reglas aprobadas pendientes de memoria/aprendidas.md:`);
  for(const rule of pending)console.log(`- [${rule.habilidad}] ${rule.texto}`);
  return {counts,pending};
}

async function importLearningPackage(file,destination,passphrase){
  const bytes=await decrypt(file,passphrase),temp=await mkdtemp(join(root,'.migrar-'));
  try{const {staged,manifest}=await validatePayload(bytes,temp);if(manifest.tipo!=='solo-aprendizaje')throw new Error('El paquete no es de solo aprendizaje');await fusionarAprendizaje(staged,resolve(destination));}
  finally{await rm(temp,{recursive:true,force:true});}
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [action, ...args] = process.argv.slice(2);
  try {
    if (action === 'exportar' && args.length === 1) await exportPackage(args[0], await phrase());
    else if (action === 'exportar' && args.length === 2 && args[0] === '--solo-aprendizaje') await exportPackage(args[1], await phrase(), true);
    else if (action === 'verificar' && args.length === 1) await verify(args[0], await phrase());
    else if (action === 'importar' && args.length === 3 && args[0] === '--fusionar') await importLearningPackage(args[1],args[2],await phrase());
    else if (action === 'importar' && args.length >= 2 && args.length <= 3) await importPackage(args[0], args[1], args[2] === '--forzar', await phrase());
    else { console.error('Uso: node scripts/migrar.mjs exportar [--solo-aprendizaje] <salida.ampkg> | importar [--fusionar] <archivo.ampkg> <carpeta-destino> [--forzar] | verificar <archivo.ampkg>'); process.exitCode = 2; }
  } catch (error) { console.error(`Error: ${error.message}`); process.exitCode = 1; }
}
