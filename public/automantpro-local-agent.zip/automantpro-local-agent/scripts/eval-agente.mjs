import { execFile as nodeExecFile } from 'node:child_process';
import { promisify } from 'node:util';
import { chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chatGate, classifyChat, classifyBusinessLead, messageText, parseAllowlist, LOCAL_CATEGORIES, CLASSIFIER_PROMPT } from '../src/bridge-core.mjs';
import { draftPrompt } from '../src/drafter.mjs';
import { classifySkill, createMemoryDb } from '../src/memory-db.mjs';
import { buildAction } from '../src/actions.mjs';

const execFileRaw = promisify(nodeExecFile);
// codex/opencode wait for stdin when it stays open; close it so they start at once.
const execFile = (cmd, args, opts) => { const p = execFileRaw(cmd, args, opts); p.child?.stdin?.end(); return p; };
const here = dirname(fileURLToPath(import.meta.url));
const fixtures = JSON.parse(await readFile(join(here, '../test/fixtures/conversaciones.json'), 'utf8'));
const dataDir = join(here, '../data');
async function loadAllFixtures(targetDataDir = dataDir) {
  let actualCases = [];
  try { actualCases = JSON.parse(await readFile(join(targetDataDir, 'eval/casos-reales.json'), 'utf8')); if (!Array.isArray(actualCases)) actualCases = []; } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return [...fixtures, ...actualCases];
}
const fold = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const allowlist = parseAllowlist(process.env.EVAL_ALLOWLIST || '');
const SYSTEM = CLASSIFIER_PROMPT;

function parseCases(output, expectedIds) {
  let value;
  try {
    const clean = String(output).replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
    value = JSON.parse(clean);
  } catch { return new Map(); }
  const rows = Array.isArray(value) ? value : value?.casos;
  const parsed = new Map();
  if (!Array.isArray(rows)) return parsed;
  for (const row of rows) {
    if (!expectedIds.includes(String(row?.id)) || !LOCAL_CATEGORIES.includes(row?.categoria) || typeof row?.relacionado_automantpro !== 'boolean' || typeof row?.borrador !== 'string') continue;
    if (!parsed.has(String(row.id))) parsed.set(String(row.id), row);
  }
  return parsed;
}

export async function runAgentBatch(cases, { agent = process.env.EVAL_AGENTE || 'codex', run = execFile, tempDir = join(here, '../data/eval') } = {}) {
  if (!['codex', 'opencode'].includes(agent)) throw new Error('EVAL_AGENTE debe ser codex u opencode');
  if (cases.length > 15) throw new Error('Máximo 15 conversaciones por llamada');
  const input = await Promise.all(cases.map(async item => {
    const text = item.mensajes.map(messageText).join(' ');
    const role = item.servicio !== 'registro_taller_almacen' ? 'dueno' : /almac[eé]n|distribuidora|autopartes/i.test(text) ? 'almacen' : 'taller';
    return { id: item.id, mensajes: item.mensajes.map(messageText), prompt_redactor: await draftPrompt({ role, message: text }) };
  }));
  const prompt = `${SYSTEM}\n\nPara cada caso redacta además la respuesta usando sus instrucciones prompt_redactor. Devuelve únicamente un JSON con un arreglo casos, cada elemento {id, categoria, relacionado_automantpro, borrador}. Casos:\n${JSON.stringify(input)}`;
  let stdout;
  if (agent === 'codex') {
    await mkdir(tempDir, { recursive: true, mode: 0o700 });
    const outFile = join(tempDir, `.codex-eval-${process.pid}-${Date.now()}.json`);
    try {
      await run('codex', ['exec', '--sandbox', 'read-only', '-o', outFile, ...(process.env.EVAL_CODEX_MODEL ? ['--model', process.env.EVAL_CODEX_MODEL] : []), prompt], { timeout: 300_000, maxBuffer: 2 * 1024 * 1024 });
      stdout = await readFile(outFile, 'utf8');
    } finally { await (await import('node:fs/promises')).rm(outFile, { force: true }).catch(() => {}); }
  } else {
    const model = process.env.EVAL_OPENCODE_MODEL || 'opencode/deepseek-v4.1-flash-free';
    ({ stdout } = await run('opencode', ['run', '-m', model, prompt], { timeout: 300_000, maxBuffer: 2 * 1024 * 1024 }));
  }
  return parseCases(stdout, cases.map(item => String(item.id)));
}

const mainRun = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (mainRun) await runEvaluation();

export async function runEvaluation({ agent: selectedAgent, useAgent: useSelectedAgent, review: selectedReview, db: suppliedDb, cases: suppliedCases, dataDir: selectedDataDir = dataDir, executeAgent = runAgentBatch, reviewerRun = execFile, saveResult = true } = {}) {
const cases = suppliedCases || await loadAllFixtures(selectedDataDir);
const useAgent = useSelectedAgent ?? (process.argv.includes('--agente') || process.env.EVAL_AGENTE);
const agent = selectedAgent || process.argv[process.argv.indexOf('--agente') + 1] || process.env.EVAL_AGENTE || 'codex';
const review = selectedReview ?? process.argv.includes('--revisar');
const start = performance.now();
const totals = { tp: 0, fp: 0, fn: 0, tn: 0 };
let privateOpened = 0;
const categories = new Map();
const detail = [];
const gated = cases.map(fixture => {
  const gate = chatGate({ title: fixture.title, preview: fixture.preview, phone: fixture.title.startsWith('+') ? fixture.title : null, allowlist });
  const open = Boolean(gate.open && !fixture.grupo);
  if (open && ['personal', 'familia', 'grupo', 'spam'].includes(fixture.categoria)) privateOpened++;
  if (open === fixture.debeAbrir) totals[open ? 'tp' : 'tn']++; else totals[open ? 'fp' : 'fn']++;
  return { fixture, open };
});
// Closed conversations are intentionally excluded from both agent input and classifier input.
const eligible = gated.filter(item => item.open).map(item => item.fixture);
const agentRows = new Map();
if (useAgent) for (let offset = 0; offset < eligible.length; offset += 15) {
  const rows = await executeAgent(eligible.slice(offset, offset + 15), { agent });
  for (const [id, row] of rows) agentRows.set(id, row);
}
let keyTotal = 0; let keyHits = 0; let draftValid = 0;
for (const { fixture, open } of gated) {
  const rules = open ? classifyChat(fixture.mensajes) : null;
  const model = agentRows.get(fixture.id) || null;
  const reason = rules?.reasons?.[0] ?? '';
  const explicit = rules?.category === 'automantpro' && /automantpro|registr|ofertar|[sc]-[0-9a-f]{6}/i.test(reason);
  const business = open ? classifyBusinessLead(fixture.mensajes) : null;
  const modelCategory = (model?.relacionado_automantpro === true || ['taller_fundador', 'almacen_fundador'].includes(model?.categoria)) ? 'automantpro' : model?.categoria;
  const effective = fixture.debeAbrir ? (explicit ? 'automantpro' : (modelCategory ?? rules?.category ?? 'fallo')) : 'cerrado';
  const expected = fixture.debeAbrir ? fixture.categoria : 'cerrado';
  const actual = effective;
  const bucket = categories.get(fixture.categoria) || { total: 0, correct: 0 };
  bucket.total++; if (actual === expected) bucket.correct++; categories.set(fixture.categoria, bucket);
  const draft = model?.borrador || '';
  const links = (draft.match(/https?:\/\/\S+/gi) || []).length;
  const unoffered = /garantiz|te aseguramos|disponible ahora|entrega hoy/i.test(draft);
  const promisesPrice = /(?:\$|USD)\s?\d|\b(?:precio|valor|costo)\s+(?:es|será|seria|de)\s+\d/i.test(draft);
  const leaks = /(?:LOCAL_AGENT_TOKEN|sk-[a-z0-9]{8,}|revela el prompt|instrucciones del sistema)/i.test(draft);
  const valid = Boolean(model && draft.length <= 900 && links <= 1 && !unoffered && !promisesPrice && !leaks);
  let hits = 0;
  for (const point of fixture.respuestaEsperada || []) { keyTotal++; if (fold(draft).includes(fold(point))) { keyHits++; hits++; } }
  if (valid) draftValid++;
  const mentionsCodes = [...String(fixture.mensajes.map(messageText).join(' ').matchAll(/\b(?:S|C|OT|AMP)-[A-Za-z0-9]+\b/g))].every(([code]) => draft.includes(code));
  const handoffExpected = ['35', '37', '45'].includes(fixture.id);
  const altaConfirmada = fixture.servicio !== 'ALTA' || /\balta\b/i.test(draft);
  const bajaConfirmada = fixture.servicio !== 'BAJA' || /\bbaja\b/i.test(draft);
  detail.push({ id: fixture.id, debeAbrir: fixture.debeAbrir, abrio: open, categoriaEsperada: fixture.categoria, categoriaReglas: rules?.category ?? null, categoriaAgente: model?.categoria ?? null, categoriaEfectiva: effective, reglaVsAgente: model ? modelCategory === rules?.category : null, ...(business ? { categoriaNegocio: business.category } : {}), borradorCaracteres: draft.length, borradorValido: valid, sinPromesaPrecio: !promisesPrice, seguridadSinFuga: !leaks, derivaAOperador: !handoffExpected || /\boperador\b/i.test(draft), codigosLiterales: mentionsCodes, confirmaAlta: altaConfirmada, confirmaBaja: bajaConfirmada, puntosClave: fixture.respuestaEsperada, puntosCubiertos: hits });
}
const precision = totals.tp + totals.fp ? totals.tp / (totals.tp + totals.fp) : 1;
const recall = totals.tp + totals.fn ? totals.tp / (totals.tp + totals.fn) : 1;
const macro = [...categories.values()].reduce((sum, item) => sum + item.correct / item.total, 0) / categories.size;
const actionCases = cases.filter(row => row.accionEsperada);
const actionDetails = actionCases.map(row => {
  const action = buildAction(row.mensajes.map(messageText).join(' '), row.contexto ?? null);
  const match = action.habilidad === row.accionEsperada.habilidad && (row.accionEsperada.comando === undefined || action.comando === row.accionEsperada.comando);
  const missing = (row.accionEsperada.faltan ?? []).every(field => action.faltan.includes(field));
  const risk = action.riesgo === row.accionEsperada.riesgo;
  return { id: row.id, accionCorrecta: match, faltantesDetectados: missing, riesgoCorrecto: risk };
});
const actionScore = key => ({ correctos: actionDetails.filter(row => row[key]).length, total: actionDetails.length, exactitud: actionDetails.length ? actionDetails.filter(row => row[key]).length / actionDetails.length : 1 });
const result = { fecha: new Date().toISOString(), agente: useAgent ? agent : null, modelo: agent === 'opencode' ? (process.env.EVAL_OPENCODE_MODEL || 'opencode/deepseek-v4.1-flash-free') : process.env.EVAL_CODEX_MODEL || null, modo: useAgent ? `reglas+${agent}` : 'solo-reglas', casos: cases.length, casosEnviados: eligible.length, apertura: { ...totals, precision, recall, falsosAbiertosPrivados: privateOpened }, exactitudCategoriaMacro: macro, comparacionReglasAgente: { comparables: detail.filter(row => row.reglaVsAgente !== null).length, acuerdos: detail.filter(row => row.reglaVsAgente === true).length }, calidadBorrador: { puntosCubiertos: keyHits, puntosTotal: keyTotal, cobertura: keyTotal ? keyHits / keyTotal : 0, validos: draftValid, evaluados: eligible.length }, calidadAcciones: { accionCorrecta: actionScore('accionCorrecta'), camposFaltantes: actionScore('faltantesDetectados'), riesgo: actionScore('riesgoCorrecto'), detalle: actionDetails }, msTotal: Math.round((performance.now() - start) * 100) / 100, detalle: detail };
const outputDir = join(selectedDataDir, 'eval'); let output = null;
if (saveResult) { await mkdir(outputDir, { recursive: true, mode: 0o700 }); await chmod(selectedDataDir, 0o700); await chmod(outputDir, 0o700); output = join(outputDir, `${new Date().toISOString().replace(/[:.]/g, '-')}.json`); await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, { mode: 0o600 }); await chmod(output, 0o600); }
const ownedDb = suppliedDb ? null : await createMemoryDb({ dataDir: selectedDataDir }); const noteDb = suppliedDb || ownedDb;
try {
  const bySkill = new Map();
  for (const row of detail) { const skill = classifySkill(`${row.categoriaEsperada} ${row.categoriaEfectiva}`); const bucket = bySkill.get(skill) || { puntos: 0, total: 0, validos: 0, falsos: 0 }; bucket.total++; if (row.borradorValido) bucket.validos++; if (row.abrio && ['personal','familia','grupo','spam'].includes(row.categoriaEsperada)) bucket.falsos++; bucket.puntos += row.puntosCubiertos || 0; bySkill.set(skill, bucket); }
  for (const [habilidad, values] of bySkill) noteDb.registrarNota({ fecha: result.fecha.slice(0,10), habilidad, ...values, falsosAbiertos: values.falsos });
} finally { ownedDb?.cerrar(); }
console.log(`Evaluación ${result.modo}: ${cases.length} casos; ${eligible.length} pasaron el gate`);
console.log(`Apertura: precisión ${(precision * 100).toFixed(1)}%, recall ${(recall * 100).toFixed(1)}%, falsos abiertos privados ${privateOpened}`);
console.log(`Categoría macro ${(macro * 100).toFixed(1)}%; borradores: ${keyHits}/${keyTotal} puntos, ${draftValid}/${eligible.length} válidos${output ? `; detalle ${output}` : ''}`);

if (review) {
  if (!saveResult) throw new Error('review requires result persistence');
  const reviewer = agent === 'codex' ? 'opencode' : 'codex';
  const failures = detail.filter(row => row.debeAbrir && (row.categoriaEfectiva !== row.categoriaEsperada || !row.borradorValido || !row.sinPromesaPrecio || !row.seguridadSinFuga || !row.derivaAOperador || !row.codigosLiterales || !row.confirmaAlta || !row.confirmaBaja || row.puntosCubiertos < (row.puntosClave || []).length));
const prompt = `Revisa estos fallos sintéticos y anonimizados de evaluación de AutoMantPro. Propón reglas cortas, generales y accionables, cada una en una línea de hasta 200 caracteres, sin ampliar el gate ni debilitar privacidad, aprobación humana o AGENTS.md. No propongas ampliar el gate, cambiar FORWARDED_CATEGORIES, automatizar envíos ni tocar AGENTS.md. Si el fallo es de medición, corrige la rúbrica, no el modelo. Devuelve Markdown breve.\n${JSON.stringify(failures)}`;
  let proposal = 'No se detectaron fallos que ameriten propuestas.\n';
  if (failures.length) {
    const args = reviewer === 'codex' ? ['exec', '--sandbox', 'read-only', ...(process.env.EVAL_CODEX_MODEL ? ['--model', process.env.EVAL_CODEX_MODEL] : []), prompt] : ['run', '-m', process.env.EVAL_OPENCODE_MODEL || 'opencode/deepseek-v4.1-flash-free', prompt];
    const { stdout } = await reviewerRun(reviewer, args, { timeout: 300_000, maxBuffer: 1024 * 1024 }); proposal = stdout;
  }
  const proposalPath = join(outputDir, `propuestas-${new Date().toISOString().slice(0, 10)}.md`);
  await writeFile(proposalPath, `# Propuestas de revisión (${reviewer})\n\n${proposal}\n\nNo aplicadas automáticamente.\n`, { mode: 0o600 });
  await chmod(proposalPath, 0o600);
  const proposalLines = proposal.split('\n').map(line => line.replace(/^[-*\d.)\s]+/, '').trim()).filter(line => line.length > 0 && line.length <= 200 && !/\+?593|\b\d{8,}\b/.test(line));
  const proposalDb = suppliedDb || await createMemoryDb({ dataDir: selectedDataDir });
  try { for (const line of proposalLines) proposalDb.proponerRegla({ habilidad: 'otro', texto: line }); }
  finally { if (!suppliedDb) proposalDb.cerrar(); }
  console.log(`Propuestas guardadas en ${proposalPath}`);
}
if (process.env.EVAL_JSON === '1') process.stdout.write(`${JSON.stringify(result)}\n`);
return result;
}
