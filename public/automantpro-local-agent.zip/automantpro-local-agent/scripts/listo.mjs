// Comprueba que servidor, puente y redactores (Claude, opencode, Ollama) estén listos y lo deja en data/estado-agentes.json.
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createClient } from '../src/client.mjs';
import { DEFAULT_CHAIN, drafterChainFromEnv } from '../src/drafter.mjs';
import { checkReadiness, summarizeReadiness, writeReadiness } from '../src/readiness.mjs';

try {
  const info = await stat(resolve('.env'));
  if (process.platform !== 'win32' && (info.mode & 0o077)) throw Object.assign(new Error('ENV_PERMISSIONS_REQUIRE_0600'), { code: 'ENV_PERMISSIONS_REQUIRE_0600' });
  process.loadEnvFile(resolve('.env'));
} catch (error) { if (error.code !== 'ENOENT') { process.stderr.write(`${error.code}\n`); process.exit(1); } }
let client = null;
try { client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN }); } catch { /* Reported as servidor ✘. */ }
const kinds = drafterChainFromEnv().length ? drafterChainFromEnv() : [...DEFAULT_CHAIN];
const estado = await checkReadiness({ client, kinds });
await writeReadiness(estado);
process.stdout.write(`${summarizeReadiness(estado)}\n${JSON.stringify(estado, null, 2)}\n`);
process.exitCode = estado.listo ? 0 : 1;
