# Inventario de comandos del servidor

Hechos del código en `packages/api`; el endpoint de marketplace requiere autenticación y cabecera `Idempotency-Key`.

## Registro
Regla (Pedro, 31/10/2026): analizar el texto libre; la gente puede no escribir la opción ni el comando. "Tengo un taller en Quito" ya indica perfil taller y ciudad: se piden solo los datos que faltan, sin exigir el formato con barras. Siempre se invita a responder con sus palabras.
Regla (Pedro, 31/10/2026): si alguien quiere registrarse y no dijo su perfil, primero se le pide elegir el perfil (1. dueño de vehículo, 2. taller, 3. almacén de repuestos) mostrando el comando de cada uno. Solo si ya dijo su perfil se da únicamente su comando.
Siempre que se explique ACEPTO, incluir el enlace https://automantpro.app/terminos (desde ahí se enlaza el tratamiento de datos en /privacidad). Solo ese enlace: el modo humano permite 1 enlace por mensaje.
Dueño: `Registrarme | nombre y apellido | ciudad | ACEPTO`.
Taller: `Registrar taller | nombre comercial | RUC | ciudad | sector | dirección | servicios | ACEPTO`.
Almacén: `Registrar almacén | nombre comercial | RUC | ciudad | sector | dirección | categorías | ACEPTO`.
ACEPTO expresa aceptación de términos y tratamiento de datos (LOPDP).

## Chat de marketplace: `POST /local-marketplace/chat`

El cuerpo exacto es `{ "message": "..." }`. El parser acepta estas formas (`src/application/local-marketplace/chat.ts`):

- `Buscar servicio | categoría | ciudad | sector | descripción` y `Buscar repuesto | categoría | ciudad | sector | descripción`. Forma completa alternativa antepone el ID del vehículo después de `|`; la forma corta se limita a solicitudes del usuario autenticado.
- `Ofertas` o `Ofertas S-XXXXXX`.
- `Aceptar 2` (posición 1–5 de ofertas propias) o `Aceptar S-XXXXXX 2`; forma larga `Aceptar | solicitud UUID | oferta UUID`.
- `Cancelar` o `Cancelar S-XXXXXX`; forma larga `Cancelar | solicitud UUID`.
- `Invitaciones`.
- `Ofertar S-XXXXXX | precio USD | minutos | AAAA-MM-DD | HH:mm | notas`; opcionales: marca, calidad (`original`, `alterno`, `usado`), garantía en días. Admite forma larga con ID de solicitud UUID tras `Ofertar |`.
- `Citas` y `Confirmar C-XXXXXX`; forma larga `Confirmar cita | solicitud UUID | cita UUID`.
- Almacén: `Stock S-XXXXXX | sí | AAAA-MM-DD` o `Stock S-XXXXXX | no | motivo`.

Los códigos cortos son S- más seis hexadecimales para solicitudes/ofertas y C- más seis hexadecimales para citas; las formas cortas se resuelven en el ámbito del remitente. Los errores de sintaxis/schema responden 422 con `INVALID_CHAT_COMMAND`/`VALIDATION_ERROR`; no encontrado 404, falta de autorización/consentimiento 403, conflictos 409 y ocupado 503. El servidor devuelve `{ data, error: null }` al ejecutar con éxito; el detalle de cada operación lo produce el store. Origen: `src/interfaces/local-marketplace.routes.ts`, `src/application/local-marketplace/chat.ts`, `src/application/local-marketplace/contracts.ts`.

## Otros comandos de cuenta

El parser `src/application/chat-account/commands.ts` admite comandos de registro, vehículo, flota, órdenes, visitas y convenios, además de mensajes de cita, entre otros. No se enumeran aquí los formatos: este inventario de fase 4 cubre el marketplace local operado con EJECUTAR; cada parser mantiene sus propias reglas.

## Límites comprobados

No hay comando de consulta ni registro de historial de servicios en `local-marketplace/chat.ts` ni en `local-marketplace/contracts.ts`. Tampoco hay un comando de crear plan de mantenimiento en ese contrato. El contrato sí tiene solicitudes de servicio/repuesto, ofertas, aceptación, cancelación y citas; no extrapolar estos a historial o plan.

## Comandos agregados en noviembre de 2026

Hechos de `packages/api/src/application/chat-account/commands.ts`.

- Perfil y vehículo: `Mis datos`, `Corregir vehículo`.
- Negocio: `Mi taller`, `Mi almacén`, `Editar taller`, `Editar almacén`.
- Inspección: `Checklist C-XXXXXX`, `Inspección C-XXXXXX | M1 ok; F2 2,5 mm; resto ok` (taller) e `Inspección` (dueño).
- Flota: `Flota` y `Vencidos` cuentan aparte los vehículos sin historial. Editarlos sigue siendo con `Último servicio`.

Consulta el formato exacto en el parser antes de proponer un comando con campos.
