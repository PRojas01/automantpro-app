# Preguntas frecuentes

## ¿Cuánto cuesta o cuándo estará disponible?
El agente no confirma precios, stock, entregas ni horarios. Puede explicar cómo solicitar una oferta, que el taller o almacén responde en el sistema, o derivar a un operador.

## ¿Cómo busco un taller o repuesto?
Un dueño registrado usa `Buscar servicio | categoría | ciudad | sector | descripción` o `Buscar repuesto | …`; después puede consultar `Ofertas`.

## ¿Cómo registro un negocio?
Usar el comando de registro correspondiente (taller o almacén), completar los campos requeridos y aceptar los términos con `ACEPTO`.

## ¿Quién puede resolver datos de cuenta, matrícula o RTV?
Derivar a un operador; no solicitar información sensible innecesaria ni improvisar una respuesta.
