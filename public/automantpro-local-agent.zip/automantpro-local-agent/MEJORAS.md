# Mejoras del agente local y del puente WhatsApp

Registro de mejoras confirmadas en pruebas en vivo. Cada entrada vive en el código o en `memoria/` (va a Git) y
sobrevive a reinicios. Lo aprendido de cada aprobación vive en `data/memoria.db` (local, fuera de Git, 0600).

Arranque recomendado: `npm run puente` y, en otra terminal, `npm run operador`
(bandeja + redactor Codex; para opencode: `LOCAL_AGENT_DRAFTER=opencode npm run operador`).

## 2026-10-30 / 31

| Mejora | Dónde | Origen |
|---|---|---|
| Contactos guardados con nombre: el número se toma del chat (data-id) o de la ficha, con clic en foto/nombre (no en la cabecera de Business) | `src/whatsapp-bridge.mjs` | Prueba en vivo: "número de ficha no disponible" |
| Permitidos administrado (nombre como HMAC, 0600) con BAJA/ALTA | `src/contacts-store.mjs` | Pedido de Pedro |
| Barrido al arrancar: detecta mensajes sin responder sin que el contacto escriba de nuevo | `src/whatsapp-bridge.mjs` | Pedido de Pedro |
| Freno anti-baneo: un chat se reabre solo si cambió, máx. 1 vez por minuto; 30 min de pausa si no hay número | `src/whatsapp-bridge.mjs` | Log en vivo (reapertura cada 30 s) |
| Privacidad: solo se reenvía desde la primera mención de AutoMant y se clasifica solo la cola sin responder | `src/bridge-core.mjs`, `src/whatsapp-bridge.mjs` | Reels y fotos personales llegaron al operador |
| Enlaces sociales, fotos sin texto y notas personales se quedan en el equipo | `src/bridge-core.mjs` | Vuelta 2 de automejora |
| Aprobación desde el chat del proyecto (bandeja con huella y vencimiento 24 h, hasta 10 en paralelo) | `src/approval-inbox.mjs`, `scripts/bandeja.mjs` | Pedido de Pedro |
| Redactor Codex/opencode con contexto de cuenta y memoria; sugiere IGNORAR si no es un pedido | `src/drafter.mjs` | Pedido de Pedro / vuelta 2 |
| Codex del redactor corre fuera de un repo (`--skip-git-repo-check`) | `src/drafter.mjs` | Prueba en vivo: borradores vacíos |
| Memoria local SQLite + FTS5 (conocimiento, aprendizaje, contexto de cuenta, resúmenes) | `src/memory-db.mjs` | Pedido de Pedro |
| Registro: primero se pide elegir perfil (dueño, taller, almacén) | `memoria/comandos.md`, `src/drafter.mjs` | Corrección de Pedro al aprobar |
| Al explicar ACEPTO se incluye el enlace https://automantpro.app/terminos (enlaza /privacidad); un solo enlace por el modo humano | `memoria/comandos.md`, `src/drafter.mjs` | Corrección de Pedro tras la entrega |
| Mensajes borrados o en blanco no se reenvían al operador | `src/bridge-core.mjs`, `src/whatsapp-bridge.mjs` | Corrección de Pedro (31/10) |
| Registro: el agente deduce el perfil del texto libre ("tengo un taller") y pide solo lo que falta; invita a escribir con sus palabras | `src/actions.mjs`, `src/drafter.mjs`, `memoria/comandos.md` | Corrección de Pedro (31/10) |
| Una respuesta a nuestro mensaje de AutoMantPro ("Acepto, 1") sigue la conversación aunque no mencione AutoMant; la opción corta elige el perfil | `src/bridge-core.mjs`, `src/whatsapp-bridge.mjs`, `src/actions.mjs` | Prueba en vivo 31/10: "Acepto, 1" no llegó al operador |
| El redactor usa la decisión del puente y el análisis (perfil, datos que faltan) en vez de descartar respuestas cortas | `src/drafter.mjs` | Prueba 31/10: "Acepto, 1" daba IGNORAR |
| Las líneas para el operador (COMANDO, Faltan datos) nunca llegan al contacto | `src/drafter.mjs`, `src/main.mjs`, `src/approval-inbox.mjs` | Revisión 31/10 |
| La bandeja muestra de qué chat viene cada mensaje (número enmascarado) | `src/approval-inbox.mjs`, `src/whatsapp-bridge.mjs` | Prueba 31/10: dos chats confundidos |
| Contactos guardados ya autorizados se reconocen por su nombre (HMAC) en el barrido, y un envío del servidor ya no borra ese nombre | `src/contacts-store.mjs`, `src/whatsapp-bridge.mjs` | Prueba 31/10: "Acepto, 1" de un contacto guardado no se leía |
| Reglas obligatorias del modo humano | `AGENTS.md` | Pedido de Pedro |
| Acción propuesta con habilidad, comando, campos faltantes y riesgo; EJECUTAR valida la propuesta, pide SI en alto riesgo y conserva fallos del servidor como evento/regla propuesta | `src/actions.mjs`, `src/main.mjs`, `src/approval-inbox.mjs`, `src/memory-db.mjs` | Fase 4, pasos 3–4 |
| Fixtures sintéticos de plan, búsqueda, historial, oferta y cita; evaluación de acierto de acción, campos faltantes y riesgo | `test/fixtures/conversaciones.json`, `scripts/eval-agente.mjs` | Fase 4, paso 5 |
| Inventario de comandos con rutas de origen y límites para historial/plan marketplace | `memoria/comandos.md`, `README.md` | Fase 4 |
