import test from 'node:test';
import assert from 'node:assert/strict';
import { createClient, handleJob, validateBaseUrl } from '../src/client.mjs';
const job = { wamid: 'wamid/a?b', leaseToken: 'lease', userId: 'u1', role: 'owner', message: 'servicio', channel: 'pilot' };
const response = data => ({ ok: true, status: 200, json: async () => ({ data, error: null }) });
test('requires HTTPS except exact loopback and rejects credentials/paths', () => {
  for (const url of ['http://automantpro.app', 'https://u:p@automantpro.app', 'http://localhost.evil', 'https://automantpro.app/api']) {
    assert.throws(() => validateBaseUrl(url));
  }
  assert.equal(validateBaseUrl('http://localhost:3000'), 'http://localhost:3000');
});
test('uses auth and encoded job identity; explicit command flag', async () => {
  const requests = [];
  const client = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async (url, opts) => {
    requests.push({ url, opts }); return response(url.endsWith('claim') ? { jobs: [job] } : { accepted: true });
  } });
  assert.deepEqual(await client.claim(), [job]);
  await client.complete(job, 'propuesta', false);
  assert.equal(requests[0].opts.headers.authorization, 'Bearer dedicated-secret');
  assert.equal(requests[0].opts.redirect, 'error');
  assert.equal(requests[1].url, 'https://example.com/api/v1/local-agent/jobs/wamid%2Fa%3Fb/complete');
  assert.deepEqual(JSON.parse(requests[1].opts.body), { leaseToken: 'lease', reply: 'propuesta', executeCommand: false });
});
test('authentication errors do not expose response bodies or token', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => ({ ok: false, status: 401 }) });
  await assert.rejects(client.claim(), { message: 'AUTH_REJECTED' });
});
test('request timeout aborts pending fetch', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', timeoutMs: 5,
    fetchImpl: async (_url, { signal }) => new Promise((_, reject) => signal.addEventListener('abort', () => reject(new Error('hidden')))),
  });
  await assert.rejects(client.claim(), { message: 'REQUEST_TIMEOUT' });
});
test('malformed jobs are rejected before human can execute them', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => response({ jobs: [{ ...job, leaseToken: null }] }) });
  await assert.rejects(client.claim(), { message: 'INVALID_JOBS' });
});
test('final fence rejects completion after human edited under expired lease', async () => {
  let pulse = 0, complete = 0, lost = 0;
  const client = { heartbeat: async () => ({ accepted: ++pulse === 1 }), complete: async () => { complete++; } };
  assert.deepEqual(await handleJob({ client, job, onLost: () => lost++, approve: async () => ({ action: 'send', reply: 'ok' }) }), { status: 'lease-lost' });
  assert.equal(complete, 0); assert.equal(lost, 1);
});
test('human can defer and heartbeat failure never triggers completion', async () => {
  let retried = 0;
  const client = { heartbeat: async () => ({ accepted: true }), retry: async () => { retried++; return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, approve: async () => null })).status, 'deferred');
  assert.equal(retried, 1);
  assert.equal((await handleJob({ client: { heartbeat: async () => { throw new Error('offline'); } }, job,
    approve: async () => { assert.fail('must not prompt after lost lease'); } })).status, 'lease-lost');
});
test('completion timeout never retries an ambiguous write', async () => {
  let calls = 0;
  const client = { heartbeat: async () => ({ accepted: true }), complete: async () => { calls++; throw new Error('timeout'); } };
  await assert.rejects(handleJob({ client, job, approve: async () => ({ action: 'execute', reply: 'ok' }) }));
  assert.equal(calls, 1);
});
test('heartbeats continue while human drafts; no overlapping heartbeats', async () => {
  let active = 0, max = 0, count = 0;
  const client = { heartbeat: async () => {
    active++; max = Math.max(max, active); count++;
    await new Promise(r => setTimeout(r, 3)); active--; return { accepted: true };
  }, complete: async (_job, reply, command) => { assert.equal(reply, 'ok'); assert.equal(command, false); return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, heartbeatMs: 5, approve: async () => {
    await new Promise(r => setTimeout(r, 25)); return { action: 'send', reply: ' ok ' };
  } })).status, 'completed');
  assert.ok(count >= 3); assert.equal(max, 1);
});

test('reply limit matches server: accepts 2000 and rejects 2001 before write', async () => {
  let calls = 0;
  const client = { heartbeat: async () => ({ accepted: true }), complete: async () => { calls++; return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, approve: async () => ({ action: 'send', reply: 'a'.repeat(2000) }) })).status, 'completed');
  await assert.rejects(handleJob({ client, job, approve: async () => ({ action: 'send', reply: 'a'.repeat(2001) }) }), { message: 'INVALID_DECISION' });
  assert.equal(calls, 1);
});
