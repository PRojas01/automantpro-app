import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, stat, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createClient, handleJob, validateBaseUrl } from '../src/client.mjs';
const job = { wamid: 'wamid/a?b', leaseToken: 'lease', userId: 'u1', role: 'owner', message: 'servicio', channel: 'pilot' };
const response = data => ({ ok: true, status: 200, json: async () => ({ data, error: null }) });
test('requires HTTPS except exact loopback and rejects credentials/paths', () => {
  for (const url of ['http://automantpro.app', 'https://u:p@automantpro.app', 'http://localhost.evil', 'https://automantpro.app/api']) {
    assert.throws(() => validateBaseUrl(url));
  }
  assert.equal(validateBaseUrl('http://localhost:3000'), 'http://localhost:3000');
});
test('uses auth and encoded job identity; explicit command flag', async () => {
  const requests = [];
  const client = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async (url, opts) => {
    requests.push({ url, opts }); return response(url.endsWith('claim') ? { jobs: [job] } : { accepted: true });
  } });
  assert.deepEqual(await client.claim(), [job]);
  await client.complete(job, 'propuesta', false);
  assert.equal(requests[0].opts.headers.authorization, 'Bearer dedicated-secret');
  assert.equal(requests[0].opts.redirect, 'error');
  assert.equal(requests[1].url, 'https://example.com/api/v1/local-agent/jobs/wamid%2Fa%3Fb/complete');
  assert.deepEqual(JSON.parse(requests[1].opts.body), { leaseToken: 'lease', reply: 'propuesta', executeCommand: false });
});
test('authentication errors do not expose response bodies or token', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => ({ ok: false, status: 401 }) });
  await assert.rejects(client.claim(), { message: 'AUTH_REJECTED' });
});
test('request timeout aborts pending fetch', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', timeoutMs: 5,
    fetchImpl: async (_url, { signal }) => new Promise((_, reject) => signal.addEventListener('abort', () => reject(new Error('hidden')))),
  });
  await assert.rejects(client.claim(), { message: 'REQUEST_TIMEOUT' });
});
test('malformed jobs are rejected before human can execute them', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => response({ jobs: [{ ...job, leaseToken: null }] }) });
  await assert.rejects(client.claim(), { message: 'INVALID_JOBS' });
});
test('final fence rejects completion after human edited under expired lease', async () => {
  let pulse = 0, complete = 0, lost = 0;
  const client = { heartbeat: async () => ({ accepted: ++pulse === 1 }), complete: async () => { complete++; } };
  assert.deepEqual(await handleJob({ client, job, onLost: () => lost++, approve: async () => ({ action: 'send', reply: 'ok' }) }), { status: 'lease-lost' });
  assert.equal(complete, 0); assert.equal(lost, 1);
});
test('human can defer and heartbeat failure never triggers completion', async () => {
  let retried = 0;
  const client = { heartbeat: async () => ({ accepted: true }), retry: async () => { retried++; return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, approve: async () => null })).status, 'deferred');
  assert.equal(retried, 1);
  assert.equal((await handleJob({ client: { heartbeat: async () => { throw new Error('offline'); } }, job,
    approve: async () => { assert.fail('must not prompt after lost lease'); } })).status, 'lease-lost');
});
test('completion timeout never retries an ambiguous write', async () => {
  let calls = 0;
  const client = { heartbeat: async () => ({ accepted: true }), complete: async () => { calls++; throw new Error('timeout'); } };
  await assert.rejects(handleJob({ client, job, approve: async () => ({ action: 'execute', reply: 'ok' }) }));
  assert.equal(calls, 1);
});
test('heartbeats continue while human drafts; no overlapping heartbeats', async () => {
  let active = 0, max = 0, count = 0;
  const client = { heartbeat: async () => {
    active++; max = Math.max(max, active); count++;
    await new Promise(r => setTimeout(r, 3)); active--; return { accepted: true };
  }, complete: async (_job, reply, command) => { assert.equal(reply, 'ok'); assert.equal(command, false); return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, heartbeatMs: 5, approve: async () => {
    await new Promise(r => setTimeout(r, 25)); return { action: 'send', reply: ' ok ' };
  } })).status, 'completed');
  assert.ok(count >= 3); assert.equal(max, 1);
});

test('reply limit matches server: accepts 2000 and rejects 2001 before write', async () => {
  let calls = 0;
  const client = { heartbeat: async () => ({ accepted: true }), complete: async () => { calls++; return { accepted: true }; } };
  assert.equal((await handleJob({ client, job, approve: async () => ({ action: 'send', reply: 'a'.repeat(2000) }) })).status, 'completed');
  await assert.rejects(handleJob({ client, job, approve: async () => ({ action: 'send', reply: 'a'.repeat(2001) }) }), { message: 'INVALID_DECISION' });
  assert.equal(calls, 1);
});

test('revoked configuration stops client; temporary service errors remain retriable', async () => {
  const revoked = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => ({
    ok: false, status: 503, json: async () => ({ error: { code: 'LOCAL_AGENT_DISABLED', detail: 'hidden secret' } }),
  }) });
  await assert.rejects(revoked.claim(), { message: 'LOCAL_AGENT_DISABLED' });
  const unavailable = createClient({ baseUrl: 'https://example.com', token: 'hidden', fetchImpl: async () => ({
    ok: false, status: 503, json: async () => { throw new Error('backend unavailable'); },
  }) });
  await assert.rejects(unavailable.claim(), { message: 'HTTP_503' });
});

test('losing lease aborts approval signal before a later confirmation can open', async () => {
  let pulse = 0, completed = 0, observedAborted = false;
  const client = { heartbeat: async () => ({ accepted: ++pulse === 1 }), complete: async () => { completed++; } };
  const result = await handleJob({ client, job, heartbeatMs: 5, approve: async (_job, signal) => {
    // Simulate a draft already returned, then pause before creating the next prompt.
    await new Promise(resolve => signal.addEventListener('abort', resolve, { once: true }));
    observedAborted = signal.aborted;
    return { action: 'send', reply: 'must be discarded' };
  } });
  assert.equal(observedAborted, true);
  assert.equal(result.status, 'lease-lost');
  assert.equal(completed, 0);
});

test('Ubuntu installer resolves relative destinations and protects config', { skip: process.platform !== 'linux' }, async () => {
  const folder = await mkdtemp(join(tmpdir(), 'amp-installer-'));
  try {
    const install = fileURLToPath(new URL('../scripts/install-ubuntu.sh', import.meta.url));
    const result = spawnSync('bash', [install, 'relative path'], {
      cwd: folder, encoding: 'utf8', env: { ...process.env, LOCAL_AGENT_BIN_DIR: 'bin' },
    });
    assert.equal(result.status, 0, result.stderr);
    const launcher = await readFile(join(folder, 'bin/automantpro-agent'), 'utf8');
    assert.ok(launcher.includes(`cd -- ${folder}/relative\\ path`));
    assert.equal((await stat(join(folder, 'relative path/.env'))).mode & 0o777, 0o600);
    assert.ok((await readFile(join(folder, 'relative path/.env'), 'utf8')).includes('replace-with-dedicated-server-token'));
  } finally { await rm(folder, { recursive: true, force: true }); }
});
test('bridge calls use their own paths, validate the outbox and bound retry codes', async () => {
  const requests = [];
  const outbox = [{ id: 'o/1', leaseToken: 'lease', phone: '593990000001', kind: 'agent.reply', message: 'Hola' }];
  const client = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async (url, opts) => {
    requests.push({ url, body: JSON.parse(opts.body) }); return response(url.endsWith('claim') ? { messages: outbox } : { accepted: true });
  } });
  await client.inbound({ id: 'wweb_x', phone: '593990000001', text: 'hola' });
  assert.deepEqual(await client.outbox(), outbox);
  await client.delivered(outbox[0]);
  await client.undelivered(outbox[0], 'not a code', 5);
  assert.deepEqual(requests.map(r => r.url.replace('https://example.com/api/v1/local-agent/', '')), ['whatsapp/inbound', 'whatsapp/outbox/claim', 'whatsapp/outbox/o%2F1/sent', 'whatsapp/outbox/o%2F1/failed']);
  assert.deepEqual(requests[3].body, { leaseToken: 'lease', errorCode: 'DELIVERY_FAILED', delaySeconds: 60 });
  const bad = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async () => response({ messages: [{ ...outbox[0], phone: '+593 99' }] }) });
  await assert.rejects(bad.outbox(), { code: 'INVALID_OUTBOX' });
  const off = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async () => ({ ok: false, status: 503, json: async () => ({ error: { code: 'WHATSAPP_BRIDGE_DISABLED' } }) }) });
  await assert.rejects(off.outbox(), { code: 'WHATSAPP_BRIDGE_DISABLED' });
});
test('IGNORAR dismisses the job without a reply', async () => {
  const requests = [];
  const client = createClient({ baseUrl: 'https://example.com', token: 'dedicated-secret', fetchImpl: async (url, opts) => { requests.push({ url, body: JSON.parse(opts.body) }); return response({ accepted: true }); } });
  const result = await handleJob({ client, job, approve: async () => ({ action: 'dismiss' }), heartbeatMs: 60000 });
  assert.equal(result.status, 'dismissed');
  assert.ok(requests.some(r => r.url.endsWith('/dismiss') && r.body.leaseToken === 'lease'));
  assert.ok(!requests.some(r => r.url.endsWith('/complete')));
});

test('claimAll validates task envelopes and task writes keep the lease contract', async () => {
  const task = { id: 'task-id', type: 'reporte_estado', payload: {}, leaseToken: 'lease-token' };
  const requests = [];
  const client = createClient({ baseUrl: 'https://example.com', token: 'secret', fetchImpl: async (url, opts) => {
    requests.push({ url, opts });
    return response(url.endsWith('/claim') ? { jobs: [], tasks: [task] } : { accepted: true });
  } });
  assert.deepEqual(await client.claimAll(), { jobs: [], tasks: [task] });
  await client.completeTask(task, 'done');
  await client.failTask(task, 'FAILED');
  assert.deepEqual(JSON.parse(requests[1].opts.body), { leaseToken: task.leaseToken, result: 'done' });
  assert.deepEqual(JSON.parse(requests[2].opts.body), { leaseToken: task.leaseToken, errorCode: 'FAILED' });
  assert.match(requests[1].url, /\/tasks\/task-id\/complete$/);
});

test('claimAll rejects unknown task types', async () => {
  const client = createClient({ baseUrl: 'https://example.com', token: 'secret', fetchImpl: async () => response({ jobs: [], tasks: [{ id: 'x', type: '__proto__', leaseToken: 'x', payload: {} }] }) });
  await assert.rejects(client.claimAll(), { message: 'INVALID_TASKS' });
});
