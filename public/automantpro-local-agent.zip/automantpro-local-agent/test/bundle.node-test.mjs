import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));

async function allowlist() {
  const source = await readFile(join(root, 'scripts/bundle.mjs'), 'utf8');
  const match = source.match(/const files = (\[[\s\S]*?\]);/);
  assert.ok(match, 'scripts/bundle.mjs debe declarar const files = [...]');
  return Function(`return ${match[1]}`)();
}

const relativeImports = code => [...code.matchAll(/(?:from\s+|import\(\s*|require\(\s*)['"](\.{1,2}\/[^'"]+)['"]/g)].map(m => m[1]);

test('el ZIP y el paquete de migración incluyen todos los módulos que importa el agente', async () => {
  const files = await allowlist(), listed = new Set(files), missing = [];
  for (const file of files.filter(f => /\.(mjs|cjs|js)$/.test(f))) {
    const code = await readFile(join(root, file), 'utf8');
    for (const spec of relativeImports(code)) {
      const target = normalize(join(dirname(file), spec)).split('\\').join('/');
      if (!listed.has(target)) missing.push(`${file} -> ${target}`);
    }
  }
  assert.deepEqual(missing, []);
});

test('la lista no incluye secretos, datos locales ni la sesión de WhatsApp', async () => {
  for (const file of await allowlist()) {
    assert.ok(!(file === '.env' || file.startsWith('data/') || file.includes('whatsapp-profile') || file.endsWith('.log')), file);
  }
});

test('cada archivo de la lista existe', async () => {
  for (const file of await allowlist()) await readFile(join(root, file));
});
