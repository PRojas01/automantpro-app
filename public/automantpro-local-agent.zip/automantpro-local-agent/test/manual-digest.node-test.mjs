import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { MANUAL_COMPONENTS, checkRow, digestManual, matchComponent, mergeRows, numberInText, relevantPages, toCsv } from '../src/manual-digest.mjs';

// Manual sintético (no es de ningún fabricante real): una página de tabla y una de relleno.
const TABLA = `PROGRAMA DE MANTENIMIENTO PERIÓDICO
Intervalo: lo que ocurra primero, km o meses
Aceite del motor y filtro de aceite ........ reemplazar cada 5.000 km o 6 meses
Filtro de combustible (separador de agua) .. reemplazar cada 10 000 km o 12 meses
Correa de distribución ...................... reemplazar cada 60000 km
Líquido de frenos ........................... reemplazar cada 24 meses
Refrigerante del motor ...................... reemplazar cada 40.000 km o 24 meses
Inspeccionar pastillas de freno cada 10.000 km; inspeccionar discos de freno cada 10.000 km`;
const pages = [{ page: 1, text: 'Bienvenido. Gracias por elegir este vehículo. Lea el manual.' }, { page: 7, text: TABLA }];
const meta = { marca: 'Marca Sintética', modelo: 'Modelo X', anioDesde: 2012, anioHasta: 2017, combustible: 'diesel', titulo: 'Manual de prueba', url: 'https://example.com/manual.pdf', fecha: '2026-11-26', paginas: null };

test('el catálogo del digestor es el mismo del plan por componentes', () => {
  const ts = readFileSync(new URL('../../api/src/domain/maintenance/system-components.ts', import.meta.url), 'utf8');
  const ids = [...ts.matchAll(/\{ id: "([a-z]+_[a-z_]+)", name:/g)].map(m => m[1]).sort();
  assert.deepEqual(MANUAL_COMPONENTS.map(c => c.id).sort(), ids);
});

test('reconoce componentes por sinónimo en español e inglés', () => {
  assert.equal(matchComponent('Correa de distribución').id, 'mot_distribucion');
  assert.equal(matchComponent('Engine oil and oil filter').id, 'mot_aceite');
  assert.equal(matchComponent('Filtro de combustible (separador de agua)').id, 'mot_filtro_comb');
  assert.equal(matchComponent('Brake fluid').id, 'fre_liquido');
  assert.equal(matchComponent('algo que no existe'), null);
});

test('números con o sin separador de miles', () => {
  assert.ok(numberInText(10000, 'cada 10.000 km'));
  assert.ok(numberInText(10000, 'cada 10 000 km'));
  assert.ok(numberInText(60000, 'cada 60000 km'));
  assert.ok(!numberInText(15000, 'cada 10.000 km'));
  assert.ok(!numberInText(1000, 'cada 10.000 km'));
});

test('solo lee las páginas con tablas de mantenimiento', () => {
  assert.deepEqual(relevantPages(pages).map(p => p.page), [7]);
});

test('descarta lo inventado: cita ausente o número que no está en el manual', () => {
  const page = pages[1];
  assert.equal(checkRow({ componente: 'Bujías', km: 20000, cita: 'bujías cada 20.000 km' }, page).estado, 'descartada');
  assert.equal(checkRow({ componente: 'Aceite del motor', km: 7500, meses: 6, cita: 'Aceite del motor y filtro de aceite' }, page).motivo, 'el número no aparece en el manual');
  const ok = checkRow({ componente: 'Aceite del motor y filtro', km: '5.000', meses: 6, cita: 'Aceite del motor y filtro de aceite ........ reemplazar cada 5.000 km o 6 meses' }, page);
  assert.equal(ok.estado, 'aceptada'); assert.equal(ok.componentId, 'mot_aceite'); assert.equal(ok.km, 5000);
});

test('valores distintos del mismo componente quedan en conflicto', () => {
  const a = { estado: 'aceptada', componentId: 'fre_pastillas', km: 10000, months: null, page: 7 };
  const merged = mergeRows([a, { ...a, km: 20000, page: 9 }]);
  assert.equal(merged[0].estado, 'conflicto');
  assert.equal(toCsv(merged, meta).trim().split('\n').length, 1, 'el conflicto no va al CSV');
});

test('digestión completa con el modelo local simulado y revisión híbrida', async () => {
  const local = async () => JSON.stringify({ filas: [
    { componente: 'Aceite del motor y filtro de aceite', accion: 'reemplazar', km: 5000, meses: 6, cita: 'Aceite del motor y filtro de aceite ........ reemplazar cada 5.000 km o 6 meses' },
    { componente: 'Correa de distribución', accion: 'reemplazar', km: 60000, meses: null, cita: 'Correa de distribución' },
    { componente: 'Líquido de frenos', accion: 'reemplazar', km: null, meses: 24, cita: 'Líquido de frenos ........................... reemplazar cada 24 meses' },
    { componente: 'Bujías', accion: 'reemplazar', km: 20000, meses: null, cita: 'Bujías cada 20.000 km' },
  ] });
  let asked = 0;
  const verify = async () => { asked++; return '{"ok":true,"km":60000,"meses":null}'; };
  const r = await digestManual(pages, meta, { ask: local, verify });
  assert.equal(r.counts.aceptadas, 3);
  assert.equal(r.counts.descartadas, 1);
  assert.equal(asked, 1, 'Claude solo revisa la fila cuyo número no está en su cita');
  const csv = r.csv.trim().split('\n');
  assert.equal(csv[0], 'sistema,item,marca,modelo,anio_desde,anio_hasta,combustible,intervalo_km,intervalo_meses,fuente,url,fecha,codigo_sistema,sistema_fabricante,codigo_item,item_fabricante,accion,pagina,cita,inspeccion_km,inspeccion_meses,severo_km,severo_meses,operacion,ref_procedimiento,repuestos,especificacion,torque,tipo_manual');
  assert.ok(csv.some(l => l.startsWith('Motor y propulsión,Kit de distribución,Marca Sintética,Modelo X,2012,2017,diesel,60000,,"Manual de prueba, pág. 7"')));
});

test('el CSV neutraliza fórmulas de hoja de cálculo', () => {
  const csv = toCsv([{ estado: 'aceptada', sistema: 'Frenos y seguridad activa', item: 'Pastillas', km: 10000, months: null, page: 2 }], { ...meta, titulo: '=HYPERLINK("x")' });
  assert.match(csv, /"'=HYPERLINK\(""x""\), pág\. 2"/);
});

test('conserva los códigos impresos y entrega lo que no está en el catálogo', async () => {
  const page = { page: 3, text: 'SISTEMA 17 Control de emisiones\n17-01 Válvula EGR: limpiar cada 40.000 km' };
  const row = checkRow({ componente: 'Válvula EGR', km: 40000, cita: '17-01 Válvula EGR: limpiar cada 40.000 km', sistema: 'Control de emisiones', codigo_sistema: '17', codigo: '17-01' }, page);
  assert.equal(row.estado, 'sin_mapear'); assert.equal(row.codigoItem, '17-01');
  assert.equal(checkRow({ componente: 'Válvula EGR', km: 40000, cita: row.cita, codigo: '99-99' }, page).codigoItem, '', 'un código que no está impreso no se acepta');
  const r = await digestManual([page], { ...meta, paginas: [3] }, { ask: async () => JSON.stringify({ filas: [{ componente: 'Válvula EGR', km: 40000, cita: row.cita, sistema: 'Control de emisiones', codigo_sistema: '17', codigo: '17-01' }] }) });
  assert.match(r.csv.split('\n')[1], /^,,Marca Sintética,Modelo X,2012,2017,diesel,40000,,.*,17,Control de emisiones,17-01,Válvula EGR,/);
});
