import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAction } from '../src/actions.mjs';

test('proposes marketplace search only when required context is complete', () => {
  const partial = buildAction('Busco repuesto', { vehicleId: 'v1' });
  assert.equal(partial.comando, null);
  assert.deepEqual(partial.faltan, ['categoria', 'ciudad', 'sector', 'descripcion']);
  const complete = buildAction('Busco repuesto', { vehicleId: 'v1', category: 'frenos', city: 'Quito', zone: 'Centro', description: 'pastillas delanteras' });
  assert.equal(complete.comando, 'Buscar repuesto | frenos | Quito | Centro | pastillas delanteras');
});

test('marks offer acceptance and appointment confirmation high risk', () => {
  assert.equal(buildAction('Quiero aceptar oferta 2').riesgo, 'alto');
  assert.equal(buildAction('Confirmar cita C-1a2b3c').comando, 'Confirmar C-1A2B3C');
  assert.equal(buildAction('Confirmar cita C-1a2b3c').riesgo, 'alto');
});

test('does not invent history commands and identifies missing plan vehicle data', () => {
  assert.equal(buildAction('consultar historial').comando, null);
  assert.deepEqual(buildAction('registrar servicio en historial').faltan, ['servicio', 'kilometraje', 'mes AAAA-MM o indicar que se desconoce']);
  assert.equal(buildAction('quiero ver mi plan', { role: 'dueno', vehicleId: 'v-sintetico' }).comando, 'Plan');
  assert.deepEqual(buildAction('quiero ver mi plan').faltan, ['vehículo registrado']);
});

test('builds account history registration command only from supplied fields', () => {
  const action = buildAction('anotar servicio', { service: 'cambio de aceite', km: '45000', month: '2026-10', vehicleId: 'v-sintetico' });
  assert.equal(action.comando, 'Último servicio | cambio de aceite | 45000 | 2026-10');
});

test('registration infers the profile from free text', async () => {
  const { buildAction, inferProfile } = await import('../src/actions.mjs');
  assert.equal(inferProfile('tengo un taller en Quito'), 'taller');
  assert.equal(inferProfile('vendo repuestos en Guayaquil'), 'almacen');
  assert.equal(inferProfile('2'), 'taller');
  assert.equal(inferProfile('hola'), null);
  const a = buildAction('Hola quiero registrarme en Automantpro');
  assert.equal(a.habilidad, 'registro'); assert.equal(a.comando, null); assert.match(a.faltan[0], /perfil/);
  const b = buildAction('quiero registrar mi taller, ACEPTO');
  assert.equal(b.habilidad, 'registro'); assert.equal(b.perfil, 'taller'); assert.equal(b.riesgo, 'bajo');
});

test('memoria keeps the registration rules approved by Pedro', async () => {
  const { readFile } = await import('node:fs/promises');
  const text = await readFile(new URL('../memoria/comandos.md', import.meta.url), 'utf8');
  assert.match(text, /## Registro/);
  assert.match(text, /elegir el perfil/);
  assert.match(text, /https:\/\/automantpro\.app\/terminos/);
  assert.match(text, /texto libre/);
});

test('short option replies pick the profile', async () => {
  const { buildAction, inferProfile } = await import('../src/actions.mjs');
  assert.equal(inferProfile('Acepto, 1'), 'dueno');
  assert.equal(inferProfile('la 2'), 'taller');
  const a = buildAction('Acepto, 1');
  assert.equal(a.habilidad, 'registro'); assert.equal(a.perfil, 'dueno'); assert.equal(a.comando, null);
});

test('operator lines never reach the contact', async () => {
  const { stripOperatorLines } = await import('../src/drafter.mjs');
  assert.equal(stripOperatorLines('Hola, ¿tu nombre?\nCOMANDO: Registrarme | x\nFaltan datos: ciudad.'), 'Hola, ¿tu nombre?');
});
