import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAction, signupLink } from '../src/actions.mjs';

test('proposes marketplace search only when required context is complete', () => {
  const partial = buildAction('Busco repuesto', { vehicleId: 'v1' });
  assert.equal(partial.comando, null);
  assert.deepEqual(partial.faltan, ['categoria', 'ciudad', 'sector', 'descripcion']);
  const complete = buildAction('Busco repuesto', { vehicleId: 'v1', category: 'frenos', city: 'Quito', zone: 'Centro', description: 'pastillas delanteras' });
  assert.equal(complete.comando, 'Buscar repuesto | frenos | Quito | Centro | pastillas delanteras');
});

test('marks offer acceptance and appointment confirmation high risk', () => {
  assert.equal(buildAction('Quiero aceptar oferta 2').riesgo, 'alto');
  assert.equal(buildAction('Confirmar cita C-1a2b3c').comando, 'Confirmar C-1A2B3C');
  assert.equal(buildAction('Confirmar cita C-1a2b3c').riesgo, 'alto');
});

test('does not invent history commands and identifies missing plan vehicle data', () => {
  assert.equal(buildAction('consultar historial').comando, null);
  assert.deepEqual(buildAction('registrar servicio en historial').faltan, ['servicio', 'kilometraje', 'mes AAAA-MM o indicar que se desconoce']);
  assert.equal(buildAction('quiero ver mi plan', { role: 'dueno', vehicleId: 'v-sintetico' }).comando, 'Plan');
  assert.deepEqual(buildAction('quiero ver mi plan').faltan, ['vehículo registrado']);
});

test('builds account history registration command only from supplied fields', () => {
  const action = buildAction('anotar servicio', { service: 'cambio de aceite', km: '45000', month: '2026-10', vehicleId: 'v-sintetico' });
  assert.equal(action.comando, 'Último servicio | cambio de aceite | 45000 | 2026-10');
});

test('registration infers the profile from free text', async () => {
  const { buildAction, inferProfile } = await import('../src/actions.mjs');
  assert.equal(inferProfile('tengo un taller en Quito'), 'taller');
  assert.equal(inferProfile('vendo repuestos en Guayaquil'), 'almacen');
  assert.equal(inferProfile('2'), 'taller');
  assert.equal(inferProfile('hola'), null);
  const a = buildAction('Hola quiero registrarme en Automantpro');
  assert.equal(a.habilidad, 'registro'); assert.equal(a.comando, null); assert.match(a.faltan[0], /perfil/);
  const b = buildAction('quiero registrar mi taller, ACEPTO');
  assert.equal(b.habilidad, 'registro'); assert.equal(b.perfil, 'taller'); assert.equal(b.riesgo, 'bajo');
});

test('memoria keeps the registration rules approved by Pedro', async () => {
  const { readFile } = await import('node:fs/promises');
  const text = await readFile(new URL('../memoria/comandos.md', import.meta.url), 'utf8');
  assert.match(text, /## Registro/);
  assert.match(text, /elegir el perfil/);
  assert.match(text, /https:\/\/automantpro\.app\/terminos/);
  assert.match(text, /texto libre/);
});

test('short option replies pick the profile', async () => {
  const { buildAction, inferProfile } = await import('../src/actions.mjs');
  assert.equal(inferProfile('Acepto, 1'), 'dueno');
  assert.equal(inferProfile('la 2'), 'taller');
  const a = buildAction('Acepto, 1');
  assert.equal(a.habilidad, 'registro'); assert.equal(a.perfil, 'dueno'); assert.equal(a.comando, null);
});

test('operator lines never reach the contact', async () => {
  const { stripOperatorLines } = await import('../src/drafter.mjs');
  assert.equal(stripOperatorLines('Hola, ¿tu nombre?\nCOMANDO: Registrarme | x\nFaltan datos: ciudad.'), 'Hola, ¿tu nombre?');
});

test('modo privado: exige 0600/0700 en Linux y macOS, y lo omite en Windows', async () => {
  const { hasPrivateMode } = await import('../src/guard.mjs');
  assert.equal(hasPrivateMode({ mode: 0o100600 }, 0o600, 'linux'), true);
  assert.equal(hasPrivateMode({ mode: 0o100644 }, 0o600, 'linux'), false);
  assert.equal(hasPrivateMode({ mode: 0o40700 }, 0o700, 'darwin'), true);
  assert.equal(hasPrivateMode({ mode: 0o40755 }, 0o700, 'darwin'), false);
  assert.equal(hasPrivateMode({ mode: 0o100666 }, 0o600, 'win32'), true);
});

test('propone tal cual el comando exacto que el servidor reconoció, y no otro texto', () => {
  const exact = buildAction('Foto OT-00012 | entrega', { exactCommand: 'Foto OT-00012 | entrega', hasPhoto: true });
  assert.equal(exact.comando, 'Foto OT-00012 | entrega');
  assert.equal(exact.riesgo, 'alto');
  assert.equal(exact.conFoto, true);
  assert.deepEqual(exact.faltan, []);
  const lowRisk = buildAction('Mis vehículos', { exactCommand: 'Mis vehículos' });
  assert.equal(lowRisk.riesgo, 'bajo');
  const other = buildAction('hola, una consulta', { exactCommand: 'Foto OT-00012 | entrega' });
  assert.notEqual(other.comando, 'Foto OT-00012 | entrega');
});

test('«Confirmo reembolso» es de riesgo alto', () => {
  assert.equal(buildAction('Confirmo reembolso OT-00012', { exactCommand: 'Confirmo reembolso OT-00012' }).riesgo, 'alto');
});

test('registration hands the signup link of the profile instead of asking for data by chat', () => {
  const shop = buildAction('tengo un taller, quiero registrarme');
  assert.deepEqual(shop.faltan, []);
  assert.equal(shop.enlace, signupLink('taller'));
  assert.match(shop.enlace, /\/cuenta\?perfil=taller#crear$/);
  const unknown = buildAction('Hola quiero registrarme en Automantpro');
  assert.equal(unknown.enlace.split('\n').length, 3);
  assert.doesNotMatch(signupLink('dueno', 'https://example.test/'), /\/\/cuenta/);
});

test('web primero: enlace a la sección del panel según el tema, solo con cuenta', async () => {
  const { sectionLink } = await import('../src/actions.mjs');
  assert.equal(sectionLink('como agrego un conductor a mi flota?', 'dueno', 'https://example.test/').url, 'https://example.test/cuenta#flota');
  assert.equal(sectionLink('quiero ver la caja del mes', 'taller').seccion, 'caja');
  assert.equal(sectionLink('cómo subo las fichas de mis clientes', 'taller').seccion, 'cargar-fichas');
  assert.equal(sectionLink('dónde veo el informe técnico', 'dueno').seccion, 'ordenes');
  assert.equal(sectionLink('quiero ser experto', 'taller').seccion, 'cursos');
  assert.equal(sectionLink('como agrego un conductor', 'nuevo'), null);
  // Fundador sin cuenta (23/11): costos → página pública de planes; si ya usa otra app, «apoyo adicional».
  const cost = sectionLink('Cuánto cuesta? ya tenemos una app para el taller', 'nuevo', 'https://example.test');
  assert.equal(cost.url, 'https://example.test/planes');
  assert.match(cost.pista, /apoyo adicional/);
  assert.doesNotMatch(sectionLink('cuales son los costos', 'nuevo').pista, /apoyo adicional/);
  assert.match(sectionLink('ya usamos otro sistema', 'nuevo').pista, /apoyo adicional/);
  assert.equal(sectionLink('hola, buenos días', 'dueno'), null);
  // Hallazgos 48 y 49 (21/11): citas y planes; cada enlace solo para el perfil que tiene esa sección.
  assert.equal(sectionLink('quiero agendar un cambio de aceite', 'dueno').url, 'https://automantpro.app/cuenta#book');
  assert.equal(sectionLink('confirmar la cita c-52f8c2', 'taller').seccion, 'citas');
  const plans = sectionLink('que planes tienen y cuanto cuestan?', 'dueno');
  assert.equal(plans.url, 'https://automantpro.app/planes');
  assert.equal(plans.etiqueta, 'Planes y precios');
  assert.match(plans.pista, /Planes/);
  assert.equal(sectionLink('ver el plan de mantenimiento de mi carro', 'dueno'), null);
  assert.equal(sectionLink('cuanto cuesta el cambio de aceite', 'dueno'), null);
  assert.equal(sectionLink('como agrego un conductor a mi flota?', 'taller'), null);
  assert.equal(sectionLink('quiero ver la caja del mes', 'dueno'), null);
  assert.equal(sectionLink('que talleres cerca hay', 'dueno').seccion, 'talleres');
  // «plan premium» es la suscripción, no el plan de mantenimiento del vehículo.
  assert.notEqual(buildAction('cuanto cuesta el plan premium?', { accountId: 'u-1' }).habilidad, 'plan_mantenimiento');
  assert.equal(buildAction('quiero ver el plan de mantenimiento de mi vehiculo por favor', { accountId: 'u-1' }).habilidad, 'plan_mantenimiento');
});

test('registro nuevo pasa directo: texto fijo con el enlace de su perfil, sin bandeja', async () => {
  const { autoRegistrationReply } = await import('../src/actions.mjs');
  const env = { LOCAL_AGENT_URL: 'https://example.test' };
  const shop = autoRegistrationReply(buildAction('tengo un taller, quiero registrarme'), { role: 'nuevo' }, env);
  assert.match(shop, /https:\/\/example\.test\/cuenta\?perfil=taller#crear/);
  assert.equal((shop.match(/https?:\/\//g) || []).length, 1);
  const ask = autoRegistrationReply(buildAction('Hola quiero registrarme en Automantpro'), { role: 'nuevo' }, env);
  assert.match(ask, /Responde con el número/);
  assert.doesNotMatch(ask, /https?:/);
  assert.equal(autoRegistrationReply(buildAction('tengo un taller, quiero registrarme'), { role: 'taller' }, env), null);
  assert.equal(autoRegistrationReply(buildAction('quiero ver mi plan'), { role: 'nuevo' }, env), null);
  assert.equal(autoRegistrationReply(buildAction('tengo un taller, quiero registrarme'), { role: 'nuevo' }, { LOCAL_AGENT_AUTO_REGISTRO: 'off' }), null);
});

test('responde todo sin bandeja, salvo comandos y riesgo alto', async () => {
  const { autoSendDecision } = await import('../src/drafter.mjs');
  assert.deepEqual(autoSendDecision('Hola, con gusto.\nFaltan datos: ciudad.', { riesgo: 'bajo', comando: null }, {}), { action: 'send', reply: 'Hola, con gusto.' });
  assert.deepEqual(autoSendDecision('IGNORAR', { riesgo: 'bajo' }, {}), { action: 'dismiss' });
  assert.equal(autoSendDecision('Listo', { riesgo: 'bajo', comando: 'Plan' }, {}), null);
  assert.equal(autoSendDecision('Listo', { riesgo: 'alto', comando: null }, {}), null);
  assert.equal(autoSendDecision('a https://a.test b https://b.test', { riesgo: 'bajo' }, {}), null);
  assert.equal(autoSendDecision('', { riesgo: 'bajo' }, {}), null);
  assert.equal(autoSendDecision(null, { riesgo: 'bajo' }, {}), null);
  assert.equal(autoSendDecision('Hola', { riesgo: 'bajo' }, { LOCAL_AGENT_AUTO_RESPUESTA: 'off' }), null);
});

test('los enlaces del inicio («Hola AutoMantPro, tengo un taller. Código: AMP-…») son un registro con su enlace', async () => {
  const { autoRegistrationReply } = await import('../src/actions.mjs');
  const env = { LOCAL_AGENT_URL: 'https://example.test' };
  const pick = m => { const a = buildAction(m); return { a, r: autoRegistrationReply(a, { role: 'nuevo' }, env) }; };
  assert.match(pick('Hola AutoMantPro, tengo un taller. Código: AMP-4K7Q').r, /perfil=taller#crear/);
  assert.match(pick('Hola AutoMantPro, tengo un almacén de repuestos. Código: AMP-4K7Q').r, /perfil=almacen#crear/);
  assert.match(pick('Hola AutoMantPro, soy dueño de un vehículo. Código: AMP-4K7Q').r, /perfil=dueno#crear/);
  assert.match(pick('Hola AutoMantPro, quiero empezar. Código: AMP-4K7Q').r, /Responde con el número/);
  assert.equal(pick('Hola AutoMantPro, quiero plan Premium Código: AMP-4K7Q').r, null);
});
