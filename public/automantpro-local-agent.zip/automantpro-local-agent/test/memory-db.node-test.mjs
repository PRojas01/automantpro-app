import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { classifySkill, createMemoryDb } from '../src/memory-db.mjs';

test('event records migrate, classify, anonymize, HMAC contacts and accept server results later', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-events-'));
  try {
    const dataDir = join(root, 'data'), docsDir = join(root, 'memoria'); await mkdir(docsDir);
    const db = await createMemoryDb({ dataDir, docsDir, now: () => Date.UTC(2026, 9, 30) });
    assert.equal(classifySkill('Quiero registrarme como taller'), 'registro');
    assert.equal(classifySkill('Necesito un plan'), 'plan');
    assert.equal(classifySkill('Buscar repuesto'), 'busqueda');
    assert.equal(classifySkill('Ver historial'), 'historial');
    assert.equal(classifySkill('servicio de frenos'), 'servicio');
    assert.equal(classifySkill('factura del pedido'), 'negocio');
    assert.equal(classifySkill('hola'), 'otro');
    const id = db.registrarEvento({ canal: 'whatsapp', habilidad: 'servicio', accionPropuesta: 'respuesta sugerida', decision: 'CORREGIDO', textoFinal: 'Hablé con Juan Perez, +593 99 123 4567', contacto: '+593 99 000 0001' });
    let event = db.evento(id);
    assert.equal(event.resultado, null);
    assert.doesNotMatch(event.texto_final_anon, /Juan Perez|123 4567/);
    assert.match(event.texto_final_anon, /\[persona\]|\[persona\]/);
    assert.match(event.clave_contacto_hmac, /^[a-f0-9]{64}$/);
    assert.equal(db.eventosCorregidos().length, 1);
    const evalCase = db.guardarCasoCorregido({ eventoId: id, habilidad: 'servicio', mensaje: 'Soy Juan Perez, necesito frenos +593 99 123 4567', sugerido: 'Hola Juan', final: 'Hola Juan Perez' });
    assert.equal(evalCase.title, '+593 99 000 0000');
    assert.doesNotMatch(JSON.stringify(evalCase), /Juan Perez|123 4567/);
    db.registrarNota({ fecha: '2026-10-30', habilidad: 'servicio', puntos: 3, total: 4, validos: 1, falsosAbiertos: 0 });
    assert.deepEqual({ ...db.listarNotas()[0] }, { fecha: '2026-10-30', habilidad: 'servicio', puntos: 3, total: 4, validos: 1, falsos_abiertos: 0 });
    assert.throws(() => db.registrarNota({ fecha: 'ayer', habilidad: 'servicio', puntos: -1, total: 1, validos: 1, falsosAbiertos: 0 }), { message: 'INVALID_NOTE' });
    assert.equal(db.actualizarResultadoEvento(id, 'entregado'), true);
    assert.equal(db.evento(id).resultado, 'entregado');
    assert.throws(() => db.registrarEvento({ habilidad: 'servicio', decision: 'BAD' }), { message: 'INVALID_EVENT' });
    assert.equal(db.actualizarResultadoEvento(id, 'fallo'), true);
    db.cerrar();
    const again = await createMemoryDb({ dataDir, docsDir });
    assert.equal(again.evento(id).decision, 'CORREGIDO');
    again.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('SQLite memory protects data and supports FTS, migration, expiry and forgetting', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-memory-'));
  const dataDir = join(root, 'data'), docsDir = join(root, 'memoria'), learning = join(dataDir, 'memoria', 'aprendizaje.jsonl');
  await mkdir(docsDir); await mkdir(join(dataDir, 'memoria'), { recursive: true });
  await writeFile(join(docsDir, 'servicios.md'), '# Servicios\n## Aceite\nBusca servicio para cambio de aceite y vehículo.\n## Llantas\nConsulta por llantas.');
  await writeFile(learning, `${JSON.stringify({ mensaje: 'Necesito cambio de frenos', sugerida: 'Hola', respuesta: 'Usa Buscar servicio', creado: '2026-01-01T00:00:00.000Z' })}\n`);
  let now = 1000;
  try {
    let db = await createMemoryDb({ dataDir, docsDir, aprendizajePath: learning, now: () => now });
    assert.equal((await stat(dataDir)).mode & 0o777, 0o700);
    assert.equal((await stat(join(dataDir, 'memoria.db'))).mode & 0o777, 0o600);
    assert.match(db.buscarConocimiento('vehiculo', 3), /Aceite/);
    assert.equal(db.ejemplosSimilares('frenos').length, 1);
    db.guardarAprendizaje({ message: 'Mi número es +593 99 123 4567', reply: 'Hola estimado cliente, revisa los frenos', suggested: 'Saludos' });
    db.guardarContexto('+593 99 000 0001', { status: 'registered' });
    assert.deepEqual(db.contextoCuenta('+593990000001'), { status: 'registered' });
    db.guardarResumen('+593 99 000 0001', 'Revisó su carro con Juan Perez');
    assert.ok(db.resumen('+593990000001'));
    db.cerrar();
    const bytes = await readFile(join(dataDir, 'memoria.db'));
    assert.equal(bytes.includes(Buffer.from('593990000001')), false);
    assert.equal(bytes.includes(Buffer.from('123 4567')), false);
    db = await createMemoryDb({ dataDir, docsDir, aprendizajePath: learning, now: () => now });
    assert.equal(db.ejemplosSimilares('frenos').length, 2);
    now += 86400001;
    assert.equal(db.contextoCuenta('+593990000001'), null);
    now -= 100000;
    db.guardarContexto('+593990000001', { status: 'x' }); db.guardarResumen('+593990000001', 'Resumen');
    db.olvidar('+593990000001');
    assert.equal(db.contextoCuenta('+593990000001'), null); assert.equal(db.resumen('+593990000001'), null);
    db.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('learned rules remain proposals until approval; only approved rules enter prompts', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-rules-'));
  try {
    const docsDir = join(root, 'memoria'); await mkdir(docsDir);
    const db = await createMemoryDb({ dataDir: join(root, 'data'), docsDir, now: () => Date.UTC(2026, 9, 30) });
    const { draftPrompt } = await import('../src/drafter.mjs');
    const { approveRule } = await import('../src/rules.mjs');
    const rejected = db.proponerRegla({ habilidad: 'busqueda', texto: 'No inventar disponibilidad.' });
    const approved = db.proponerRegla({ habilidad: 'busqueda', texto: 'Pedir ciudad antes de ofrecer un servicio.' });
    assert.equal((await draftPrompt({ role: 'dueno', message: 'Buscar servicio', memoryPath: db })).includes('Pedir ciudad'), false);
    assert.equal(db.decidirRegla(rejected, 'rechazada'), true);
    assert.equal(await approveRule(db, approved, { memoryDir: join(root, 'memoria'), mejorasPath: join(root, 'MEJORAS.md') }), true);
    assert.match(await draftPrompt({ role: 'dueno', message: 'Buscar servicio', memoryPath: db }), /Pedir ciudad antes/);
    assert.equal(db.regla(rejected).estado, 'rechazada');
    assert.throws(() => db.proponerRegla({ habilidad: 'otro', texto: 'x'.repeat(201) }), { message: 'INVALID_RULE' });
    db.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('FTS query treats user operators and punctuation as plain terms', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-memory-query-'));
  try {
    const docsDir = join(root, 'memoria'); await mkdir(docsDir); await writeFile(join(docsDir, 'x.md'), '## Aceite\nServicio de frenos para vehículo.');
    const db = await createMemoryDb({ dataDir: join(root, 'data'), docsDir });
    assert.doesNotThrow(() => db.buscarConocimiento('OR NOT " (NEAR(abc))', 5));
    db.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});
