import test from 'node:test';
import assert from 'node:assert/strict';
import { checkRow, digestManual, extractPages, mergeRows } from '../src/manual-digest.mjs';

// Manual de taller sintético: ningún fabricante real.
const PLAN = { page: 4, text: `PROGRAMA DE MANTENIMIENTO
Líquido de frenos: inspeccionar cada 10.000 km
Líquido de frenos: reemplazar cada 40.000 km o 24 meses
Condiciones severas: reemplazar líquido de frenos cada 20.000 km
Pastillas de freno: inspeccionar cada 10.000 km` };
const PROC = { page: 90, text: `Sección 5-2 Frenos. Procedimiento de reemplazo del líquido de frenos.
Use líquido DOT 4. Torque del purgador 8 Nm. Repuesto: Arandela del purgador ZZ-100, cantidad 4.` };
const meta = { marca: 'Marca Sintética', modelo: 'Modelo X', anioDesde: 2018, anioHasta: 2022, titulo: 'Taller de prueba', url: 'https://example.com/t.pdf', fecha: '2026-11-27', paginas: [4], tipo: 'taller' };
const row = (accion, km, cita, extra = {}) => ({ componente: 'Líquido de frenos', accion, km, cita, ...extra });
const answers = async prompt => JSON.stringify({ filas: prompt.includes('de un manual de taller') ? [{ operacion: 'Purgar y reemplazar el líquido', seccion: 'Sección 5-2', especificacion: 'DOT 4', torque: '8 Nm', repuestos: [{ nombre: 'Arandela del purgador', codigo: 'ZZ-100', cantidad: 4 }] }] : [
  row('inspeccionar', 10000, 'Líquido de frenos: inspeccionar cada 10.000 km'),
  row('reemplazar', 40000, 'Líquido de frenos: reemplazar cada 40.000 km o 24 meses', { meses: 24 }),
  row('reemplazar', 20000, 'Condiciones severas: reemplazar líquido de frenos cada 20.000 km', { severo: true }),
] });

test('revisar, cambiar y uso severo quedan en una fila, sin conflicto', async () => {
  const r = await digestManual([PLAN, PROC], meta, { ask: answers });
  assert.equal(r.counts.conflicto, 0);
  assert.equal(r.counts.aceptadas, 1);
  const [fila] = r.rows;
  assert.deepEqual([fila.km, fila.inspeccionKm, fila.severoKm], [40000, 10000, 20000]);
  assert.deepEqual([fila.especificacion, fila.torque, fila.procedimientoPag], ['DOT 4', '8 Nm', 90]);
  assert.deepEqual(r.pagesRead, [4, 90]);
  assert.match(r.csv, /Arandela del purgador \| ZZ-100 \| 4/);
  assert.match(r.csv, /"Sección 5-2, pág\. 90 \(manual de taller\)"/);
});

test('códigos, pares y especificaciones que no están impresos se descartan', () => {
  const r = checkRow(row('reemplazar', 40000, 'Líquido de frenos: reemplazar cada 40.000 km o 24 meses', { meses: 24, torque: '99 Nm', especificacion: 'DOT 5', seccion: '9-9', severo: true, repuestos: [{ nombre: 'Sello inventado', codigo: 'X1' }] }), { page: 4, text: PLAN.text.replace(/severas/, 'normales') });
  assert.deepEqual([r.torque, r.especificacion, r.seccion, r.repuestos, r.severo], ['', '', '', [], false]);
});

test('dos cifras para el mismo cambio siguen siendo conflicto', () => {
  const a = { estado: 'aceptada', componentId: 'fre_liquido', accion: 'reemplazar', km: 40000, months: null, page: 1 };
  assert.equal(mergeRows([a, { ...a, km: 30000, page: 2 }])[0].estado, 'conflicto');
});

test('un PDF sin texto avisa que necesita OCR y la falta de pdftotext dice cómo instalarlo', async () => {
  await assert.rejects(extractPages('x.pdf', { run: (_c, _a, _o, done) => done(null, '\f\f') }), /ocrmypdf/);
  await assert.rejects(extractPages('x.pdf', { run: (_c, _a, _o, done) => done(Object.assign(new Error('x'), { code: 'ENOENT' }), '') }), /poppler-utils/);
});
