import test from 'node:test';
import assert from 'node:assert/strict';
import { chmod, mkdtemp, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { cifrarPaquete, descifrarPaquete, escribirPayload, migracionExcluye, validarPayload, importarValidado, fusionarAprendizaje } from '../scripts/migrar.mjs';
import { createHash } from 'node:crypto';

const passphrase = 'frase-sintetica-de-prueba-2026';
const payload = (path, body) => {
  const name = Buffer.from(path), data = Buffer.from(body), head = Buffer.alloc(8);
  head.writeUInt32LE(name.length, 0); head.writeUInt32LE(data.length, 4);
  return Buffer.concat([Buffer.from('AMPPAY1\0'), head, name, data]);
};

test('migración sintética: ida y vuelta, frase incorrecta, alteración, ruta maliciosa y exclusiones', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'local-agent-migrar-'));
  try {
    const original = payload('codigo/README.md', 'memoria sintética');
    const encrypted = await cifrarPaquete(original, passphrase);
    assert.deepEqual(await descifrarPaquete(encrypted, passphrase), original);
    await assert.rejects(descifrarPaquete(encrypted, 'frase incorrecta'));
    const altered = Buffer.from(encrypted); altered[altered.length - 1] ^= 1;
    await assert.rejects(descifrarPaquete(altered, passphrase));
    const extracted = join(dir, 'ida-vuelta'); await escribirPayload(original, extracted);
    assert.equal(await readFile(join(extracted, 'codigo/README.md'), 'utf8'), 'memoria sintética');
    await assert.rejects(escribirPayload(payload('../escape.txt', 'x'), join(dir, 'malicioso')));
    await assert.rejects(stat(join(dir, 'escape.txt')));
    const names = await readdir(extracted, { recursive: true });
    assert.equal(names.some(name => name.includes('.env') || name.includes('whatsapp-profile')), false);
    assert.equal(migracionExcluye('.env'), true);
    assert.equal(migracionExcluye('data/whatsapp-profile/Default/Cookies'), true);
    assert.equal(migracionExcluye('data/human/pacing.json'), false);
    const manifest = { formato: 1, archivos: [{ path: 'codigo/.env.example', sha256: createHash('sha256').update('LOCAL_AGENT_TOKEN=\n').digest('hex') }, { path: 'data/permitidos.json', sha256: createHash('sha256').update('[]\n').digest('hex') }] };
    const files = [
      ['codigo/.env.example', 'LOCAL_AGENT_TOKEN=\n'],
      ['data/permitidos.json', '[]\n'],
      ['MANIFIESTO.json', `${JSON.stringify(manifest)}\n`],
    ];
    const chunks = [Buffer.from('AMPPAY1\0')];
    for (const [path, text] of files) { const n = Buffer.from(path), b = Buffer.from(text), h = Buffer.alloc(8); h.writeUInt32LE(n.length); h.writeUInt32LE(b.length, 4); chunks.push(h, n, b); }
    const full = Buffer.concat(chunks), check = join(dir, 'check'); await validarPayload(full, check);
    const target = join(dir, 'destino'); await importarValidado(full, target);
    assert.equal(await readFile(join(target, '.env'), 'utf8'), 'LOCAL_AGENT_TOKEN=\n');
    if (process.platform !== 'win32') assert.equal((await stat(target)).mode & 0o777, 0o700);
    if (process.platform !== 'win32') assert.equal((await stat(join(target, 'data/permitidos.json'))).mode & 0o777, 0o600);
    await assert.rejects(importarValidado(full, target), /Ya existe data/);
    await chmod(join(target, 'data'), 0o700);
    await writeFile(join(target, 'data', 'extra.txt'), 'preservar', { mode: 0o600 });
    await importarValidado(full, target, true);
    assert.equal(await readFile(join(target, 'data/extra.txt'), 'utf8'), 'preservar');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('fusión sintética: idempotente, estado de regla avanzado y casos únicos', async () => {
  const dir=await mkdtemp(join(tmpdir(),'local-agent-fusion-'));
  try {
    const {DatabaseSync}=await import('node:sqlite');
    const staged=join(dir,'staged'), destination=join(dir,'dest');
    const {mkdir}=await import('node:fs/promises'); await mkdir(join(staged,'data'),{recursive:true}); await mkdir(join(destination,'data'),{recursive:true});
    const schema=db=>db.exec(`CREATE TABLE aprendizaje(creado TEXT,rol TEXT,mensaje TEXT,sugerido TEXT,final TEXT,accion TEXT); CREATE TABLE reglas(creado TEXT,habilidad TEXT,texto TEXT,origen_evento INTEGER,estado TEXT,decidido TEXT); CREATE TABLE eventos(creado TEXT,canal TEXT,habilidad TEXT,accion_propuesta TEXT,decision TEXT,texto_final_anon TEXT,resultado TEXT); CREATE TABLE notas(fecha TEXT,habilidad TEXT,puntos INTEGER,total INTEGER,validos INTEGER,falsos_abiertos INTEGER);`);
    const src=new DatabaseSync(join(staged,'data/memoria.db'));schema(src);
    src.prepare('INSERT INTO reglas VALUES(?,?,?,?,?,?)').run('2026-01-01','servicio','Regla sintética',null,'aprobada','2026-01-02');
    src.prepare('INSERT INTO aprendizaje VALUES(?,?,?,?,?,?)').run('2026-01-01','operador','mensaje sintético','sugerencia','respuesta','ENVIO');src.close();
    await writeFile(join(staged,'data/eval-cases-placeholder'),'');
    await mkdir(join(staged,'data/eval'),{recursive:true});await writeFile(join(staged,'data/eval/casos-reales.json'),'[{"id":"sintetico-1","texto":"caso ficticio"}]');
    await fusionarAprendizaje(staged,destination);await fusionarAprendizaje(staged,destination);
    const db=new DatabaseSync(join(destination,'data/memoria.db'),{readOnly:true});
    assert.equal(db.prepare('SELECT count(*) n FROM reglas').get().n,1);assert.equal(db.prepare('SELECT estado FROM reglas').get().estado,'aprobada');assert.equal(db.prepare('SELECT count(*) n FROM aprendizaje').get().n,1);db.close();
    assert.equal(JSON.parse(await readFile(join(destination,'data/eval/casos-reales.json'),'utf8')).length,1);
  } finally { await rm(dir,{recursive:true,force:true}); }
});
