import test from 'node:test';
import assert from 'node:assert/strict';
import { agentOptions, askModel, createDrafterChain, drafterChainFromEnv, resolveCommand } from '../src/drafter.mjs';
import { checkReadiness, isTestMode, summarizeReadiness } from '../src/readiness.mjs';
import { draftSecondary } from '../src/secondary.mjs';

const job = { wamid: 'wweb:prueba-1', message: 'Hola quiero registrarme en AutoMantPro', category: 'automantpro', role: 'nuevo', chatSummary: '' };
const okFetch = text => async () => ({ ok: true, json: async () => ({ response: text }) });
const failFetch = async () => { throw new Error('offline'); };
// Fake execFile: answers per executable name, or fails like a CLI without credits.
const fakeRun = answers => (command, _args, _options, callback) => {
  const kind = Object.keys(answers).find(name => String(command).includes(name));
  if (kind && answers[kind] !== null) callback(null, answers[kind]); else callback(new Error('sin créditos'), '');
  return { stdin: { end() {} } };
};

test('uses the real .exe on Windows because execFile cannot start npm shims', () => {
  const exe = resolveCommand('opencode', { platform: 'win32', appData: 'C:\\AppData', exists: () => true });
  assert.match(exe, /opencode-ai[\\/]bin[\\/]opencode\.exe$/);
  assert.equal(resolveCommand('opencode', { platform: 'win32', appData: 'C:\\AppData', exists: () => false }), 'opencode');
  assert.equal(resolveCommand('claude', { platform: 'linux', appData: 'x', exists: () => true }), 'claude');
});

test('chain order is Claude, opencode, Ollama unless configured otherwise', () => {
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER: 'opencode' }), ['claude', 'opencode', 'ollama']);
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER_CHAIN: 'ollama, opencode,desconocido,ollama' }), ['ollama', 'opencode']);
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER: 'pymeagents' }), []);
});

test('the drafter command and model only apply to the agent they were set for', () => {
  const env = { LOCAL_AGENT_DRAFTER: 'opencode', LOCAL_AGENT_DRAFTER_COMMAND: 'C:\\opencode.exe', LOCAL_AGENT_DRAFTER_MODEL: 'opencode/modelo' };
  assert.deepEqual(agentOptions('opencode', env), { command: 'C:\\opencode.exe', model: 'opencode/modelo' });
  assert.deepEqual(agentOptions('claude', env), { command: null, model: null });
});

test('Ollama is called directly and failures return null', async () => {
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: okFetch('listo') }), 'listo');
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: async () => ({ ok: false }) }), null);
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: failFetch }), null);
});

test('falls back to opencode when Claude has no credits, and to Ollama when both fail', async () => {
  const env = { LOCAL_AGENT_DRAFTER: 'opencode' };
  const first = createDrafterChain({ env, run: fakeRun({ claude: null, opencode: '¡Hola! ¿Eres dueño de un auto, taller o almacén?' }), fetchImpl: failFetch });
  assert.deepEqual(first.kinds, ['claude', 'opencode', 'ollama']);
  assert.equal((await first.withAgent(job)).agent, 'opencode');
  const second = createDrafterChain({ env, run: fakeRun({ claude: null, opencode: null }), fetchImpl: okFetch('Hola, ¿eres dueño de un auto, taller o almacén?') });
  const drafted = await second.withAgent(job);
  assert.equal(drafted.agent, 'ollama');
  assert.match(drafted.reply, /taller/);
  const none = createDrafterChain({ env, run: fakeRun({}), fetchImpl: failFetch });
  assert.deepEqual(await none.withAgent(job), { reply: null, agent: null });
});

test('readiness reports every component and is ready with at least one drafter', async () => {
  const client = { ping: async () => ({ ok: true, whatsappDelivery: 'bridge' }) };
  const now = () => Date.parse('2026-11-03T15:00:00Z');
  const estado = await checkReadiness({ client, kinds: ['claude', 'opencode', 'ollama'], env: {}, now,
    ask: async kind => (kind === 'claude' ? null : 'listo'), statImpl: async () => ({ mtimeMs: now() - 5 * 60_000 }) });
  assert.equal(estado.listo, true);
  assert.equal(estado.redactorPrincipal, 'opencode');
  assert.equal(estado.modoPrueba, true);
  assert.equal(estado.puente.minutosDesdeActividad, 5);
  assert.match(summarizeReadiness(estado), /claude ✘ opencode ✔ ollama ✔ · puente ✔ · servidor ✔ → LISTO.*MODO PRUEBA/);
  const stale = await checkReadiness({ client, kinds: ['ollama'], env: {}, now, ask: async () => 'listo', statImpl: async () => ({ mtimeMs: now() - 90 * 60_000 }) });
  assert.equal(stale.listo, false);
});

test('test mode blocks sending unless explicitly turned off', () => {
  assert.equal(isTestMode({}), true);
  assert.equal(isTestMode({ LOCAL_AGENT_MODO_PRUEBA: '1' }), true);
  assert.equal(isTestMode({ LOCAL_AGENT_MODO_PRUEBA: '0' }), false);
});

test('secondary drafts use Ollama first and reject links in alerts', async () => {
  const calls = [];
  const plan = await draftSecondary({ tipo: 'plan_mantenimiento', datos: { marca: 'Marca X', kilometraje: 85000 }, env: {}, ask: async kind => { calls.push(kind); return 'Cambio de aceite cada 5.000 km.'; } });
  assert.deepEqual(calls, ['ollama']);
  assert.equal(plan.agente, 'ollama');
  const alert = await draftSecondary({ tipo: 'alerta', env: {}, ask: async kind => (kind === 'ollama' ? 'Visita https://ejemplo.test' : 'Te recordamos revisar tu auto.') });
  assert.equal(alert.agente, 'opencode');
  await assert.rejects(draftSecondary({ tipo: 'promocion_masiva', ask: async () => 'x' }), /SECONDARY_TYPE_NOT_ALLOWED/);
});
