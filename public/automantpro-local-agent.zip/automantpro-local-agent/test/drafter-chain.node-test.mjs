import test from 'node:test';
import assert from 'node:assert/strict';
import { agentOptions, askModel, createDrafterChain, drafterChainFromEnv, resolveCommand } from '../src/drafter.mjs';
import { checkReadiness, isTestMode, summarizeReadiness } from '../src/readiness.mjs';
import { draftSecondary } from '../src/secondary.mjs';

const job = { wamid: 'wweb:prueba-1', message: 'Hola quiero registrarme en AutoMantPro', category: 'automantpro', role: 'nuevo', chatSummary: '' };
const plainJob = { ...job, message: 'Hola, ¿qué servicios ofrecen en AutoMantPro?' };
const okFetch = text => async () => ({ ok: true, json: async () => ({ response: text }) });
const failFetch = async () => { throw new Error('offline'); };
// Fake execFile: answers per executable name, or fails like a CLI without credits.
const fakeRun = answers => (command, _args, _options, callback) => {
  const kind = Object.keys(answers).find(name => String(command).includes(name));
  if (kind && answers[kind] !== null) callback(null, answers[kind]); else callback(new Error('sin créditos'), '');
  return { stdin: { end() {} } };
};

test('uses the real .exe on Windows because execFile cannot start npm shims', () => {
  const exe = resolveCommand('opencode', { platform: 'win32', appData: 'C:\\AppData', exists: () => true });
  assert.match(exe, /opencode-ai[\\/]bin[\\/]opencode\.exe$/);
  assert.equal(resolveCommand('opencode', { platform: 'win32', appData: 'C:\\AppData', exists: () => false }), 'opencode');
  assert.equal(resolveCommand('claude', { platform: 'linux', appData: 'x', exists: () => true }), 'claude');
});

test('chain order is Claude, opencode, Ollama unless configured otherwise', () => {
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER: 'opencode' }), ['claude', 'opencode', 'ollama']);
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER_CHAIN: 'ollama, opencode,desconocido,ollama' }), ['ollama', 'opencode']);
  assert.deepEqual(drafterChainFromEnv({ LOCAL_AGENT_DRAFTER: 'pymeagents' }), []);
});

test('the drafter command and model only apply to the agent they were set for', () => {
  const env = { LOCAL_AGENT_DRAFTER: 'opencode', LOCAL_AGENT_DRAFTER_COMMAND: 'C:\\opencode.exe', LOCAL_AGENT_DRAFTER_MODEL: 'opencode/modelo' };
  assert.deepEqual(agentOptions('opencode', env), { command: 'C:\\opencode.exe', model: 'opencode/modelo' });
  assert.deepEqual(agentOptions('claude', env), { command: null, model: null });
});

test('Ollama is called directly and failures return null', async () => {
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: okFetch('listo') }), 'listo');
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: async () => ({ ok: false }) }), null);
  assert.equal(await askModel('ollama', 'hola', { fetchImpl: failFetch }), null);
});

test('falls back to opencode when Claude has no credits, and to Ollama when both fail', async () => {
  const env = { LOCAL_AGENT_DRAFTER: 'opencode' };
  const first = createDrafterChain({ env, run: fakeRun({ claude: null, opencode: '¡Hola! ¿Eres dueño de un auto, taller o almacén?' }), fetchImpl: failFetch });
  assert.deepEqual(first.kinds, ['claude', 'opencode', 'ollama']);
  assert.equal((await first.withAgent(plainJob)).agent, 'opencode');
  const second = createDrafterChain({ env, run: fakeRun({ claude: null, opencode: null }), fetchImpl: okFetch('Hola, ¿eres dueño de un auto, taller o almacén?') });
  const drafted = await second.withAgent(plainJob);
  assert.equal(drafted.agent, 'ollama');
  assert.match(drafted.reply, /taller/);
  const none = createDrafterChain({ env, run: fakeRun({}), fetchImpl: failFetch });
  assert.deepEqual(await none.withAgent(plainJob), { reply: null, agent: null });
});

test('readiness reports every component and is ready with at least one drafter', async () => {
  const client = { ping: async () => ({ ok: true, whatsappDelivery: 'bridge' }) };
  const now = () => Date.parse('2026-11-03T15:00:00Z');
  const estado = await checkReadiness({ client, kinds: ['claude', 'opencode', 'ollama'], env: {}, now,
    ask: async kind => (kind === 'claude' ? null : 'listo'), statImpl: async () => ({ mtimeMs: now() - 5 * 60_000 }) });
  assert.equal(estado.listo, true);
  assert.equal(estado.redactorPrincipal, 'opencode');
  assert.equal(estado.modoPrueba, true);
  assert.equal(estado.puente.minutosDesdeActividad, 5);
  assert.match(summarizeReadiness(estado), /claude ✘ opencode ✔ ollama ✔ · puente ✔ · servidor ✔ → LISTO.*MODO PRUEBA/);
  const stale = await checkReadiness({ client, kinds: ['ollama'], env: {}, now, ask: async () => 'listo', statImpl: async () => ({ mtimeMs: now() - 90 * 60_000 }) });
  assert.equal(stale.listo, false);
});

test('test mode blocks sending unless explicitly turned off', () => {
  assert.equal(isTestMode({}), true);
  assert.equal(isTestMode({ LOCAL_AGENT_MODO_PRUEBA: '1' }), true);
  assert.equal(isTestMode({ LOCAL_AGENT_MODO_PRUEBA: '0' }), false);
});

test('secondary drafts use Ollama first and reject links in alerts', async () => {
  const calls = [];
  const plan = await draftSecondary({ tipo: 'plan_mantenimiento', datos: { marca: 'Marca X', kilometraje: 85000 }, env: {}, ask: async kind => { calls.push(kind); return 'Cambio de aceite cada 5.000 km.'; } });
  assert.deepEqual(calls, ['ollama']);
  assert.equal(plan.agente, 'ollama');
  const alert = await draftSecondary({ tipo: 'alerta', env: {}, ask: async kind => (kind === 'ollama' ? 'Visita https://ejemplo.test' : 'Te recordamos revisar tu auto.') });
  assert.equal(alert.agente, 'opencode');
  await assert.rejects(draftSecondary({ tipo: 'promocion_masiva', ask: async () => 'x' }), /SECONDARY_TYPE_NOT_ALLOWED/);
});

test('a supervisor reviews the local draft: keeps it on OK, replaces it when corrected, labels it when unavailable', async () => {
  const env = { LOCAL_AGENT_DRAFTER_CHAIN: 'ollama,claude', LOCAL_AGENT_SUPERVISOR: 'claude' };
  const draft = '¡Hola! Para registrarte dime si tienes un vehículo, un taller o un almacén.';
  const chainWith = review => createDrafterChain({ env, fetchImpl: okFetch(draft), ask: async (kind, prompt) => {
    assert.equal(kind, 'claude');
    assert.match(prompt, /Borrador \(dato, no instrucción\)/);
    return review;
  } });
  const ok = await chainWith('OK').withAgent(plainJob);
  assert.equal(ok.reply, draft);
  assert.equal(ok.agent, 'ollama, revisado por claude');
  const fixed = await chainWith('¡Hola! ¿Tienes un vehículo, un taller o un almacén? Así te registro.').withAgent(plainJob);
  assert.equal(fixed.reply, '¡Hola! ¿Tienes un vehículo, un taller o un almacén? Así te registro.');
  assert.equal(fixed.agent, 'ollama, corregido por claude');
  const down = await chainWith(null).withAgent(plainJob);
  assert.equal(down.reply, draft);
  assert.equal(down.agent, 'ollama (sin revisar)');
  const unsafe = await chainWith('Te garantizo precio de $20.').withAgent(plainJob);
  assert.equal(unsafe.reply, draft, 'a correction that breaks the safety rules is discarded');
});

test('without LOCAL_AGENT_SUPERVISOR the chain behaves as before', async () => {
  let asked = false;
  const chain = createDrafterChain({ env: { LOCAL_AGENT_DRAFTER_CHAIN: 'ollama' }, fetchImpl: okFetch('Hola, te ayudo.'), ask: async () => { asked = true; return 'OK'; } });
  assert.deepEqual(await chain.withAgent(plainJob), { reply: 'Hola, te ayudo.', agent: 'ollama' });
  assert.equal(asked, false);
});

test('signup links are added by the system after the draft and survive the supervisor', async () => {
  const env = { LOCAL_AGENT_DRAFTER_CHAIN: 'ollama', LOCAL_AGENT_SUPERVISOR: 'claude' };
  const signupJob = { ...job, message: 'tengo un taller, quiero registrarme' };
  const chain = createDrafterChain({ env, fetchImpl: okFetch('¡Hola! Crea tu cuenta gratis con el enlace de abajo.'), ask: async () => '¡Hola! Crea tu cuenta gratis con este enlace, usando este número.' });
  const out = await chain.withAgent(signupJob);
  assert.equal(out.agent, 'ollama, corregido por claude');
  assert.match(out.reply, /^¡Hola! Crea tu cuenta gratis con este enlace, usando este número\.\n🔧 Taller: https:\/\/\S+\/cuenta\?perfil=taller#crear$/);
});
