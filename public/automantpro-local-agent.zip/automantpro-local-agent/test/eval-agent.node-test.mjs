import test from 'node:test';
import assert from 'node:assert/strict';
import { chmod, mkdtemp, readFile, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { chatGate, classifyChat } from '../src/bridge-core.mjs';
import { runAgentBatch, runEvaluation } from '../scripts/eval-agente.mjs';
import { createMemoryDb } from '../src/memory-db.mjs';
import { exportCorrectedCases, runNightCycle } from '../scripts/ciclo-nocturno.mjs';

const fixtures = JSON.parse(await readFile(new URL('./fixtures/conversaciones.json', import.meta.url), 'utf8'));
test('synthetic evaluation set has 60+ unique cases and keeps personal chats behind the gate', () => {
  assert.ok(fixtures.length >= 60);
  assert.equal(new Set(fixtures.map(item => item.id)).size, fixtures.length);
  for (const item of fixtures.filter(item => ['personal', 'familia', 'grupo', 'spam'].includes(item.categoria))) {
    const gate = chatGate({ title: item.title, preview: item.preview, phone: item.title.startsWith('+') ? item.title : null });
    assert.equal(gate.open, false, item.id);
  }
});
test('injected text remains a mention case and generic registration is not opened', () => {
  const injected = fixtures.find(item => item.id === '61');
  assert.equal(chatGate({ title: injected.title, preview: injected.preview, phone: injected.title }).open, true);
  assert.equal(classifyChat(injected.mensajes).category, 'automantpro');
  const generic = fixtures.find(item => item.id === '02');
  assert.equal(chatGate({ title: generic.title, preview: generic.preview, phone: generic.title }).open, false);
});
test('agent batch uses an injected executor, sends only the supplied synthetic cases and parses valid JSON', async () => {
  const item = fixtures.find(row => row.debeAbrir);
  let invoked = false;
  const rows = await runAgentBatch([item], { agent: 'opencode', run: async (command, args) => {
    invoked = true;
    assert.equal(command, 'opencode');
    assert.equal(args[0], 'run');
    assert.match(args.at(-1), new RegExp(`\\"id\\":\\"${item.id}\\"`));
    return { stdout: JSON.stringify({ casos: [{ id: item.id, categoria: 'automantpro', relacionado_automantpro: true, borrador: 'Podemos revisar tu vehículo.' }] }), stderr: '' };
  } });
  assert.equal(invoked, true);
  assert.equal(rows.get(item.id).borrador, 'Podemos revisar tu vehículo.');
});
test('agent batch rejects malformed output and more than 15 conversations', async () => {
  const item = fixtures.find(row => row.debeAbrir);
  const invalid = await runAgentBatch([item], { agent: 'opencode', run: async () => ({ stdout: 'no es json' }) });
  assert.equal(invalid.size, 0);
  await assert.rejects(runAgentBatch(Array(16).fill(item), { agent: 'opencode', run: async () => { throw new Error('no debe ejecutarse'); } }), /Máximo 15/);
});

test('corrected events export synthetic cases with private permissions and idempotent ids', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-eval-bank-'));
  try {
    const db = await createMemoryDb({ dataDir: join(root, 'data'), docsDir: join(root, 'memoria') });
    const eventId = db.registrarEvento({ habilidad: 'servicio', accionPropuesta: 'Quiero frenos', decision: 'CORREGIDO', textoFinal: 'Soy Juan Perez, mi número +593 99 123 4567. Revisa frenos.', casoEval: { mensaje: 'Soy Juan Perez, necesito frenos +593 99 123 4567', sugerido: 'Hola Juan', final: 'Podemos revisar tus frenos.' } });
    const path = join(root, 'data/eval/casos-reales.json');
    assert.equal(await exportCorrectedCases(db, path), 1);
    assert.equal(await exportCorrectedCases(db, path), 1);
    const [item] = JSON.parse(await readFile(path, 'utf8'));
    assert.equal(item.id, `real-${eventId}`);
    assert.equal(item.title, '+593 99 000 0000');
    assert.doesNotMatch(JSON.stringify(item), /Juan Perez|123 4567/);
    assert.equal((await stat(path)).mode & 0o777, 0o600);
    assert.equal(db.eventosCorregidosNoExportados().length, 0);
    db.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('eval records per-skill notes; night cycle calls Codex eval and stores reviewer proposals as pending rules', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-night-cycle-'));
  try {
    const db = await createMemoryDb({ dataDir: join(root, 'data'), docsDir: join(root, 'memoria') });
    const item = { id: 'test-1', title: '+593 99 000 0001', preview: 'AutoMantPro consulta', categoria: 'automantpro', debeAbrir: true, grupo: false, servicio: 'otro', mensajes: [{ text: 'AutoMantPro consulta de servicio' }], respuestaEsperada: [] };
    const evaluation = async options => runEvaluation({ ...options, cases: [item], executeAgent: async () => new Map(), reviewerRun: async () => ({ stdout: '- Pedir el sector antes de cotizar.' }) });
    const { result, notes, proposals } = await runNightCycle({ db, dataDir: join(root, 'data'), evaluate: evaluation });
    assert.equal(result.agente, 'codex');
    assert.equal(result.casos, 1);
    assert.ok(notes.length > 0);
    assert.equal(proposals, 1);
    assert.equal(db.listarReglas('propuesta')[0].texto, 'Pedir el sector antes de cotizar.');
    db.cerrar();
  } finally { await rm(root, { recursive: true, force: true }); }
});
