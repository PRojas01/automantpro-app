import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, chmod, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApprovalInbox, writeInboxDecision } from '../src/approval-inbox.mjs';

const sample = { wamid: 'synthetic_job_01', channel: 'whatsapp', role: 'dueno', category: 'automantpro',
  phone: '593990000001', message: 'Necesito revisar frenos' };
async function fixture() {
  const root = await mkdtemp(join(tmpdir(), 'amp-inbox-'));
  const inbox = createApprovalInbox({ root });
  const pending = await inbox.create(sample, 'Con gusto le ayudamos.');
  return { root, inbox, pending, close: () => rm(root, { recursive: true, force: true }) };
}

test('writes masked pending with fingerprint and accepts matching human decision', async () => {
  const f = await fixture();
  try {
    const file = (await import('node:fs/promises')).readdir;
    const names = await file(f.inbox.dirs.pendingDir);
    const raw = await readFile(join(f.inbox.dirs.pendingDir, names[0]), 'utf8');
    assert.ok(!raw.includes('593990000001'));
    assert.ok(raw.includes('…0001'));
    await writeInboxDecision({ root: f.root, jobId: f.pending.jobId, accion: 'ENVIO' });
    const decision = await f.inbox.awaitDecision(f.pending.jobId, new AbortController().signal, 5);
    assert.equal(decision.action, 'send');
    assert.equal(decision.reply, 'Con gusto le ayudamos.');
  } finally { await f.close(); }
});

test('rejects stale pending work', async () => {
  const f = await fixture();
  try {
    const stale = createApprovalInbox({ root: f.root, now: () => Date.now() + 25 * 60 * 60 * 1000 });
    const decision = await stale.awaitDecision(f.pending.jobId, new AbortController().signal, 1);
    assert.equal(decision.expired, true);
  } finally { await f.close(); }
});

test('decision requires owner and 0600 permissions', async () => {
  const f = await fixture();
  try {
    const names = await (await import('node:fs/promises')).readdir(f.inbox.dirs.pendingDir);
    await chmod(join(f.inbox.dirs.pendingDir, names[0]), 0o644);
    await assert.rejects(writeInboxDecision({ root: f.root, jobId: f.pending.jobId, accion: 'IGNORAR' }), { message: 'INVALID_PENDING_PERMISSIONS' });
  } finally { await f.close(); }
});

test('rejects invalid outbound text and EJECUTAR without SI', async () => {
  const f = await fixture();
  try {
    await assert.rejects(writeInboxDecision({ root: f.root, jobId: f.pending.jobId, accion: 'ENVIO', texto: 'x'.repeat(2001) }), { message: 'INVALID_TEXT' });
    await assert.rejects(writeInboxDecision({ root: f.root, jobId: f.pending.jobId, accion: 'EJECUTAR', texto: 'comando' }), { message: 'EXECUTE_REQUIRES_SI' });
  } finally { await f.close(); }
});

test('stores proposed action and requires high-risk confirmation plus exact command', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-inbox-action-'));
  try {
    const inbox = createApprovalInbox({ root });
    const pending = await inbox.create({ ...sample, wamid: 'synthetic_action_01', message: 'Aceptar oferta 2 de S-ABC123', context: { role: 'dueno', vehicleId: 'veh-sintetico' } }, 'Borrador sintético');
    assert.equal(pending.accionPropuesta.comando, 'Aceptar S-ABC123 2');
    assert.equal(pending.riesgo, 'alto');
    await assert.rejects(writeInboxDecision({ root, jobId: pending.jobId, accion: 'EJECUTAR', texto: 'Aceptar S-ABC123 2' }), /EXECUTE_REQUIRES_SI/);
    await assert.rejects(writeInboxDecision({ root, jobId: pending.jobId, accion: 'EJECUTAR', texto: 'Cancelar', confirmar: 'SI' }), /COMMAND_DOES_NOT_MATCH_PROPOSAL/);
    await writeInboxDecision({ root, jobId: pending.jobId, accion: 'EJECUTAR', texto: 'Aceptar S-ABC123 2', confirmar: 'SI' });
    const decision = await inbox.awaitDecision(pending.jobId, new AbortController().signal, 5);
    assert.equal(decision.action, 'execute');
    assert.equal(decision.command, 'Aceptar S-ABC123 2');
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('IGNORAR suggestion is labeled as discard and cannot be sent as the default reply', async () => {
  const root = await mkdtemp(join(tmpdir(), 'amp-inbox-ignore-'));
  try {
    const inbox = createApprovalInbox({ root });
    const pending = await inbox.create({ ...sample, wamid: 'synthetic_ignore_01' }, 'IGNORAR');
    assert.equal(pending.tipoSugerencia, 'descartar');
    await assert.rejects(writeInboxDecision({ root, jobId: pending.jobId, accion: 'ENVIO' }), { message: 'TEXT_REQUIRED_FOR_IGNORE_SUGGESTION' });
    await writeInboxDecision({ root, jobId: pending.jobId, accion: 'ENVIO', texto: 'Respuesta escrita por operador' });
    const decision = await inbox.awaitDecision(pending.jobId, new AbortController().signal, 5);
    assert.equal(decision.reply, 'Respuesta escrita por operador');
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('inbox shows which chat a message came from, masked', async () => {
  const { mkdtemp } = await import('node:fs/promises'); const { tmpdir } = await import('node:os'); const { join } = await import('node:path');
  const { createApprovalInbox, recordOrigin } = await import('../src/approval-inbox.mjs');
  const root = await mkdtemp(join(tmpdir(), 'bandeja-'));
  await recordOrigin(root, 'wweb:wweb_abc', '593990000001');
  const inbox = createApprovalInbox({ root });
  const pending = await inbox.create({ wamid: 'wweb:wweb_abc', channel: 'whatsapp', role: 'nuevo', message: 'Hola' }, 'Hola');
  assert.match(pending.telefonoEnmascarado, /0001$/);
  assert.equal(pending.telefonoEnmascarado.includes('593990'), false);
});
