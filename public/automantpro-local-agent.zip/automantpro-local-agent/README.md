# Agente local de pruebas con aprobación humana

Cliente independiente, sin dependencias npm. El nuevo equipo Ubuntu necesita Node.js **22**, terminal interactiva e Internet HTTPS hacia la API de GoDaddy. No necesita acceso a MySQL ni puertos entrantes. No llama a Meta ni a un proveedor de IA. El servidor conserva la cola, autoriza acciones y registra las salidas. Aceptación por servidor no equivale a entrega por WhatsApp.

## Preparar GoDaddy

El responsable despliega la API con las rutas `/api/v1/local-agent/jobs/*`. Un administrador entra en `/admin/local-agent`, confirma su contraseña y genera la clave del equipo. El panel la muestra una vez; el servidor conserva solo su hash en `AppSetting`. Entréguela por un canal privado al operador y configúrela como `LOCAL_AGENT_TOKEN` solo en su equipo; nunca en GitHub, ZIP, historial ni capturas. No requiere editar variables de GoDaddy. Rotar o revocar desde el panel invalida la clave anterior. Habilitar el equipo desde ese panel activa también `/pruebas`. La conexión Meta/WhatsApp requiere configuración y aprobación de lanzamiento separadas. Primero pruebe trabajos `pilot` y consulte sus salidas en plataforma.

## Instalar en Ubuntu nuevo

Instale Node22 mediante el mecanismo ya aprobado de su equipo (verifique `node --version`: `v22.x`). No ejecute instaladores descargados con el token configurado. Descargue ZIP y checksum del mismo candidato. El archivo contiene código, no Node ni secretos.

```sh
sha256sum -c automantpro-local-agent.zip.sha256
unzip automantpro-local-agent.zip
cd automantpro-local-agent
umask 077
cp .env.example .env
chmod 600 .env
```

Abra `.env` en su editor local. Configure `LOCAL_AGENT_URL=https://automantpro.app` (o URL HTTPS del piloto) y reemplace el token de ejemplo. Verifique carpeta privada del operador; no sincronice `.env`. No se requiere `npm install`.

```sh
node --test test/*.node-test.mjs
node src/main.mjs
```

Para instalación permanente sin root: `bash scripts/install-ubuntu.sh`. Copia solo cliente/documentación a `~/.local/share/automantpro-local-agent`, crea `.env` con permiso 0600 sin sobreescribir configuración existente y el lanzador `~/.local/bin/automantpro-agent`. Edite el `.env` de esa instalación e inicie el lanzador en terminal. El instalador verifica Node22; no descarga paquetes, no crea servicio systemd y no conecta por sí solo al servidor.

El operador ve cada mensaje, redacta una respuesta de hasta 2000 caracteres y confirma exactamente **ENVIO** para responder o **EJECUTAR** para autorizar el comando de marketplace del mensaje original. El servidor vuelve a comprobar usuario, rol y argumentos. El borrador no define argumentos de una acción. Cualquier otra confirmación o borrador vacío pospone 60 segundos. Cada reserva se renueva cada 30 segundos y se comprueba antes de completar. Al perder conexión o reserva no se envía el borrador. Ctrl+C cancela edición y pospone cuando la reserva sigue vigente; si falla la red, el servidor recupera el trabajo vencido.

Mantenga el equipo despierto durante la atención. Para terminal persistente en Ubuntu puede usar `tmux new -s automantpro` y ejecutar el comando anterior. Reanude con `tmux attach -t automantpro`. No active systemd para este modo: requiere una persona en terminal y nunca aprueba automáticamente. Cerrar el proceso no cancela la solicitud del usuario; la cola del servidor permite recuperarla. No redirija la sesión a logs con datos personales. Tras un timeout de finalización consulte las salidas en plataforma antes de repetir, para evitar duplicar acciones.

## Windows y macOS

Instale Node22, descomprima ZIP y abra terminal en la carpeta. Copie `.env.example` a `.env` y edite URL/token. macOS: `chmod 600 .env`, luego `node src/main.mjs`. Windows PowerShell: `Copy-Item .env.example .env`; restrinja ACL del archivo al operador mediante Propiedades > Seguridad antes de iniciarlo. Ejecute `node src/main.mjs`. No necesita Bash ni compilador.

## Crear candidato portable

Desde esta carpeta: `npm test` y `npm run bundle`. `dist/automantpro-local-agent.zip` incluye solo la lista explícita de código/documentación; `.env`, logs y secretos quedan fuera. Incluye checksum SHA256 para validar integridad. No distribuya la carpeta completa del equipo configurado.

## Prueba mínima

1. Crear un mensaje piloto desde un usuario autorizado; confirmar que aparece con canal `pilot`.
2. Escribir un borrador y confirmar `ENVIO`; comprobar salida persistida sin acción de marketplace.
3. Enviar comando válido de marketplace y confirmar `EJECUTAR`; comprobar autorización, acción y salida desde plataforma.
4. Intentar una acción con rol incorrecto; el servidor debe rechazarla sin mutación.
5. Posponer, cortar Internet y reiniciar; comprobar recuperación sin duplicar salida/acción.
6. Rotar token; el agente debe detenerse con `AUTH_REJECTED`.

Los tests incluidos verifican el contrato del cliente con fetch simulado. Estas pruebas no acreditan todavía conectividad de GoDaddy ni entrega WhatsApp; la prueba anterior sí requiere servidor desplegado.
