# Agente local de pruebas con aprobación humana

Cliente independiente, sin dependencias npm. El nuevo equipo Ubuntu necesita Node.js **22**, terminal interactiva e Internet HTTPS hacia la API de GoDaddy. No necesita acceso a MySQL ni puertos entrantes. No llama a Meta ni a un proveedor de IA. El servidor conserva la cola, autoriza acciones y registra las salidas. Aceptación por servidor no equivale a entrega por WhatsApp.

## Preparar GoDaddy

El responsable despliega la API con las rutas `/api/v1/local-agent/jobs/*`. Un administrador entra en `/admin/local-agent`, confirma su contraseña y genera la clave del equipo. El panel la muestra una vez; el servidor conserva solo su hash en `AppSetting`. Entréguela por un canal privado al operador y configúrela como `LOCAL_AGENT_TOKEN` solo en su equipo; nunca en GitHub, ZIP, historial ni capturas. No requiere editar variables de GoDaddy. Rotar o revocar desde el panel invalida la clave anterior. Habilitar el equipo desde ese panel activa también `/pruebas`. La conexión Meta/WhatsApp requiere configuración y aprobación de lanzamiento separadas. Primero pruebe trabajos `pilot` y consulte sus salidas en plataforma.

## Instalar en Ubuntu nuevo

Instale Node22 mediante el mecanismo ya aprobado de su equipo (verifique `node --version`: `v22.x`). No ejecute instaladores descargados con el token configurado. Descargue ZIP y checksum del mismo candidato. El archivo contiene código, no Node ni secretos.

```sh
sha256sum -c automantpro-local-agent.zip.sha256
unzip automantpro-local-agent.zip
cd automantpro-local-agent
umask 077
cp .env.example .env
chmod 600 .env
```

Abra `.env` en su editor local. Configure `LOCAL_AGENT_URL=https://automantpro.app` (o URL HTTPS del piloto) y reemplace el token de ejemplo. Verifique carpeta privada del operador; no sincronice `.env`. No se requiere `npm install`.

```sh
node --test test/*.node-test.mjs
node src/main.mjs
```

Para instalación permanente sin root en el equipo del operador:

```sh
bash scripts/install-ubuntu.sh --whatsapp --claude
automantpro-doctor
```

Copia el agente a `~/.local/share/automantpro-local-agent`, crea `.env` con permiso 0600 sin sobreescribir configuración existente y deja los lanzadores `automantpro-agent` (operador), `automantpro-whatsapp` (puente, con `--whatsapp`) y `automantpro-doctor` (comprobación) en `~/.local/bin`. Con `--whatsapp` instala la única dependencia fijada (`playwright-core`) desde npm, sin descargar navegadores, y detecta Chrome o Chromium. Con `--claude` activa los borradores de Claude. No crea servicio systemd ni conecta por sí solo al servidor. `automantpro-doctor` revisa Node 22, el permiso de `.env`, la URL, la clave (sin mostrarla), que el servidor tenga el agente habilitado y el canal WhatsApp elegido, el navegador y el CLI `claude`.

El operador ve cada mensaje, la acción propuesta y su riesgo. Confirma exactamente **ENVIO** para responder o **EJECUTAR** para autorizar el comando propuesto; si faltan campos, el borrador pregunta por ellos y no se permite ejecutar. Las acciones de riesgo alto (aceptar oferta, confirmar cita, cerrar OT o cancelar) requieren además confirmar **SI**. La terminal admite `EJECUTAR: <comando>` con confirmación posterior; solo permite el comando propuesto. La bandeja se decide con `node scripts/bandeja.mjs decidir <jobId> EJECUTAR --texto "<comando propuesto>" [--confirmar SI]`. El servidor vuelve a comprobar usuario, rol y argumentos; su resultado redactado sustituye el borrador. Cada reserva se renueva cada 30 segundos y se comprueba antes de completar. Al perder conexión o reserva se cierra la pregunta. Revocar el equipo en el panel detiene el cliente con LOCAL_AGENT_DISABLED; rotar clave lo detiene con AUTH_REJECTED.

Las propuestas usan los comandos existentes. El contrato marketplace no tiene comando para crear/consultar plan ni para registrar/recuperar historial; esos casos se derivan a los comandos de cuenta disponibles cuando existen (por ejemplo `Plan` y `Último servicio | servicio | km | AAAA-MM`). No se inventan comandos marketplace para cubrirlos. Ver el inventario con sus rutas de origen en `memoria/comandos.md`.

Mantenga el equipo despierto durante la atención. Para terminal persistente en Ubuntu puede usar `tmux new -s automantpro` y ejecutar el comando anterior. Reanude con `tmux attach -t automantpro`. No active systemd para este modo: requiere una persona en terminal y nunca aprueba automáticamente. Cerrar el proceso no cancela la solicitud del usuario; la cola del servidor permite recuperarla. No redirija la sesión a logs con datos personales. Tras un timeout de finalización consulte las salidas en plataforma antes de repetir, para evitar duplicar acciones.

## Puente WhatsApp Web (piloto)

Proceso aparte, `node src/whatsapp-bridge.mjs` (lanzador `automantpro-whatsapp`), para atender por WhatsApp antes de conectar la API oficial. Se basa en la mesa de pruebas de PYMEAgents (`src/vendor/pymeagents/`, con su commit de origen anotado).

- **Servidor:** `WHATSAPP_DELIVERY=bridge` en el hosting. Con `cloud` envía la API oficial y el puente queda rechazado; con `off` (defecto) nadie envía. Nunca entregan los dos.
- **Equipo:** Chrome o Chromium instalado (`WHATSAPP_BROWSER_PATH`) y `npm install playwright-core@1.62.1` en la carpeta del agente. No descarga navegadores.
- **Primera vez:** se abre una ventana de WhatsApp Web; escanee el QR desde *Dispositivos vinculados* del teléfono del piloto. La sesión queda en `data/whatsapp-profile` (permiso 0700, fuera de Git y del ZIP).
- **Entrada:** al arrancar y en cada vuelta revisa chats que pasaron el filtro, aunque la vista previa no haya cambiado; solo reenvía mensajes si el último lo escribió el contacto. Fotos y audios llegan como aviso para revisarlos en WhatsApp.
- **Identidad y permitidos:** `data/permitidos.json` mantiene números que pasaron por una mención de AutoMantPro/AMP o por autorización del servidor. Se conserva como máximo 500 entradas y se quitan primero las de actividad más antigua. Las listas manuales opcionales se leen desde `data/permitidos.txt` y desde `permitidos.txt` en la raíz del paquete; sus entradas tienen prioridad y no se reescriben. Un contacto con nombre solo se abre después de pasar el filtro por nombre manual o por vista previa y el puente obtiene su número desde la ficha. Si falta un número válido, no procesa el chat.
- **Datos locales:** cada entrada guarda número, HMAC-SHA256 del nombre normalizado, origen, alta y última actividad; el nombre legible no se almacena. La clave aleatoria está en `data/.clave-contactos`; ambos archivos usan permiso 0600 dentro de `data/`, que está excluido de Git. `BAJA` marca el contacto para que deje de abrirse y `ALTA` lo reactiva. Los comandos se reenvían al servidor junto con el mensaje normal, sujeto al filtro habitual.
- **Salida:** solo lo que autoriza el servidor (respuestas aprobadas con `ENVIO`/`EJECUTAR`, avisos a usuarios vinculados y una bienvenida fija a números sin cuenta). Ritmo humano: 60 s entre envíos, 10 por hora, 30 por día, horario 8–21 (`HUMAN_ACTIVE_HOURS`). Lo que no cabe queda pendiente y se reintenta.
- Automatizar WhatsApp Web no está permitido por WhatsApp y el número puede ser bloqueado. Use un número del piloto, nunca el que se conectará a la API oficial.

## Borradores con Codex u Opencode (opcional)

Define `LOCAL_AGENT_DRAFTER=codex` o `LOCAL_AGENT_DRAFTER=opencode` para sugerir borradores con el contexto de cuenta del servidor y la memoria documental de `memoria/`. Opencode usa `opencode/deepseek-v4.1-flash-free` por defecto; se cambia con `LOCAL_AGENT_DRAFTER_MODEL`. Codex ejecuta `codex exec` en sandbox de solo lectura. La respuesta siempre requiere revisión y aprobación humana; si el CLI falla, se puede responder manualmente. `LOCAL_AGENT_DRAFTER=claude` sigue disponible como opción explícita.

## Memoria local

El operador y el puente mantienen `data/memoria.db` (SQLite con FTS5, permisos 0600 en un directorio 0700). Indexa por secciones los Markdown de `memoria/` y detecta cambios por hash. Guarda aprendizaje anonimizado, contexto de cuenta por HMAC de número con `.clave-contactos` (caduca a las 24 h) y un resumen breve anonimizado. El JSONL histórico se importa una vez y se conserva. `BAJA` elimina de SQLite el contexto y el resumen del contacto. El punto de extensión `MEMORY_VECTORS=1` está reservado para una fase futura y no activa embeddings.

## Migrar a otro equipo

La migración conserva la memoria SQLite mediante una instantánea, permitidos, clave HMAC, ritmo humano, bandeja pendiente y casos reales de evaluación. El archivo `.ampkg` cifra todo con AES-256-GCM; la frase se escribe de forma oculta y no debe enviarse junto al archivo.

1. Detenga el puente y el operador en el equipo actual.
2. Exporte desde la carpeta del paquete: `node scripts/migrar.mjs exportar /ruta/segura/automantpro.ampkg`. Escriba una frase larga cuando se solicite; no la ponga en argumentos ni variables de entorno.
3. Copie el `.ampkg` al equipo nuevo por USB cifrado o `scp` en una conexión de confianza. Transmita la frase por otro canal.
4. En Ubuntu nuevo instale Node 22 y ejecute `bash scripts/install-ubuntu.sh --whatsapp` sobre el código del paquete.
5. Importe con `node scripts/migrar.mjs importar /ruta/automantpro.ampkg /ruta/automantpro-local-agent`. Para verificar el manifiesto sin aplicar los archivos, use `node scripts/migrar.mjs verificar /ruta/automantpro.ampkg`.
6. Complete `.env` en el equipo nuevo con un `LOCAL_AGENT_TOKEN` recién generado desde el panel. No copie el token anterior.
7. Ejecute `npm run doctor`, luego `npm run puente` y escanee el QR con el teléfono del número oficial. Después ejecute `npm run operador`.
8. Desactive el equipo viejo antes de operar. Nunca mantenga dos puentes activos con el mismo número.

Importar rechaza un `data/` existente; `--forzar` reemplaza únicamente archivos de datos incluidos en el paquete y preserva los demás archivos y el código existente. La sesión `data/whatsapp-profile/` se excluye y se vincula de nuevo mediante QR.

### Sincronizar aprendizaje entre equipos

Para llevar reglas, ejemplos anonimizados, eventos, notas y casos reales entre este equipo y operación, exporte únicamente ese aprendizaje: `node scripts/migrar.mjs exportar --solo-aprendizaje /ruta/segura/aprendizaje.ampkg`. La frase se solicita sin eco. Este paquete no contiene `.clave-contactos`, permitidos, conversaciones ni estado de WhatsApp.

En el otro equipo, con su carpeta del agente como destino, ejecute `node scripts/migrar.mjs importar --fusionar /ruta/aprendizaje.ampkg /ruta/automantpro-local-agent`. La fusión puede repetirse: deduplica texto y clave natural. En reglas conserva la decisión más avanzada y una regla rechazada nunca se reactiva. El comando muestra las aprobadas que todavía deben incorporarse manualmente a `memoria/aprendidas.md` y al código. Repita el mismo flujo en sentido contrario para devolver el aprendizaje de operación.

## Borradores con Claude (opcional)

Con `LOCAL_AGENT_DRAFTER=claude` y el CLI `claude` instalado y con sesión iniciada, la terminal del operador muestra un borrador sugerido para cada mensaje. Enter lo usa, otro texto lo reemplaza y `-` pospone; el envío sigue exigiendo `ENVIO` o `EJECUTAR`. Claude corre sin shell, en una carpeta temporal vacía, sin herramientas que actúen sobre el equipo y sin ver la clave del agente. El mensaje del contacto se le pasa como dato, no como instrucción. Si Claude no responde, se escribe la respuesta a mano.

## Aprobar desde el chat

Inicia `node src/main.mjs --bandeja` o define `OPERATOR_MODE=bandeja`. Cada consulta pendiente aparece en `data/bandeja/pendientes/` con teléfono enmascarado, acción propuesta y riesgo. Consulta con `node scripts/bandeja.mjs listar`; usa `ENVIO`, `IGNORAR` o `POSPONER`, o ejecuta con `node scripts/bandeja.mjs decidir <jobId> EJECUTAR --texto "<comando propuesto>" [--confirmar SI]`. Los archivos se validan por permisos 0600, propietario, huella, campos requeridos y antigüedad máxima de 24 horas. Las acciones de riesgo alto necesitan `--confirmar SI`; el texto debe coincidir exactamente con el comando propuesto.

## Agente PYMEAgents y tipos de trabajo

`LOCAL_AGENT_DRAFTER=pymeagents` activa el clasificador local portado de PYMEAgents (`d803ca5`) para sugerir respuestas en español; la persona operadora sigue revisando y confirmando cada salida con **ENVIO**. El guard revisa los mensajes antes de generar borradores y los marcados como posibles instrucciones incrustadas se responden a mano. La lista cerrada de trabajos incluye responder y clasificar consultas, avisos por WhatsApp (que solo entrega el outbox del servidor), pruebas, capturas, revisión de diff y reporte de estado. Las tareas locales de desarrollo requieren `LOCAL_AGENT_DEV_JOBS=true` y una ruta existente en `LOCAL_AGENT_REPO_DIR`; por defecto están apagadas. El operador puede ejecutar los trabajos de desarrollo permitidos con `node src/run-job.mjs <tipo>`.

### Tareas tipadas

El panel `/admin/local-agent` permite encolar tareas con clave de idempotencia. Para procesarlas sin terminal interactiva, ejecute `npm run tasks` (o `node src/task-worker.mjs` desde esta carpeta). El worker solo procesa tareas tipadas, devuelve de inmediato cualquier trabajo de mensaje y se detiene ante credenciales rechazadas o acceso revocado.

## Windows y macOS

Instale Node22, descomprima ZIP y abra terminal en la carpeta. Copie `.env.example` a `.env` y edite URL/token. macOS: `chmod 600 .env`, luego `node src/main.mjs`. Windows PowerShell: `Copy-Item .env.example .env`; restrinja ACL del archivo al operador mediante Propiedades > Seguridad antes de iniciarlo. Ejecute `node src/main.mjs`. No necesita Bash ni compilador.

## Crear candidato portable

Desde esta carpeta: `npm test` y `npm run bundle`. `dist/automantpro-local-agent.zip` incluye solo la lista explícita de código/documentación; `.env`, logs y secretos quedan fuera. Incluye checksum SHA256 para validar integridad. No distribuya la carpeta completa del equipo configurado.

## Prueba mínima

1. Crear un mensaje piloto desde un usuario autorizado; confirmar que aparece con canal `pilot`.
2. Escribir un borrador y confirmar `ENVIO`; comprobar salida persistida sin acción de marketplace.
3. Enviar comando válido de marketplace y confirmar `EJECUTAR`; comprobar autorización, acción y salida desde plataforma.
4. Intentar una acción con rol incorrecto; el servidor debe rechazarla sin mutación.
5. Posponer, cortar Internet y reiniciar; comprobar recuperación sin duplicar salida/acción.
6. Rotar token; el agente debe detenerse con `AUTH_REJECTED`.

Los tests incluidos verifican el contrato del cliente con fetch simulado. Estas pruebas no acreditan todavía conectividad de GoDaddy ni entrega WhatsApp; la prueba anterior sí requiere servidor desplegado.
