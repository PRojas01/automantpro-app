# Agente local de pruebas con aprobación humana

Cliente independiente, sin dependencias npm. El nuevo equipo Ubuntu necesita Node.js **22**, terminal interactiva e Internet HTTPS hacia la API de GoDaddy. No necesita acceso a MySQL ni puertos entrantes. No llama a Meta ni a un proveedor de IA. El servidor conserva la cola, autoriza acciones y registra las salidas. Aceptación por servidor no equivale a entrega por WhatsApp.

## Preparar GoDaddy

El responsable despliega la API con las rutas `/api/v1/local-agent/jobs/*`. Un administrador entra en `/admin/local-agent`, confirma su contraseña y genera la clave del equipo. El panel la muestra una vez; el servidor conserva solo su hash en `AppSetting`. Entréguela por un canal privado al operador y configúrela como `LOCAL_AGENT_TOKEN` solo en su equipo; nunca en GitHub, ZIP, historial ni capturas. No requiere editar variables de GoDaddy. Rotar o revocar desde el panel invalida la clave anterior. Habilitar el equipo desde ese panel activa también `/pruebas`. La conexión Meta/WhatsApp requiere configuración y aprobación de lanzamiento separadas. Primero pruebe trabajos `pilot` y consulte sus salidas en plataforma.

## Instalar en Ubuntu nuevo

Instale Node22 mediante el mecanismo ya aprobado de su equipo (verifique `node --version`: `v22.x`). No ejecute instaladores descargados con el token configurado. Descargue ZIP y checksum del mismo candidato. El archivo contiene código, no Node ni secretos.

```sh
sha256sum -c automantpro-local-agent.zip.sha256
unzip automantpro-local-agent.zip
cd automantpro-local-agent
umask 077
cp .env.example .env
chmod 600 .env
```

Abra `.env` en su editor local. Configure `LOCAL_AGENT_URL=https://automantpro.app` (o URL HTTPS del piloto) y reemplace el token de ejemplo. Verifique carpeta privada del operador; no sincronice `.env`. No se requiere `npm install`.

```sh
node --test test/*.node-test.mjs
node src/main.mjs
```

Para instalación permanente sin root en el equipo del operador:

```sh
bash scripts/install-ubuntu.sh --whatsapp --claude
automantpro-doctor
```

Copia el agente a `~/.local/share/automantpro-local-agent`, crea `.env` con permiso 0600 sin sobreescribir configuración existente y deja los lanzadores `automantpro-agent` (operador), `automantpro-whatsapp` (puente, con `--whatsapp`) y `automantpro-doctor` (comprobación) en `~/.local/bin`. Con `--whatsapp` instala la única dependencia fijada (`playwright-core`) desde npm, sin descargar navegadores, y detecta Chrome o Chromium. Con `--claude` activa los borradores de Claude. No crea servicio systemd ni conecta por sí solo al servidor. `automantpro-doctor` revisa Node 22, el permiso de `.env`, la URL, la clave (sin mostrarla), que el servidor tenga el agente habilitado y el canal WhatsApp elegido, el navegador y el CLI `claude`.

El operador ve cada mensaje, redacta una respuesta de hasta 2000 caracteres y confirma exactamente **ENVIO** para responder o **EJECUTAR** para autorizar el comando de marketplace del mensaje original. El servidor vuelve a comprobar usuario, rol y argumentos. Con EJECUTAR, la salida real es el resultado redactado por el servidor y sustituye el borrador mostrado. Revise el mensaje original (IDs, precio, fecha, sector); editar el borrador no cambia esos argumentos. Cualquier otra confirmación o borrador vacío pospone 60 segundos. Cada reserva se renueva cada 30 segundos y se comprueba antes de completar. Al perder conexión o reserva se cierra la pregunta y no se envía el borrador. Ctrl+C cancela edición y pospone cuando la reserva sigue vigente; si falla la red, el servidor recupera el trabajo vencido. Revocar el equipo en el panel detiene el cliente con LOCAL_AGENT_DISABLED; rotar clave lo detiene con AUTH_REJECTED.

Mantenga el equipo despierto durante la atención. Para terminal persistente en Ubuntu puede usar `tmux new -s automantpro` y ejecutar el comando anterior. Reanude con `tmux attach -t automantpro`. No active systemd para este modo: requiere una persona en terminal y nunca aprueba automáticamente. Cerrar el proceso no cancela la solicitud del usuario; la cola del servidor permite recuperarla. No redirija la sesión a logs con datos personales. Tras un timeout de finalización consulte las salidas en plataforma antes de repetir, para evitar duplicar acciones.

## Puente WhatsApp Web (piloto)

Proceso aparte, `node src/whatsapp-bridge.mjs` (lanzador `automantpro-whatsapp`), para atender por WhatsApp antes de conectar la API oficial. Se basa en la mesa de pruebas de PYMEAgents (`src/vendor/pymeagents/`, con su commit de origen anotado).

- **Servidor:** `WHATSAPP_DELIVERY=bridge` en el hosting. Con `cloud` envía la API oficial y el puente queda rechazado; con `off` (defecto) nadie envía. Nunca entregan los dos.
- **Equipo:** Chrome o Chromium instalado (`WHATSAPP_BROWSER_PATH`) y `npm install playwright-core@1.62.1` en la carpeta del agente. No descarga navegadores.
- **Primera vez:** se abre una ventana de WhatsApp Web; escanee el QR desde *Dispositivos vinculados* del teléfono del piloto. La sesión queda en `data/whatsapp-profile` (permiso 0700, fuera de Git y del ZIP).
- **Entrada:** detecta los chats que cambiaron y pasa a la cola lo que el contacto escribió después del último mensaje nuestro. La primera vuelta solo toma la foto de la lista y no responde a nadie. Fotos y audios llegan como aviso para revisarlos en WhatsApp.
- **Identidad:** solo atiende chats cuyo título es un número. **No guarde contactos en ese teléfono**: un contacto con nombre se omite.
- **Salida:** solo lo que autoriza el servidor (respuestas aprobadas con `ENVIO`/`EJECUTAR`, avisos a usuarios vinculados y una bienvenida fija a números sin cuenta). Ritmo humano: 60 s entre envíos, 10 por hora, 30 por día, horario 8–21 (`HUMAN_ACTIVE_HOURS`). Lo que no cabe queda pendiente y se reintenta.
- Automatizar WhatsApp Web no está permitido por WhatsApp y el número puede ser bloqueado. Use un número del piloto, nunca el que se conectará a la API oficial.

## Borradores con Claude (opcional)

Con `LOCAL_AGENT_DRAFTER=claude` y el CLI `claude` instalado y con sesión iniciada, la terminal del operador muestra un borrador sugerido para cada mensaje. Enter lo usa, otro texto lo reemplaza y `-` pospone; el envío sigue exigiendo `ENVIO` o `EJECUTAR`. Claude corre sin shell, en una carpeta temporal vacía, sin herramientas que actúen sobre el equipo y sin ver la clave del agente. El mensaje del contacto se le pasa como dato, no como instrucción. Si Claude no responde, se escribe la respuesta a mano.

## Agente PYMEAgents y tipos de trabajo

`LOCAL_AGENT_DRAFTER=pymeagents` activa el clasificador local portado de PYMEAgents (`d803ca5`) para sugerir respuestas en español; la persona operadora sigue revisando y confirmando cada salida con **ENVIO**. El guard revisa los mensajes antes de generar borradores y los marcados como posibles instrucciones incrustadas se responden a mano. La lista cerrada de trabajos incluye responder y clasificar consultas, avisos por WhatsApp (que solo entrega el outbox del servidor), pruebas, capturas, revisión de diff y reporte de estado. Las tareas locales de desarrollo requieren `LOCAL_AGENT_DEV_JOBS=true` y una ruta existente en `LOCAL_AGENT_REPO_DIR`; por defecto están apagadas. El operador puede ejecutar los trabajos de desarrollo permitidos con `node src/run-job.mjs <tipo>`.

## Windows y macOS

Instale Node22, descomprima ZIP y abra terminal en la carpeta. Copie `.env.example` a `.env` y edite URL/token. macOS: `chmod 600 .env`, luego `node src/main.mjs`. Windows PowerShell: `Copy-Item .env.example .env`; restrinja ACL del archivo al operador mediante Propiedades > Seguridad antes de iniciarlo. Ejecute `node src/main.mjs`. No necesita Bash ni compilador.

## Crear candidato portable

Desde esta carpeta: `npm test` y `npm run bundle`. `dist/automantpro-local-agent.zip` incluye solo la lista explícita de código/documentación; `.env`, logs y secretos quedan fuera. Incluye checksum SHA256 para validar integridad. No distribuya la carpeta completa del equipo configurado.

## Prueba mínima

1. Crear un mensaje piloto desde un usuario autorizado; confirmar que aparece con canal `pilot`.
2. Escribir un borrador y confirmar `ENVIO`; comprobar salida persistida sin acción de marketplace.
3. Enviar comando válido de marketplace y confirmar `EJECUTAR`; comprobar autorización, acción y salida desde plataforma.
4. Intentar una acción con rol incorrecto; el servidor debe rechazarla sin mutación.
5. Posponer, cortar Internet y reiniciar; comprobar recuperación sin duplicar salida/acción.
6. Rotar token; el agente debe detenerse con `AUTH_REJECTED`.

Los tests incluidos verifican el contrato del cliente con fetch simulado. Estas pruebas no acreditan todavía conectividad de GoDaddy ni entrega WhatsApp; la prueba anterior sí requiere servidor desplegado.
