import { createHmac, createHash, randomBytes } from 'node:crypto';
import { chmod, mkdir, readFile, readdir, writeFile, stat } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { anonymize, neutralize } from './drafter.mjs';

// node:sqlite is experimental in Node 22. Filter only its startup warning while loading this module.
const priorWarning = process.emitWarning;
process.emitWarning = function (warning, ...args) {
  if (String(warning?.message ?? warning).includes('node:sqlite') || String(args[0] ?? '').includes('ExperimentalWarning')) return;
  return priorWarning.call(this, warning, ...args);
};
let DatabaseSync;
try { ({ DatabaseSync } = await import('node:sqlite')); }
finally { process.emitWarning = priorWarning; }

const base = dirname(fileURLToPath(import.meta.url));
const defaultData = join(base, '..', 'data');
const memoryDir = join(base, '..', 'memoria');
async function writeCorrectedCase(item) {
  const directory = join(defaultData, 'eval'); await mkdir(directory, { recursive: true, mode: 0o700 }); await chmod(directory, 0o700);
  const filename = join(directory, 'casos-reales.json'); let cases = [];
  try { cases = JSON.parse(await readFile(filename, 'utf8')); if (!Array.isArray(cases)) return; } catch (error) { if (error.code !== 'ENOENT') return; }
  if (cases.some(row => row.id === item.id)) return;
  cases.push(item); await writeFile(filename, `${JSON.stringify(cases, null, 2)}\n`, { mode: 0o600 }); await chmod(filename, 0o600);
}
const normalizePhone = value => String(value ?? '').replace(/\D/g, '');
const wordQuery = value => (String(value ?? '').normalize('NFKC').match(/[\p{L}\p{N}]+/gu) ?? [])
  .filter(word => word.length <= 64).map(word => `"${word.replaceAll('"', '""')}"`).join(' OR ');

export function classifySkill(text) {
  const value = String(text ?? '').toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (/\b(registr\w*|registro|acepto|ruc)\b/.test(value)) return 'registro';
  if (/\b(plan|suscrip|membresia)\b/.test(value)) return 'plan';
  if (/\b(buscar|busqueda|repuesto|cotizacion|ofertar|invitaciones)\b/.test(value)) return 'busqueda';
  if (/\b(historial|resumen|conversacion|conversación)\b/.test(value)) return 'historial';
  if (/\b(servicio|vehiculo|vehículo|frenos|aceite|mecanico|mecánico|cita)\b/.test(value)) return 'servicio';
  if (/\b(factura|pago|precio|negocio|proveedor|pedido|entrega)\b/.test(value)) return 'negocio';
  return 'otro';
}

async function localKey(dataDir) {
  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  await chmod(dataDir, 0o700);
  const file = join(dataDir, '.clave-contactos');
  try { const key = await readFile(file); await chmod(file, 0o600); return key; }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const key = randomBytes(32);
    try { await writeFile(file, key, { flag: 'wx', mode: 0o600 }); }
    catch (race) { if (race.code !== 'EEXIST') throw race; return localKey(dataDir); }
    return key;
  }
}

function sectionRows(filename, content) {
  const chunks = content.split(/(?=^#{1,2}\s+)/m).map(x => x.trim()).filter(Boolean);
  return (chunks.length ? chunks : [content.trim()]).map((texto, i) => {
    const titulo = texto.match(/^#{1,2}\s+(.+)$/m)?.[1]?.trim() ?? filename;
    const id = createHash('sha256').update(`${filename}\0${i}\0${titulo}`).digest('hex');
    return { id, fuente: filename, titulo, texto: neutralize(texto, 12000), actualizado: new Date().toISOString() };
  });
}

export async function createMemoryDb({ dataDir = defaultData, docsDir = memoryDir, aprendizajePath = join(dataDir, 'memoria', 'aprendizaje.jsonl'), dbPath = join(dataDir, 'memoria.db'), now = () => Date.now() } = {}) {
  await mkdir(dataDir, { recursive: true, mode: 0o700 }); await chmod(dataDir, 0o700);
  const key = await localKey(dataDir);
  const db = new DatabaseSync(dbPath);
  await chmod(dbPath, 0o600);
  const dbStat = await stat(dbPath);
  if ((dbStat.mode & 0o777) !== 0o600) throw new Error('MEMORY_DB_PERMISSIONS');
  db.exec('PRAGMA journal_mode=WAL');
  for (const suffix of ['-wal', '-shm']) { try { await chmod(`${dbPath}${suffix}`, 0o600); } catch { /* SQLite may not have created both files yet. */ } }
  db.exec('PRAGMA foreign_keys=ON');
  db.exec('PRAGMA secure_delete=ON');
  const version = db.prepare('PRAGMA user_version').get().user_version;
  if (version < 1) {
    db.exec(`CREATE TABLE conocimiento(id TEXT PRIMARY KEY, fuente TEXT NOT NULL, titulo TEXT NOT NULL, texto TEXT NOT NULL, actualizado TEXT NOT NULL);
      CREATE VIRTUAL TABLE conocimiento_fts USING fts5(id UNINDEXED, titulo, texto, tokenize='unicode61 remove_diacritics 2');
      CREATE TABLE aprendizaje(id INTEGER PRIMARY KEY, creado TEXT NOT NULL, rol TEXT NOT NULL, mensaje TEXT NOT NULL, sugerido TEXT NOT NULL, final TEXT NOT NULL, accion TEXT NOT NULL);
      CREATE VIRTUAL TABLE aprendizaje_fts USING fts5(mensaje, sugerido, final, tokenize='unicode61 remove_diacritics 2');
      CREATE TABLE cuenta(clave TEXT PRIMARY KEY, contexto_json TEXT NOT NULL, actualizado INTEGER NOT NULL);
      CREATE TABLE conversacion(clave TEXT PRIMARY KEY, resumen TEXT NOT NULL, actualizado INTEGER NOT NULL);
      CREATE TABLE fuentes(fuente TEXT PRIMARY KEY, hash TEXT NOT NULL, indexado TEXT NOT NULL);
      PRAGMA user_version=1;`);
  }
  if (!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='eventos'").get()) {
    db.exec(`CREATE TABLE eventos(
      id INTEGER PRIMARY KEY, creado TEXT NOT NULL, canal TEXT NOT NULL, habilidad TEXT NOT NULL,
      accion_propuesta TEXT NOT NULL, decision TEXT NOT NULL, texto_final_anon TEXT NOT NULL,
      resultado TEXT, clave_contacto_hmac TEXT NOT NULL
    ); PRAGMA user_version=2;`);
  }
  db.exec('CREATE TABLE IF NOT EXISTS eventos_eval_exportados(evento_id INTEGER PRIMARY KEY)');
  if (!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='reglas'").get()) {
    db.exec(`CREATE TABLE reglas(id INTEGER PRIMARY KEY, creado TEXT NOT NULL, habilidad TEXT NOT NULL, texto TEXT NOT NULL, origen_evento INTEGER, estado TEXT NOT NULL, decidido TEXT);
      CREATE INDEX reglas_estado_habilidad ON reglas(estado, habilidad); PRAGMA user_version=3;`);
  }
  if (!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='notas'").get()) {
    db.exec(`CREATE TABLE notas(fecha TEXT NOT NULL, habilidad TEXT NOT NULL, puntos INTEGER NOT NULL, total INTEGER NOT NULL, validos INTEGER NOT NULL, falsos_abiertos INTEGER NOT NULL, PRIMARY KEY(fecha, habilidad)); PRAGMA user_version=4;`);
  }
  const insertKnowledge = db.prepare('INSERT OR REPLACE INTO conocimiento(id,fuente,titulo,texto,actualizado) VALUES(?,?,?,?,?)');
  const insertKnowledgeFts = db.prepare('INSERT INTO conocimiento_fts(id,titulo,texto) VALUES(?,?,?)');
  const delKnowledgeFts = db.prepare('DELETE FROM conocimiento_fts WHERE id=?');
  const delKnowledge = db.prepare('DELETE FROM conocimiento WHERE id=?');
  const setSource = db.prepare('INSERT OR REPLACE INTO fuentes(fuente,hash,indexado) VALUES(?,?,?)');
  const getSource = db.prepare('SELECT hash FROM fuentes WHERE fuente=?');
  const filenames = (await readdir(docsDir).catch(() => [])).filter(f => f.endsWith('.md')).sort();
  for (const filename of filenames) {
    const content = await readFile(join(docsDir, filename), 'utf8');
    const hash = createHash('sha256').update(content).digest('hex');
    if (getSource.get(filename)?.hash === hash) continue;
    const old = db.prepare('SELECT id FROM conocimiento WHERE fuente=?').all(filename);
    for (const row of old) { delKnowledgeFts.run(row.id); delKnowledge.run(row.id); }
    for (const row of sectionRows(filename, content)) { insertKnowledge.run(row.id,row.fuente,row.titulo,row.texto,row.actualizado); insertKnowledgeFts.run(row.id,row.titulo,row.texto); }
    setSource.run(filename, hash, new Date(now()).toISOString());
  }
  db.exec('CREATE TABLE IF NOT EXISTS __memory_metadata(clave TEXT PRIMARY KEY, valor TEXT NOT NULL)');
  if (!db.prepare("SELECT valor FROM __memory_metadata WHERE clave='aprendizaje_importado'").get()) {
    let lines = [];
    try { lines = (await readFile(aprendizajePath, 'utf8')).split('\n').filter(Boolean); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const add = db.prepare('INSERT INTO aprendizaje(creado,rol,mensaje,sugerido,final,accion) VALUES(?,?,?,?,?,?)');
    const addFts = db.prepare('INSERT INTO aprendizaje_fts(mensaje,sugerido,final) VALUES(?,?,?)');
    for (const line of lines) {
      try {
        const row = JSON.parse(line); if (typeof row.mensaje !== 'string' || typeof (row.respuesta ?? row.final) !== 'string') continue;
        const msg = anonymize(row.mensaje), suggested = anonymize(row.sugerida ?? row.sugerido ?? ''), final = anonymize(row.respuesta ?? row.final);
        add.run(String(row.creado ?? new Date(now()).toISOString()), String(row.rol ?? ''), msg, suggested, final, String(row.accion ?? 'ENVIO')); addFts.run(msg,suggested,final);
      } catch { /* Ignore malformed historic rows. */ }
    }
    db.prepare("INSERT INTO __memory_metadata(clave,valor) VALUES('aprendizaje_importado','1')").run();
  }
  const accountKey = numero => createHmac('sha256', key).update(normalizePhone(numero)).digest('hex');
  const selectKnowledge = db.prepare('SELECT k.titulo,k.texto,bm25(conocimiento_fts) AS rank FROM conocimiento_fts JOIN conocimiento k ON k.id=conocimiento_fts.id WHERE conocimiento_fts MATCH ? ORDER BY rank LIMIT ?');
  const selectExamples = db.prepare('SELECT a.rol,a.mensaje,a.sugerido,a.final,a.accion,a.creado,bm25(aprendizaje_fts) AS rank FROM aprendizaje_fts JOIN aprendizaje a ON a.id=aprendizaje_fts.rowid WHERE aprendizaje_fts MATCH ? ORDER BY rank LIMIT ?');
  const addLearning = db.prepare('INSERT INTO aprendizaje(creado,rol,mensaje,sugerido,final,accion) VALUES(?,?,?,?,?,?)');
  const addLearningFts = db.prepare('INSERT INTO aprendizaje_fts(mensaje,sugerido,final) VALUES(?,?,?)');
  const getContext = db.prepare('SELECT contexto_json,actualizado FROM cuenta WHERE clave=?');
  const putContext = db.prepare('INSERT OR REPLACE INTO cuenta(clave,contexto_json,actualizado) VALUES(?,?,?)');
  const getSummary = db.prepare('SELECT resumen,actualizado FROM conversacion WHERE clave=?');
  const putSummary = db.prepare('INSERT OR REPLACE INTO conversacion(clave,resumen,actualizado) VALUES(?,?,?)');
  const insertEvent = db.prepare('INSERT INTO eventos(creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado,clave_contacto_hmac) VALUES(?,?,?,?,?,?,?,?)');
  const updateEventResult = db.prepare('UPDATE eventos SET resultado=? WHERE id=?');
  const eventById = db.prepare('SELECT id,creado,canal,habilidad,accion_propuesta,decision,texto_final_anon,resultado,clave_contacto_hmac FROM eventos WHERE id=?');
  const insertRule = db.prepare('INSERT INTO reglas(creado,habilidad,texto,origen_evento,estado,decidido) VALUES(?,?,?,?,?,NULL)');
  const selectRules = db.prepare('SELECT id,creado,habilidad,texto,origen_evento,estado,decidido FROM reglas');
  const getRule = db.prepare('SELECT id,creado,habilidad,texto,origen_evento,estado,decidido FROM reglas WHERE id=?');
  const decideRule = db.prepare('UPDATE reglas SET estado=?, decidido=? WHERE id=? AND estado=?');
  const insertNote = db.prepare('INSERT OR REPLACE INTO notas(fecha,habilidad,puntos,total,validos,falsos_abiertos) VALUES(?,?,?,?,?,?)');
  const selectNotes = db.prepare('SELECT fecha,habilidad,puntos,total,validos,falsos_abiertos FROM notas ORDER BY fecha,habilidad');
  const correctedEvents = db.prepare("SELECT id,creado,habilidad,accion_propuesta,texto_final_anon FROM eventos WHERE decision='CORREGIDO' ORDER BY id");
  const exportedEvent = db.prepare('SELECT evento_id FROM eventos_eval_exportados WHERE evento_id=?');
  const markExportedEvent = db.prepare('INSERT OR IGNORE INTO eventos_eval_exportados(evento_id) VALUES(?)');
  return {
    buscarConocimiento(texto, n=5) { const q=wordQuery(texto); return q ? selectKnowledge.all(q,Math.max(1,Math.min(20,Number(n)||5))).map(({titulo,texto})=>`## ${titulo}\n${texto}`).join('\n').slice(0,3000) : ''; },
    ejemplosSimilares(texto,n=5) { const q=wordQuery(texto); return q ? selectExamples.all(q,Math.max(1,Math.min(20,Number(n)||5))).map(({rank,...row})=>({mensaje:row.mensaje,sugerido:row.sugerido,respuesta:row.final,rol:row.rol,accion:row.accion,creado:row.creado})) : []; },
    guardarAprendizaje({ message, suggested='', final, reply, rol='', accion='ENVIO' }) { const msg=anonymize(message), sug=anonymize(suggested), output=anonymize(final ?? reply); if (!msg || !output) return false; const creado=new Date(now()).toISOString(); addLearning.run(creado,String(rol),msg,sug,output,String(accion)); addLearningFts.run(msg,sug,output); return true; },
    registrarEvento({ canal='', habilidad, accionPropuesta='', decision, textoFinal='', casoEval=null, resultado=null, contacto='' }) {
      const skills = ['registro','plan','busqueda','historial','servicio','negocio','otro'];
      const decisions = ['ENVIO','CORREGIDO','IGNORAR','EJECUTAR','VENCIDO'];
      if (!decisions.includes(decision) || !skills.includes(habilidad)) throw new Error('INVALID_EVENT');
      const contactHash = accountKey(contacto);
      const result = resultado == null ? null : String(resultado).slice(0, 100);
      const info = insertEvent.run(new Date(now()).toISOString(), String(canal).slice(0, 40), habilidad, String(accionPropuesta).slice(0, 40), decision, anonymize(textoFinal), result, contactHash);
      const id = Number(info.lastInsertRowid);
      if (decision === 'CORREGIDO') {
        const payload = casoEval || { mensaje: accionPropuesta, sugerido: '', final: textoFinal };
        const evalCase = this.guardarCasoCorregido({ eventoId: id, habilidad, ...payload });
        writeCorrectedCase(evalCase).catch(() => {});
      }
      return id;
    },
    actualizarResultadoEvento(id, resultado) { if (!['entregado','ejecutado','fallo'].includes(resultado)) throw new Error('INVALID_EVENT_RESULT'); const changed = updateEventResult.run(resultado, Number(id)).changes === 1; if (changed) { const row = eventById.get(Number(id)); if (row) row.resultado = resultado; } return changed; },
    evento(id) { return eventById.get(Number(id)) ?? null; },
    proponerRegla({ habilidad, texto, origenEvento = null }) {
      const skills = ['registro','plan','busqueda','historial','servicio','negocio','otro'];
      const clean = neutralize(texto, 201).trim();
      if (!skills.includes(habilidad) || !clean || clean.length > 200) throw new Error('INVALID_RULE');
      const id = insertRule.run(new Date(now()).toISOString(), habilidad, clean, origenEvento == null ? null : Number(origenEvento), 'propuesta').lastInsertRowid;
      return Number(id);
    },
    listarReglas(estado) { return selectRules.all().filter(row => !estado || row.estado === estado); },
    regla(id) { return getRule.get(Number(id)) ?? null; },
    decidirRegla(id, estado) {
      if (!['aprobada','rechazada'].includes(estado)) throw new Error('INVALID_RULE_STATE');
      return decideRule.run(estado, new Date(now()).toISOString(), Number(id), 'propuesta').changes === 1;
    },
    reglasAprobadas(habilidad) { return selectRules.all().filter(row => row.estado === 'aprobada' && row.habilidad === habilidad); },
    registrarNota({ fecha, habilidad, puntos, total, validos, falsosAbiertos }) {
      const skills = ['registro','plan','busqueda','historial','servicio','negocio','otro'];
      if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha) || !skills.includes(habilidad) || ![puntos,total,validos,falsosAbiertos].every(Number.isSafeInteger) || puntos < 0 || total < 0 || validos < 0 || falsosAbiertos < 0) throw new Error('INVALID_NOTE');
      insertNote.run(fecha, habilidad, puntos, total, validos, falsosAbiertos); return true;
    },
    listarNotas() { return selectNotes.all(); },
    eventosCorregidos() { return correctedEvents.all(); },
    eventosCorregidosNoExportados() { return correctedEvents.all().filter(row => !exportedEvent.get(row.id)); },
    marcarEventoEvalExportado(id) { return markExportedEvent.run(Number(id)).changes === 1; },
    guardarCasoCorregido({ eventoId, habilidad, mensaje, sugerido, final }) {
      const skills = ['registro','plan','busqueda','historial','servicio','negocio','otro'];
      if (!skills.includes(habilidad)) throw new Error('INVALID_EVAL_CASE');
      const cleanMessage = anonymize(mensaje), cleanSuggested = anonymize(sugerido), cleanFinal = anonymize(final);
      if (!cleanMessage || !cleanFinal || /(?:\+?593|0)\s*(?:\d[\s().-]*){8,12}\b|\b\d{10,15}\b/.test(`${cleanMessage}${cleanSuggested}${cleanFinal}`.replaceAll('+593 99 000 0000', ''))) throw new Error('INVALID_EVAL_CASE');
      return { id: `real-${Number(eventoId)}`, title: '+593 99 000 0000', preview: cleanMessage.slice(0, 250), categoria: habilidad, debeAbrir: true, grupo: false, servicio: habilidad, mensajes: [{ text: cleanMessage }, { text: `Respuesta sugerida: ${cleanSuggested}` }, { text: `Respuesta corregida: ${cleanFinal}` }], respuestaEsperada: [] };
    },
    contextoCuenta(numero) { const row=getContext.get(accountKey(numero)); if (!row || now()-row.actualizado>86400000) { if(row) db.prepare('DELETE FROM cuenta WHERE clave=?').run(accountKey(numero)); return null; } try{return JSON.parse(row.contexto_json);}catch{return null;} },
    guardarContexto(numero,ctx) { const clean=JSON.parse(neutralize(JSON.stringify(ctx ?? null),10000)); putContext.run(accountKey(numero),JSON.stringify(clean),now()); return true; },
    resumen(numero) { const row=getSummary.get(accountKey(numero)); return row && now()-row.actualizado<=86400000 ? row.resumen : null; },
    guardarResumen(numero,texto) { putSummary.run(accountKey(numero),anonymize(String(texto ?? '').slice(0,500),2000).slice(0,500),now()); return true; },
    olvidar(numero) { const k=accountKey(numero); db.prepare('DELETE FROM cuenta WHERE clave=?').run(k); db.prepare('DELETE FROM conversacion WHERE clave=?').run(k); return true; },
    extensionVectores: Object.freeze({ enabled: process.env.MEMORY_VECTORS === '1', initialize() { if (process.env.MEMORY_VECTORS !== '1') return false; return 'sqlite-vec extension point'; } }),
    cerrar() { db.close(); },
  };
}
