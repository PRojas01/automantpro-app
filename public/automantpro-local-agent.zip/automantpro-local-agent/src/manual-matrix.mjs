// Tablas de mantenimiento en matriz leídas por código (sin modelo, sin costo y sin inventar): la cabecera lista
// los kilometrajes en miles y cada operación trae exactamente una marca por columna (R, I, A, T, L o -).

/** Kilometrajes de la cabecera «x 1,000 km 5 10 15 …»; null si la página no trae una cabecera así. */
export function matrixColumns(text) {
  const lines = String(text ?? '').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const header = /[x×]\s?1[.,  ]?000\s?km\b(.*)$/i.exec(lines[i]);
    if (!header) continue;
    const km = (header[1].match(/\d{1,3}/g) || []).map(Number);
    if (km.length < 4 || !km.every((v, k) => k === 0 || v > km[k - 1])) continue;
    // Meses: la primera línea siguiente con tantos números crecientes como columnas (las millas no cuentan).
    let months = null;
    for (const line of lines.slice(i + 1, i + 5)) {
      const found = (line.match(/\d{1,3}/g) || []).map(Number).slice(-km.length);
      if (/month|mes/i.test(line) && found.length === km.length && found.every((v, k) => k === 0 || v > found[k - 1])) { months = found; break; }
    }
    // Cabecera partida («or months … 6» aparte): con columnas uniformes, los meses son múltiplos del primero.
    const uniform = km.every((v, k) => v === km[0] * (k + 1));
    const first = /months?\b\D{0,40}?\b(\d{1,2})\b/i.exec(lines.slice(i, i + 6).filter(l => /or months|o meses/i.test(l)).join(' '));
    if (!months && uniform && first) months = km.map((_, k) => Number(first[1]) * (k + 1));
    return { km: km.map(v => v * 1000), months };
  }
  return null;
}

const ACTIONS = [['R', 'reemplazar'], ['I', 'inspeccionar'], ['A', 'ajustar'], ['L', 'lubricar'], ['T', 'ajustar']];
const SKIP = /service interval|interval[oa] de|miles|months|\bmeses\b|^[IRATL] ?:|maintenance|mantenimiento|^\d|replace (every|the)/i;
const clean = s => s.replace(/\([^)]*\)?/g, ' ').replace(/^\*+\s*/, '').replace(/\s+/g, ' ').trim();

/** Paso de una letra: el intervalo más repetido entre columnas marcadas (o la primera marca si es única). */
function step(marks, letter, columns) {
  const at = marks.map((m, i) => (m === letter ? i : -1)).filter(i => i >= 0);
  if (!at.length) return null;
  const gaps = at.slice(1).map((v, k) => v - at[k]);
  const common = gaps.length ? [...gaps].sort((a, b) => gaps.filter(g => g === b).length - gaps.filter(g => g === a).length)[0] : at[0] + 1;
  const km = columns.km[Math.min(common, columns.km.length) - 1];
  const months = columns.months ? columns.months[Math.min(common, columns.months.length) - 1] : null;
  return { km, months, regular: gaps.every(g => g === common) };
}

/**
 * Filas de una página en matriz, con la forma que espera el digestor. «motor» (p. ej. «4JA1») descarta las
 * variantes escritas para otros motores. Devuelve null si la página no se puede leer así.
 */
export function matrixRows(page, { motor = null } = {}) {
  const columns = matrixColumns(page.text);
  if (!columns) return null;
  const n = columns.km.length;
  const tailRe = new RegExp('((?:(?<![A-Za-z0-9])[RIATL-]|(?<=[RIATL-])[RIATL-])\\s*){' + n + '}\\s*$');
  const wanted = motor ? new RegExp(motor, 'i') : null;
  const rows = [];
  let label = '';
  for (const line of page.text.split(/\r?\n/)) {
    const tail = tailRe.exec(line);
    const head = (tail ? line.slice(0, tail.index) : line).trim();
    // El nombre va en la línea que no empieza por «(»; las variantes de motor van debajo.
    if (head && !SKIP.test(head) && !/^(\*\*\s*)?\(|^\*\*$|Output\)/.test(head)) label = clean(head) || label;
    if (!tail || !label) continue;
    const marks = tail[0].replace(/\s+/g, '').split('');
    const variants = (head.match(/\((?:[0-9][A-Z0-9]{2,}|[A-Z]{2,}[0-9]|GASOLINE|DIESEL|GASOLINA|DI[EÉ]SEL)[^()]*(?:\([^()]*\))?[^()]*\)?/gi) || []).join(' ');
    if (wanted && variants && !wanted.test(variants) && !/DIESEL|DI[EÉ]SEL/i.test(variants)) continue;
    for (const [letter, accion] of ACTIONS) {
      const found = step(marks, letter, columns);
      if (!found) continue;
      rows.push({ componente: label + (variants ? ' ' + variants : ''), accion, km: found.km, meses: found.months, cita: line.trim().slice(0, 160), irregular: !found.regular });
      // Un cambio y su revisión son dos datos; las demás letras no repiten.
      if (letter !== 'R') break;
    }
  }
  return rows.length ? rows : null;
}

/** ¿La página dice algún intervalo? Sin kilómetros, meses ni marcas no vale la pena preguntarle al modelo. */
export const hasIntervals = text => /\d[\d.,  ]{2,}\s?(km|kil[oó]metros|millas)\b|\b\d{1,3}\s?(meses|months|años|years)\b|[x×]\s?1[.,  ]?000|([RI] ){4,}|[RI]{6,}/i.test(String(text ?? ''));
