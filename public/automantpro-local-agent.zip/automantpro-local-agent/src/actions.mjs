const words = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const first = (...values) => values.find(value => typeof value === 'string' && value.trim())?.trim();

/** Construye una propuesta ejecutable solo cuando hay datos suficientes del contexto. */
export function buildAction(message, context = null, chatSummary = '') {
  const text = words(`${message ?? ''} ${chatSummary ?? ''}`);
  const account = context && typeof context === 'object' ? context : {};
  const role = words(account.role ?? account.perfil ?? '');
  const vehicleId = first(account.vehicleId, account.vehicle?.id, account.vehiculoId);
  let habilidad = 'otro', comando = null, faltan = [], riesgo = 'bajo';

  // El servidor reconoció el mensaje como un comando exacto de la plataforma: se propone tal cual, para que el operador
  // lo ejecute con un toque. El servidor lo vuelve a validar (debe ser idéntico al texto del contacto).
  const exact = typeof account.exactCommand === 'string' ? account.exactCommand.trim() : '';
  if (exact && exact === String(message ?? '').trim()) {
    const delicate = /\b(aprobar|rechazar|pago|cobro|reembolso|cancelar|anular|aceptar|confirm|eliminar|entrega|garantia|reclamo|ofertar|foto)/.test(words(exact));
    return { habilidad: 'comando_plataforma', comando: exact, faltan: [], riesgo: delicate ? 'alto' : 'bajo', ...(account.hasPhoto ? { conFoto: true } : {}) };
  }
  const profile = inferProfile(message);
  if (/\bregistr(arme|ate|arse|o)\b|\bregistrar (mi |un |una )?(taller|almacen|negocio|cuenta|vehiculo|carro)\b/.test(text) || (profile && words(message).trim().length <= 30 && !/\b(aceptar|confirmar|confirmo|cita|oferta|ofertar|s-[0-9a-f]{6}|c-[0-9a-f]{6})\b/.test(words(message)))) {
    // Registro: el perfil se deduce del texto libre ("tengo un taller", "vendo repuestos", "mi carro") o de 1/2/3.
    habilidad = 'registro';
    // Los datos no se piden por chat: la persona llena el formulario web de su perfil y entra con el código que le llega por WhatsApp.
    if (!profile) faltan = ['perfil (dueño de vehículo, taller o almacén)'];
    return { habilidad, perfil: profile, comando: null, faltan, riesgo, enlace: signupLink(profile) };
  }
  if (/\b(plan|mantenimiento preventivo)\b/.test(text)) {
    habilidad = 'plan_mantenimiento';
    const vehicle = account.vehicle ?? {};
    const plate = first(vehicle.plate, vehicle.placa, account.plate, account.placa);
    const planVehicleId = first(vehicle.id, account.vehicleId, account.vehiculoId);
    if (planVehicleId || account.accountId || account.userId) comando = `Plan${plate ? ` ${plate}` : ''}`;
    else faltan = ['vehículo registrado'];
  } else if (/\b(historial|ultimo servicio|último servicio|registrar servicio|anotar servicio)\b/.test(text)) {
    if (/\b(ultimo servicio|último servicio|registrar servicio|anotar servicio)\b/.test(text)) {
      habilidad = 'registrar_historial';
      const service = first(account.service, account.servicio);
      const km = first(account.km, account.kilometraje);
      const month = first(account.month, account.mes);
      faltan = [!service && 'servicio', !km && 'kilometraje', month === undefined && 'mes AAAA-MM o indicar que se desconoce'].filter(Boolean);
      if (!faltan.length) comando = `Último servicio | ${service} | ${km} | ${month || ''}`;
    } else {
      habilidad = 'consultar_historial';
      comando = /\b(plan completo|historial completo)\b/.test(text) ? 'Plan completo' : 'Plan';
      if (!account.vehicleId && !account.vehicle?.id && !account.accountId && !account.userId) { comando = null; faltan = ['cuenta de dueño con vehículo registrado']; }
    }
  } else if (/\b(aceptar|acepto)\b/.test(text)) {
    habilidad = 'aceptar_oferta'; riesgo = 'alto';
    const position = text.match(/\b([1-5])\b/)?.[1];
    const request = text.match(/\bs-[0-9a-f]{6}\b/i)?.[0];
    const requestId = first(account.requestId, account.solicitudId, text.match(/\bs-[0-9a-f]{6}\b/i)?.[0]);
    const offerId = first(account.offerId, account.ofertaId);
    if (requestId && offerId) comando = `Aceptar | ${requestId} | ${offerId}`;
    else if (position && (request || account.hasPendingOffer === true)) comando = `Aceptar${request ? ` ${request.toUpperCase()}` : ''} ${position}`;
    else {
      if (!position) faltan.push('número de oferta');
      if (!request && !account.hasPendingOffer) faltan.push('código S- de solicitud con oferta propia');
    }
  } else if (/\b(confirmar|confirmo)\b/.test(text) && /\b(cita|turno)\b/.test(text)) {
    habilidad = 'confirmar_cita'; riesgo = 'alto';
    const ref = text.match(/\bc-[0-9a-f]{6}\b/i)?.[0];
    const requestId = first(account.requestId, account.solicitudId);
    const appointmentId = first(account.appointmentId, account.citaId);
    if (requestId && appointmentId) comando = `Confirmar cita | ${requestId} | ${appointmentId}`;
    else if (ref) comando = `Confirmar ${ref.toUpperCase()}`;
    else faltan = ['código C- de la cita'];
  } else if (/\b(buscar|busco|necesito|cotizar)\b/.test(text) && /\b(taller|servicio|repuesto|pieza)\b/.test(text)) {
    const part = /\b(repuesto|pieza)\b/.test(text);
    habilidad = part ? 'buscar_repuesto' : 'buscar_servicio';
    const fields = { categoria: first(account.category, account.categoria), ciudad: first(account.city, account.ciudad), sector: first(account.zone, account.sector), descripcion: first(account.description, account.descripcion) };
    faltan = Object.keys(fields).filter(key => !fields[key]);
    if (!vehicleId && !role.includes('taller') && !role.includes('almacen')) faltan.push('vehículo registrado');
    if (!faltan.length) comando = `Buscar ${part ? 'repuesto' : 'servicio'} | ${fields.categoria} | ${fields.ciudad} | ${fields.sector} | ${fields.descripcion}`;
  }
  return { habilidad, comando: faltan.length ? null : comando, faltan, riesgo };
}

/** Deduce el perfil de registro del texto libre; null si no se puede. */
export function inferProfile(message) {
  const t = words(message).trim();
  // Respuesta corta con la opción ("Acepto, 1", "la 2", "opción 3").
  const option = t.length <= 30 ? t.match(/(?:^|\W)(1|2|3|uno|dos|tres)(?:\W|$)/)?.[1] : null;
  if (option) return ({ 1: 'dueno', uno: 'dueno', 2: 'taller', dos: 'taller', 3: 'almacen', tres: 'almacen' })[option];
  if (/^(1|uno|opcion 1)\b/.test(t)) return 'dueno';
  if (/^(2|dos|opcion 2)\b/.test(t)) return 'taller';
  if (/^(3|tres|opcion 3)\b/.test(t)) return 'almacen';
  if (/\b(almacen|repuestos|autopartes|vendo (repuestos|piezas)|distribuidora)\b/.test(t)) return 'almacen';
  if (/\b(taller|mecanica|lubricadora|lavadora|vulcanizadora|electromecanica|enderezada|tengo un negocio de autos)\b/.test(t)) return 'taller';
  if (/\b(mi (carro|auto|vehiculo|moto|camioneta)|dueno|propietario|tengo un (carro|auto|vehiculo))\b/.test(t)) return 'dueno';
  return null;
}

const PROFILE_LABELS = { dueno: '🚗 Dueño de vehículo', taller: '🔧 Taller', almacen: '📦 Almacén de repuestos' };
/** Enlace de alta del perfil (o los tres si aún no se sabe). La web verifica el número con un código por WhatsApp. */
export function signupLink(profile, site = process.env.LOCAL_AGENT_URL || 'https://automantpro.app') {
  const base = String(site).replace(/\/+$/, '');
  const one = key => `${PROFILE_LABELS[key]}: ${base}/cuenta?perfil=${key}#crear`;
  return profile && PROFILE_LABELS[profile] ? one(profile) : Object.keys(PROFILE_LABELS).map(one).join('\n');
}
