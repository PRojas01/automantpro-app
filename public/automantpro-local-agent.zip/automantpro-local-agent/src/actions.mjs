const words = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const first = (...values) => values.find(value => typeof value === 'string' && value.trim())?.trim();

/** Construye una propuesta ejecutable solo cuando hay datos suficientes del contexto. */
export function buildAction(message, context = null, chatSummary = '') {
  const text = words(`${message ?? ''} ${chatSummary ?? ''}`);
  const account = context && typeof context === 'object' ? context : {};
  const role = words(account.role ?? account.perfil ?? '');
  const vehicleId = first(account.vehicleId, account.vehicle?.id, account.vehiculoId);
  let habilidad = 'otro', comando = null, faltan = [], riesgo = 'bajo';

  // El servidor reconoció el mensaje como un comando exacto de la plataforma: se propone tal cual, para que el operador
  // lo ejecute con un toque. El servidor lo vuelve a validar (debe ser idéntico al texto del contacto).
  const exact = typeof account.exactCommand === 'string' ? account.exactCommand.trim() : '';
  if (exact && exact === String(message ?? '').trim()) {
    const delicate = /\b(aprobar|rechazar|pago|cobro|reembolso|cancelar|anular|aceptar|confirm|eliminar|entrega|garantia|reclamo|ofertar|foto)/.test(words(exact));
    return { habilidad: 'comando_plataforma', comando: exact, faltan: [], riesgo: delicate ? 'alto' : 'bajo', ...(account.hasPhoto ? { conFoto: true } : {}) };
  }
  const profile = inferProfile(message);
  // Enlaces del inicio (23/11/2026): «Hola AutoMantPro, tengo un taller. Código: AMP-XXXX» o «quiero empezar» es un registro nuevo.
  const fromHome = /\bamp-[a-z0-9]{4,6}\b/.test(text) && (profile || /quiero empezar/.test(text)) && !/\b(aceptar|confirmar|confirmo|cita|oferta|ofertar|plan|s-[0-9a-f]{6}|c-[0-9a-f]{6})\b/.test(text);
  if (fromHome || /\bregistr(arme|ate|arse|o)\b|\bregistrar (mi |un |una )?(taller|almacen|negocio|cuenta|vehiculo|carro)\b/.test(text) || (profile && words(message).trim().length <= 30 && !/\b(aceptar|confirmar|confirmo|cita|oferta|ofertar|s-[0-9a-f]{6}|c-[0-9a-f]{6})\b/.test(words(message)))) {
    // Registro: el perfil se deduce del texto libre ("tengo un taller", "vendo repuestos", "mi carro") o de 1/2/3.
    habilidad = 'registro';
    // Los datos no se piden por chat: la persona llena el formulario web de su perfil y entra con el código que le llega por WhatsApp.
    if (!profile) faltan = ['perfil (dueño de vehículo, taller o almacén)'];
    return { habilidad, perfil: profile, comando: null, faltan, riesgo, enlace: signupLink(profile) };
  }
  // «plan premium», «cuánto cuesta el plan»: es la suscripción (página de planes), no el plan de mantenimiento del vehículo.
  const subscription = /\bplan (premium|pro|gratis|gratuito|basico|avanzado|flota|taller pro)\b|\b(precios?|costos?|cuesta|cuestan|vale|valen|pagar|contratar|suscripcion)\b/.test(text);
  if (/\b(plan|mantenimiento preventivo)\b/.test(text) && !subscription) {
    habilidad = 'plan_mantenimiento';
    const vehicle = account.vehicle ?? {};
    const plate = first(vehicle.plate, vehicle.placa, account.plate, account.placa);
    const planVehicleId = first(vehicle.id, account.vehicleId, account.vehiculoId);
    if (planVehicleId || account.accountId || account.userId) comando = `Plan${plate ? ` ${plate}` : ''}`;
    else faltan = ['vehículo registrado'];
  } else if (/\b(historial|ultimo servicio|último servicio|registrar servicio|anotar servicio)\b/.test(text)) {
    if (/\b(ultimo servicio|último servicio|registrar servicio|anotar servicio)\b/.test(text)) {
      habilidad = 'registrar_historial';
      const service = first(account.service, account.servicio);
      const km = first(account.km, account.kilometraje);
      const month = first(account.month, account.mes);
      faltan = [!service && 'servicio', !km && 'kilometraje', month === undefined && 'mes AAAA-MM o indicar que se desconoce'].filter(Boolean);
      if (!faltan.length) comando = `Último servicio | ${service} | ${km} | ${month || ''}`;
    } else {
      habilidad = 'consultar_historial';
      comando = /\b(plan completo|historial completo)\b/.test(text) ? 'Plan completo' : 'Plan';
      if (!account.vehicleId && !account.vehicle?.id && !account.accountId && !account.userId) { comando = null; faltan = ['cuenta de dueño con vehículo registrado']; }
    }
  } else if (/\b(aceptar|acepto)\b/.test(text)) {
    habilidad = 'aceptar_oferta'; riesgo = 'alto';
    const position = text.match(/\b([1-5])\b/)?.[1];
    const request = text.match(/\bs-[0-9a-f]{6}\b/i)?.[0];
    const requestId = first(account.requestId, account.solicitudId, text.match(/\bs-[0-9a-f]{6}\b/i)?.[0]);
    const offerId = first(account.offerId, account.ofertaId);
    if (requestId && offerId) comando = `Aceptar | ${requestId} | ${offerId}`;
    else if (position && (request || account.hasPendingOffer === true)) comando = `Aceptar${request ? ` ${request.toUpperCase()}` : ''} ${position}`;
    else {
      if (!position) faltan.push('número de oferta');
      if (!request && !account.hasPendingOffer) faltan.push('código S- de solicitud con oferta propia');
    }
  } else if (/\b(confirmar|confirmo)\b/.test(text) && /\b(cita|turno)\b/.test(text)) {
    habilidad = 'confirmar_cita'; riesgo = 'alto';
    const ref = text.match(/\bc-[0-9a-f]{6}\b/i)?.[0];
    const requestId = first(account.requestId, account.solicitudId);
    const appointmentId = first(account.appointmentId, account.citaId);
    if (requestId && appointmentId) comando = `Confirmar cita | ${requestId} | ${appointmentId}`;
    else if (ref) comando = `Confirmar ${ref.toUpperCase()}`;
    else faltan = ['código C- de la cita'];
  } else if (/\b(buscar|busco|necesito|cotizar)\b/.test(text) && /\b(taller|servicio|repuesto|pieza)\b/.test(text)) {
    const part = /\b(repuesto|pieza)\b/.test(text);
    habilidad = part ? 'buscar_repuesto' : 'buscar_servicio';
    const fields = { categoria: first(account.category, account.categoria), ciudad: first(account.city, account.ciudad), sector: first(account.zone, account.sector), descripcion: first(account.description, account.descripcion) };
    faltan = Object.keys(fields).filter(key => !fields[key]);
    if (!vehicleId && !role.includes('taller') && !role.includes('almacen')) faltan.push('vehículo registrado');
    if (!faltan.length) comando = `Buscar ${part ? 'repuesto' : 'servicio'} | ${fields.categoria} | ${fields.ciudad} | ${fields.sector} | ${fields.descripcion}`;
  }
  return { habilidad, comando: faltan.length ? null : comando, faltan, riesgo };
}

/** Deduce el perfil de registro del texto libre; null si no se puede. */
export function inferProfile(message) {
  const t = words(message).trim();
  // Respuesta corta con la opción ("Acepto, 1", "la 2", "opción 3").
  const option = t.length <= 30 ? t.match(/(?:^|\W)(1|2|3|uno|dos|tres)(?:\W|$)/)?.[1] : null;
  if (option) return ({ 1: 'dueno', uno: 'dueno', 2: 'taller', dos: 'taller', 3: 'almacen', tres: 'almacen' })[option];
  if (/^(1|uno|opcion 1)\b/.test(t)) return 'dueno';
  if (/^(2|dos|opcion 2)\b/.test(t)) return 'taller';
  if (/^(3|tres|opcion 3)\b/.test(t)) return 'almacen';
  if (/\b(almacen|repuestos|autopartes|vendo (repuestos|piezas)|distribuidora)\b/.test(t)) return 'almacen';
  if (/\b(taller|mecanica|lubricadora|lavadora|vulcanizadora|electromecanica|enderezada|tengo un negocio de autos)\b/.test(t)) return 'taller';
  if (/\b(mi (carro|auto|vehiculo|moto|camioneta)|dueno|propietario|tengo un (carro|auto|vehiculo))\b/.test(t)) return 'dueno';
  return null;
}

const PROFILE_LABELS = { dueno: '🚗 Dueño de vehículo', taller: '🔧 Taller', almacen: '📦 Almacén de repuestos' };
/**
 * Registro sin bandeja (23/11/2026): quien pide registrarse y aún no tiene cuenta recibe al instante un texto fijo
 * (no redactado por el modelo) con el formulario de su perfil, o la pregunta de qué perfil es. Apagar: LOCAL_AGENT_AUTO_REGISTRO=off.
 */
export function autoRegistrationReply(action, job = {}, env = process.env) {
  if (env.LOCAL_AGENT_AUTO_REGISTRO === 'off' || action?.habilidad !== 'registro' || action.comando) return null;
  if (job.role && job.role !== 'nuevo') return null;
  if (!action.perfil || !PROFILE_LABELS[action.perfil]) return '¡Hola! 👋 Con gusto te ayudo a registrarte en AutoMantPro. ¿Cuál es tu perfil?\n1. Dueño de vehículo\n2. Taller\n3. Almacén de repuestos\nResponde con el número.';
  return `¡Hola! 👋 Regístrate aquí en 2 minutos:\n${signupLink(action.perfil, env.LOCAL_AGENT_URL || 'https://automantpro.app')}\nLlena tus datos y entra con el código que te llega por este WhatsApp. Es gratis.`;
}

/** Enlace de alta del perfil (o los tres si aún no se sabe). La web verifica el número con un código por WhatsApp. */
export function signupLink(profile, site = process.env.LOCAL_AGENT_URL || 'https://automantpro.app') {
  const base = String(site).replace(/\/+$/, '');
  const one = key => `${PROFILE_LABELS[key]}: ${base}/cuenta?perfil=${key}#crear`;
  return profile && PROFILE_LABELS[profile] ? one(profile) : Object.keys(PROFILE_LABELS).map(one).join('\n');
}

// Alguien busca un taller o un servicio para su vehículo.
const SERVICE_NEED = /\b(taller(es)?|mecanic[oa]s?|lubricadora|lavadora|vulcanizadora|electromecanica|enderezada|grua)\b|\b(necesito|busco|quiero|donde|quien)\b.*\b(aceite|frenos?|llantas?|bateria|alineacion|balanceo|motor|suspension|transmision|embrague|aire acondicionado|escaner|lavado|pintura|revision|mantenimiento|reparar|arreglar)\b/;
// Sin cuenta: la búsqueda pública, sin pedir registro primero.
const PUBLIC_WORKSHOPS = { ruta: '/talleres', etiqueta: 'Busca talleres aquí', pista: 'La persona busca un taller o servicio: dile en una frase que puede buscarlo por ciudad en el enlace del final y agendar con su cuenta gratis. No inventes nombres, precios ni disponibilidad.' };

// Web primero (19/11/2026): si la persona pregunta por algo que se hace en su panel, el sistema agrega el enlace a esa
// sección (un solo enlace por mensaje). El modelo no lo escribe: lo pega la regla al final, como el enlace de alta.
// Cada entrada: patrón, sección por perfil (solo los perfiles que la tienen en su panel), título y, si va fuera del
// panel, la página pública con su etiqueta y una pista para el modelo.
const PLANS_PAGE = { ruta: '/planes', etiqueta: 'Planes y precios', pista: 'Los precios de los planes están publicados en esa página: no digas que no los conoces ni ofrezcas cotización. Por chat también puede escribir: Planes.' };
// Taller que ya usa otra app o sistema (23/11/2026): AutoMantPro se presenta como un apoyo adicional, no como reemplazo.
const ALREADY_HAVE_APP = /\bya (tenemos|tengo|usamos|uso|manejamos|manejo|trabajamos con|contamos con|cuento con)\b.*\b(app|apps|aplicacion|aplicaciones|sistema|software|programa|plataforma)\b/;
const ALREADY_HAVE_HINT = 'Ya usa otra app o sistema: responde con respeto que AutoMantPro puede ser un apoyo adicional, no un reemplazo; suma el perfil público con sello de fundador, los avisos de mantenimiento a sus clientes y las citas por WhatsApp. No critiques la otra app.';
// Contacto sin cuenta (fundador) que pregunta costos: la página pública de planes, que no requiere cuenta.
const PUBLIC_PLANS = /\b(precios?|costos?|cuesta|cuestan|cobran|cobra|tarifas?|pagar|gratis|gratuito|mensualidad)\b/;
const SECTIONS = [
  [/\b(planes|suscripcion(es)?)\b|\bplan (premium|pro|gratis|gratuito|basico|avanzado|flota|taller pro)\b|\b(precios?|costos?|cuesta|cuestan|vale|valen|pagar)\b.*\bplan(es)?\b|\bplan(es)?\b.*\b(precios?|costos?|cuesta|cuestan|vale|valen)\b/,
    { dueno: 'planes', taller: 'planes', almacen: 'planes' }, 'Planes', PLANS_PAGE],
  [/\b(flota|conductor(es)?|chofer(es)?|supervisor(es)?|convenios?)\b/, { dueno: 'flota' }, 'Tu flota'],
  [/\b(caja|gastos del taller|cobros del (dia|mes)|utilidad del (dia|mes))\b/, { taller: 'caja' }, 'Caja del taller'],
  [/\b(cargar|subir) (las |mis )?fichas\b|\bfichas de (mis )?clientes\b/, { taller: 'cargar-fichas' }, 'Cargar fichas de clientes'],
  [/\binformes? tecnicos?\b/, { dueno: 'ordenes', taller: 'ordenes' }, 'Órdenes de trabajo'],
  [/\b(curso|cursos|experto|certificado|capacitacion)\b/, { dueno: 'cursos', taller: 'cursos', almacen: 'cursos' }, 'Cursos'],
  [/\b(sin cita|llego un (carro|vehiculo|auto)|recibir (un )?vehiculo)\b/, { taller: 'sin-cita' }, 'Vehículos sin cita'],
  // Alertas, equipo, trabajos e ingreso (27/11/2026): también llevan a su sección.
  [/\balertas?\b|\bavisos? de mantenimiento\b|\bproximos? mantenimientos?\b/, { dueno: 'alertas', taller: 'alertas' }, { dueno: 'Mis alertas', taller: 'Alertas a clientes' }],
  [/\b(agregar|anadir|registrar) (un |mi )?tecnico\b|\bmi equipo\b/, { taller: 'equipo' }, 'Equipo'],
  [/\b(mis )?trabajos( asignados| pendientes)?\b|\bmis ordenes\b/, { dueno: 'ordenes', taller: 'ordenes' }, 'Órdenes de trabajo'],
  [/\b(registr\w+|hacer) (un |el )?ingreso\b|\bingreso (de un|del) (carro|vehiculo|auto)\b/, { taller: 'citas' }, 'Citas por atender'],
  [/\b(agendar|agendame|reservar|turno|citas?)\b/, { dueno: 'book', taller: 'citas' }, { dueno: 'Agendar cita', taller: 'Citas por atender' }],
  [/\btalleres? (cerca|cercanos?|recomendados?)\b|\bbuscar (un )?taller\b|\bque talleres\b/, { dueno: 'talleres' }, 'Talleres cerca de ti'],
  // Cualquier pedido se responde con el lugar donde se hace (26/11/2026).
  [/\b(reclamo|reclamar|garantia|presupuesto|cotizacion de (la )?orden|factura|comprobante|orden( de trabajo)?|entrega|calificar|pagar la orden|cobro)\b/, { dueno: 'ordenes', taller: 'ordenes' }, 'Órdenes de trabajo'],
  [/\b(mis pedidos|pedidos? (pendientes?|por responder)|ofertar|cotizar|solicitudes?)\b/, { almacen: 'por-responder', taller: 'por-responder' }, { almacen: 'Pedidos de repuestos', taller: 'Solicitudes por responder' }],
  [/\b(catalogo|stock|inventario|subir productos|mis precios)\b/, { almacen: 'catalogo', taller: 'catalogo' }, { almacen: 'Mi catálogo', taller: 'Catálogo de servicios' }],
  [/\b(tarifas?|tarifario|horarios?|a domicilio)\b/, { taller: 'tarifario' }, 'Tarifario, horario y domicilio'],
  [/\b(promocion(es)?|descuentos?|ofertas del mes)\b/, { dueno: 'promociones', taller: 'promociones', almacen: 'promociones' }, 'Promociones'],
  [/\b(repuestos?|autopartes|piezas?)\b/, { dueno: 'book', taller: 'ordenes' }, { dueno: 'Pide ofertas de repuestos', taller: 'Órdenes de trabajo' }],
  [SERVICE_NEED, { dueno: 'talleres' }, 'Talleres cerca de ti'],
];

/** Sección del panel para el mensaje, o null. No aplica a contactos sin cuenta (ellos reciben el enlace de alta). */
export function sectionLink(message, role, site = process.env.LOCAL_AGENT_URL || 'https://automantpro.app') {
  const text = words(message);
  const base = String(site).replace(/\/+$/, '');
  // Sin cuenta: solo la página pública de planes, si pregunta costos o ya usa otra app (23/11/2026).
  if (!role || role === 'nuevo') {
    const already = ALREADY_HAVE_APP.test(text);
    // Quien busca taller o servicio (y no ofrece el suyo ni pregunta por precios de los planes) va a la búsqueda pública.
    if (!already && !PUBLIC_PLANS.test(text) && !SECTIONS[0][0].test(text)) {
      if (!SERVICE_NEED.test(text) || /\b(tengo|soy|mi) (un |una )?(taller|mecanica|lubricadora|lavadora|vulcanizadora)\b|\bregistr/.test(text)) return null;
      return { seccion: 'talleres', titulo: 'Talleres', url: `${base}${PUBLIC_WORKSHOPS.ruta}`, etiqueta: PUBLIC_WORKSHOPS.etiqueta, pista: PUBLIC_WORKSHOPS.pista };
    }
    return { seccion: 'planes', titulo: 'Planes', url: `${base}${PLANS_PAGE.ruta}`, etiqueta: PLANS_PAGE.etiqueta, pista: [PLANS_PAGE.pista, already ? ALREADY_HAVE_HINT : ''].filter(Boolean).join(' ') };
  }
  const hit = SECTIONS.find(([pattern, byRole]) => byRole[role] && pattern.test(text));
  if (!hit) return null;
  const [, byRole, title, page] = hit;
  const titulo = typeof title === 'string' ? title : title[role];
  return page
    ? { seccion: byRole[role], titulo, url: `${base}${page.ruta}`, etiqueta: page.etiqueta, pista: page.pista }
    : { seccion: byRole[role], titulo, url: `${base}/cuenta#${byRole[role]}`, etiqueta: 'En tu panel', pista: null };
}
