import { chmod, mkdir, rename, stat, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { agentOptions, askModel } from './drafter.mjs';

const PROBE = 'Responde solo con la palabra: listo';

/** Sending stays blocked until Pedro sets LOCAL_AGENT_MODO_PRUEBA=0 after the tests pass. */
export function isTestMode(env = process.env) { return env.LOCAL_AGENT_MODO_PRUEBA !== '0'; }

/** Checks server, bridge and every drafter with a synthetic probe; no contact data is involved. */
export async function checkReadiness({ client, kinds, env = process.env, ask = askModel, now = Date.now, statImpl = stat,
  bridgeStatePath = join(process.cwd(), 'data', 'bridge-state.json'), bridgeMaxAgeMinutes = 30, timeoutMs = 120_000 } = {}) {
  const servidor = client
    ? await client.ping().then(status => ({ listo: true, entrega: status.whatsappDelivery }), error => ({ listo: false, error: error.code || 'ERROR' }))
    : { listo: false, error: 'SIN_CLIENTE' };
  const puente = await statImpl(bridgeStatePath).then(info => {
    const minutos = Math.max(0, Math.round((now() - info.mtimeMs) / 60_000));
    return { listo: minutos <= bridgeMaxAgeMinutes, minutosDesdeActividad: minutos };
  }, () => ({ listo: false, error: 'SIN_ESTADO' }));
  const agentes = Object.fromEntries(await Promise.all(kinds.map(async kind => {
    const started = now();
    const text = await ask(kind, PROBE, { ...agentOptions(kind, env), timeoutMs }).catch(() => null);
    return [kind, { listo: typeof text === 'string' && /listo/i.test(text), segundos: Math.round((now() - started) / 1000) }];
  })));
  const listos = kinds.filter(kind => agentes[kind].listo);
  return { fecha: new Date(now()).toISOString(), listo: servidor.listo && puente.listo && listos.length > 0,
    redactorPrincipal: listos[0] ?? null, modoPrueba: isTestMode(env), servidor, puente, agentes };
}

export function summarizeReadiness(estado) {
  const mark = ok => (ok ? '✔' : '✘');
  const agents = Object.entries(estado.agentes).map(([kind, agent]) => `${kind} ${mark(agent.listo)}`).join(' ');
  return `Listos: ${agents} · puente ${mark(estado.puente.listo)} · servidor ${mark(estado.servidor.listo)} → ${estado.listo ? `LISTO para responder (redacta ${estado.redactorPrincipal})` : 'NO LISTO'}${estado.modoPrueba ? ' · MODO PRUEBA: ENVIO y EJECUTAR bloqueados' : ''}`;
}

export async function writeReadiness(estado, path = join(process.cwd(), 'data', 'estado-agentes.json')) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const tmp = `${path}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tmp, `${JSON.stringify(estado, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  await rename(tmp, path);
  await chmod(path, 0o600);
  return path;
}
