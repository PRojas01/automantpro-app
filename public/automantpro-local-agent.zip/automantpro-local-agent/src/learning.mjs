import { chmod, mkdir, open, readFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { anonymize } from './drafter.mjs';

export async function recordLearning({ message, suggested = '', reply, memoryDb, path = new URL('../data/memoria/aprendizaje.jsonl', import.meta.url).pathname }) {
  if (typeof message !== 'string' || typeof reply !== 'string' || !reply.trim()) return false;
  if (memoryDb) return memoryDb.guardarAprendizaje({ message, suggested, final: reply, accion: 'ENVIO' });
  const row = { mensaje: anonymize(message), sugerida: anonymize(suggested), respuesta: anonymize(reply), creado: new Date().toISOString() };
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const handle = await open(path, 'a', 0o600);
  try { await handle.write(`${JSON.stringify(row)}\n`); await handle.sync(); }
  finally { await handle.close(); }
  await chmod(path, 0o600);
  return true;
}
