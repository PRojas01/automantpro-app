// Supervisión local del puente y del operador: tiempos por etapa, latidos, vigilante e informe.
// Nada de aquí guarda texto de mensajes, nombres ni números completos.
import { appendFile, mkdir, readFile, readdir, rename, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const leer = file => readFile(file, 'utf8').catch(() => '');
const leerJson = async file => { try { return JSON.parse(await readFile(file, 'utf8')); } catch { return null; } };
const limpio = value => String(value ?? '').replace(/[^a-z0-9_-]/gi, '').slice(0, 24);

/** Línea «hora etapa ms=N etiqueta» en data/tiempos.log. Nunca detiene al proceso que mide. */
export async function registrarTiempo(dataDir, etapa, ms, etiqueta = '') {
  try {
    const file = join(dataDir, 'tiempos.log');
    if ((await stat(file).catch(() => null))?.size > 512 * 1024) await rename(file, `${file}.1`);
    const tag = limpio(etiqueta);
    await appendFile(file, `${new Date().toISOString()} ${limpio(etapa)} ms=${Math.max(0, Math.round(ms))}${tag ? ` ${tag}` : ''}\n`, { mode: 0o600 });
  } catch { /* medir es opcional */ }
}

export async function escribirLatido(dataDir, quien, datos = {}) {
  try {
    await mkdir(dataDir, { recursive: true, mode: 0o700 });
    const file = join(dataDir, `${quien}-latido.json`);
    await writeFile(`${file}.tmp`, JSON.stringify({ ...datos, fecha: new Date().toISOString() }), { mode: 0o600 });
    await rename(`${file}.tmp`, file);
  } catch { /* el latido nunca detiene al proceso */ }
}

export const LIMITES = Object.freeze({ latidoMin: 6, sinListaMin: 10, vueltasFallidas: 5, colaMin: 10, sinLecturaHoras: 6 });
const minutos = (desde, ahora) => (ahora - Date.parse(desde)) / 60_000;

/**
 * Decide qué avisar y qué reiniciar a partir de los latidos y la bandeja. Función pura.
 * Cola envejecida: pendientes de aprobación de más de 10 min y de menos de 24 h (los vencidos solo se informan).
 */
export function evaluarVigilancia({ puente, operador, pendientes = [] }, ahora = Date.now(), limites = LIMITES) {
  const alertas = [];
  const reiniciar = new Set();
  const alerta = (codigo, detalle, proceso) => { alertas.push({ codigo, detalle }); if (proceso) reiniciar.add(proceso); };
  if (!puente?.fecha) alerta('PUENTE_SIN_LATIDO', 'El puente no ha escrito latido.');
  else if (minutos(puente.fecha, ahora) > limites.latidoMin) alerta('PUENTE_DETENIDO', `Sin vueltas hace ${Math.round(minutos(puente.fecha, ahora))} min.`, 'puente');
  else if (puente.sinSesion) alerta('PUENTE_SIN_SESION', 'WhatsApp Web sin sesión: puede pedir el código QR.');
  else if (puente.sinListaDesde && minutos(puente.sinListaDesde, ahora) > limites.sinListaMin) alerta('PUENTE_CIEGO', 'La lista de chats no se ve.', 'puente');
  else if (puente.vueltasFallidas >= limites.vueltasFallidas) alerta('PUENTE_FALLANDO', `${puente.vueltasFallidas} vueltas fallidas seguidas.`, 'puente');
  else if (puente.ultimaLectura && minutos(puente.ultimaLectura, ahora) > limites.sinLecturaHoras * 60) alerta('PUENTE_SIN_LECTURAS', `Ningún chat leído hace más de ${limites.sinLecturaHoras} h.`);
  if (!operador?.fecha) alerta('OPERADOR_SIN_LATIDO', 'El operador no ha escrito latido.');
  else if (minutos(operador.fecha, ahora) > limites.latidoMin) alerta('OPERADOR_DETENIDO', `Sin consultar la cola hace ${Math.round(minutos(operador.fecha, ahora))} min.`, 'operador');
  const edades = pendientes.map(p => minutos(p.creado, ahora)).filter(m => m > limites.colaMin && m < 24 * 60);
  if (edades.length) alerta('COLA_ENVEJECIDA', `${edades.length} pendiente(s) de aprobación; el más antiguo, ${Math.round(Math.max(...edades))} min.`);
  return { alertas, reiniciar: [...reiniciar] };
}

export async function leerPendientes(dataDir) {
  const dir = join(dataDir, 'bandeja', 'pendientes');
  const files = await readdir(dir).catch(() => []);
  const rows = await Promise.all(files.filter(f => f.endsWith('.json')).map(f => leerJson(join(dir, f))));
  // Solo metadatos: el texto del mensaje y el borrador no salen de la bandeja.
  return rows.filter(Boolean).map(p => ({ creado: p.creado, telefono: p.telefonoEnmascarado, riesgo: p.riesgo, habilidad: p.accionPropuesta?.habilidad ?? 'otro' }));
}

export async function leerEstado(dataDir) {
  return { puente: await leerJson(join(dataDir, 'puente-latido.json')), operador: await leerJson(join(dataDir, 'operador-latido.json')), pendientes: await leerPendientes(dataDir) };
}

const percentil = (list, f) => { const s = [...list].sort((a, b) => a - b); return s.length ? s[Math.min(s.length - 1, Math.floor(f * s.length))] : 0; };
const contar = list => list.reduce((acc, k) => acc.set(k, (acc.get(k) || 0) + 1), new Map());
const recientes = (texto, desde) => texto.split('\n').filter(l => Date.parse(l.split(' ')[0]) >= desde);

/** Informe en Markdown para la supervisión (Claude o una persona): pendientes, fallos y envíos frenados. */
export async function informeSupervision(dataDir, { ahora = Date.now(), horas = 24 } = {}) {
  const desde = ahora - horas * 3_600_000;
  const estado = await leerEstado(dataDir);
  const { alertas } = evaluarVigilancia(estado, ahora);
  const diag = recientes(await leer(join(dataDir, 'puente-diagnostico.log')), desde).map(l => l.split(' '));
  const registro = recientes(await leer(join(dataDir, 'bandeja', 'registro.log')), desde);
  const tiempos = recientes(await leer(join(dataDir, 'tiempos.log')), desde).map(l => l.split(' '));
  // servicio.log usa hora local «AAAA-MM-DD HH:mm:ss».
  const servicio = (await leer(join(dataDir, 'servicio.log'))).split('\n').filter(l => Date.parse(l.slice(0, 19).replace(' ', 'T')) >= desde);

  const lista = (map, vacio = '- Nada') => (map.size ? [...map].sort((a, b) => b[1] - a[1]).map(([k, n]) => `- ${k}: ${n}`).join('\n') : vacio);
  const fallos = contar(diag.map(p => p[2] || '').filter(m => /^(vuelta-fallida|no-se-pudo-leer|recarga)/.test(m)).map(m => m.replace(/^no-se-pudo-leer.*/, 'no-se-pudo-leer')));
  const caidas = servicio.filter(l => /termina con código (?!0\b)/.test(l)).length;
  if (caidas) fallos.set('caídas de proceso', caidas);
  const frenados = contar(diag.filter(p => p[2]?.startsWith('salida-falla')).map(p => `${p[2].replace('salida-falla-', '')} · ${(p.find(x => x.startsWith('cat=')) ?? 'cat=?').slice(4).split('_reintento')[0]}`));
  const retenidos = contar(diag.filter(p => /inseguros=[1-9]/.test(p.join(' ')) && p.includes('pendientes=0') && p.includes('enviados=0')).map(p => p[1]));
  const sinCierre = contar(registro.map(l => l.trim().split(' ').at(-1)).filter(r => r && r !== 'completed'));
  const porEtapa = new Map();
  for (const p of tiempos) { const ms = Number(/^ms=(\d+)$/.exec(p[2] ?? '')?.[1]); if (Number.isFinite(ms)) porEtapa.set(p[1], [...(porEtapa.get(p[1]) ?? []), ms]); }
  const seg = ms => (ms / 1000).toFixed(1);

  return [
    `# Supervisión del agente local · ${new Date(ahora).toISOString()} · últimas ${horas} h`,
    '## Alertas', alertas.length ? alertas.map(a => `- ${a.codigo}: ${a.detalle}`).join('\n') : '- Nada',
    `## Pendientes de aprobación (${estado.pendientes.length})`,
    estado.pendientes.length ? estado.pendientes.map(p => `- ${p.telefono} · ${p.habilidad} · riesgo ${p.riesgo} · ${Math.round(minutos(p.creado, ahora))} min`).join('\n') : '- Nada',
    '## Fallos', lista(fallos),
    '## Envíos frenados (tipo · motivo)', lista(frenados),
    '## Chats con mensajes retenidos por emisor dudoso', lista(retenidos),
    '## Pendientes cerrados sin respuesta entregada', lista(sinCierre),
    '## Tiempos por etapa (s)', porEtapa.size ? ['| etapa | n | p50 | p90 | máx |', '|---|---|---|---|---|', ...[...porEtapa].map(([k, v]) => `| ${k} | ${v.length} | ${seg(percentil(v, 0.5))} | ${seg(percentil(v, 0.9))} | ${seg(Math.max(...v))} |`)].join('\n') : '- Sin mediciones todavía',
    '',
  ].join('\n');
}
