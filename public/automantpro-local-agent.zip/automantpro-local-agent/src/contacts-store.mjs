import { createHmac, randomBytes } from 'node:crypto';
import { chmod, mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim().replace(/\s+/g, ' ');
const digitsOnly = value => String(value || '').replace(/\D/g, '');
const validDigits = value => /^\d{8,15}$/.test(String(value || ''));
const MAX_ENTRIES = 500;

export function hashContactName(name, key) {
  return createHmac('sha256', key).update(normalize(name)).digest('hex');
}

export function contactCommand(text) {
  if (/^\s*baja\s*$/i.test(String(text || ''))) return 'baja';
  if (/^\s*alta\s*$/i.test(String(text || ''))) return 'alta';
  return null;
}

export function createContactsStore(dataDir) {
  const file = join(dataDir, 'permitidos.json');
  const keyFile = join(dataDir, '.clave-contactos');
  async function key() {
    await mkdir(dataDir, { recursive: true, mode: 0o700 });
    try { const bytes = await readFile(keyFile); await chmod(keyFile, 0o600); return bytes; }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      const bytes = randomBytes(32);
      try { await writeFile(keyFile, bytes, { flag: 'wx', mode: 0o600 }); }
      catch (race) { if (race.code !== 'EEXIST') throw race; return key(); }
      return bytes;
    }
  }
  async function load() {
    try {
      const parsed = JSON.parse(await readFile(file, 'utf8'));
      return Array.isArray(parsed) ? parsed.filter(e => validDigits(e?.digits) && typeof e.nombreHash === 'string') : [];
    } catch (error) { if (error.code === 'ENOENT') return []; throw error; }
  }
  async function save(entries) {
    await mkdir(dirname(file), { recursive: true, mode: 0o700 });
    const tmp = `${file}.${process.pid}.${randomBytes(6).toString('hex')}.tmp`;
    await writeFile(tmp, JSON.stringify(entries), { mode: 0o600 });
    await chmod(tmp, 0o600);
    await rename(tmp, file);
    await chmod(file, 0o600);
  }
  async function add({ digits, name = '', origen = 'mencion' }) {
    if (!validDigits(digitsOnly(digits))) return false;
    const now = new Date().toISOString(); const secret = await key(); const entries = await load();
    const clean = digitsOnly(digits); const existing = entries.find(e => e.digits === clean);
    const next = entries.filter(e => e.digits !== clean);
    next.push({ digits: clean, nombreHash: String(name || '').trim() ? hashContactName(name, secret) : (existing?.nombreHash ?? hashContactName('', secret)), origen: existing?.origen ?? origen, alta: existing?.alta || now, ultimaVez: now, ...(existing?.baja ? { baja: true } : {}) });
    const pruned = next.length > MAX_ENTRIES ? next.sort((a, b) => Date.parse(a.ultimaVez || a.alta) - Date.parse(b.ultimaVez || b.alta)).slice(next.length - MAX_ENTRIES) : next;
    await save(pruned); return true;
  }
  async function update(digits, command) {
    const clean = digitsOnly(digits); if (!validDigits(clean)) return false;
    const entries = await load(); const found = entries.find(e => e.digits === clean); if (!found) return false;
    found.ultimaVez = new Date().toISOString();
    if (command === 'baja') found.baja = true;
    if (command === 'alta') delete found.baja;
    await save(entries); return true;
  }
  async function isAllowed(digits) { return (await load()).some(e => e.digits === digitsOnly(digits) && !e.baja); }
  async function touch(digits) { const entries = await load(); const found = entries.find(e => e.digits === digitsOnly(digits)); if (found) { found.ultimaVez = new Date().toISOString(); await save(entries); } }
  /** Saved-name chats already authorized (by HMAC of the name, never the name itself) and not in BAJA. */
  async function nameMatcher() {
    const secret = await key(); const entries = await load();
    const allowed = new Set(entries.filter(e => !e.baja).map(e => e.nombreHash));
    return name => Boolean(name) && allowed.has(hashContactName(name, secret));
  }
  return { file, keyFile, load, add, update, isAllowed, touch, nameMatcher };
}
