import { appendFile, mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { stdout } from 'node:process';
import { AgentError } from './client.mjs';
import { classifyBusinessLead, classifyWithLocalModel, masked } from './bridge-core.mjs';

/**
 * One-off review of the WhatsApp history on the operator's computer, to find workshops and stores
 * that asked about AutoMantPro before. It uses WhatsApp's own search with a few keywords, opens only
 * the matching chats at a human pace and classifies them locally. Nothing is sent to the server,
 * to any AI or to anyone: the result is a private list (0600) for the owner to review.
 * Stop the bridge first: both use the same WhatsApp Web session.
 */
const require = createRequire(import.meta.url);
// Access control: the agent opens only chats that WhatsApp's own search returns for "automant",
// or chats the owner lists by exact name in permitidos.txt. Any other chat is never opened or read.
const ACCESS_WORD = 'automant';
const MAX_CHATS = 200;

/** Scrolls the open (allowed) chat up a few times and accepts "get older messages from your phone". */
async function loadOlder(page, pause) {
  for (let round = 0; round < 10; round++) {
    const button = page.getByText(/mensajes anteriores|older messages/i).first();
    if (await button.count().catch(() => 0)) { await button.click().catch(() => {}); await pause(2500, 4000); }
    const height = await page.evaluate(() => {
      const panel = [...document.querySelectorAll('#main div')].find(d => d.scrollHeight > d.clientHeight + 50 && /(auto|scroll)/.test(getComputedStyle(d).overflowY));
      if (!panel) return 0;
      const h = panel.scrollHeight; panel.scrollTop = 0; return h;
    });
    if (!height) break;
    await pause(1500, 2500);
    const grown = await page.evaluate(h => { const panel = [...document.querySelectorAll('#main div')].find(d => d.scrollHeight > d.clientHeight + 50 && /(auto|scroll)/.test(getComputedStyle(d).overflowY)); return !!panel && panel.scrollHeight > h; }, height);
    if (!grown) break;
  }
}

async function main() {
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const dataDir = resolve(process.env.WHATSAPP_DATA_DIR || 'data');
  process.env.HUMAN_DIR = join(dataDir, 'human');
  const { chromium } = require('playwright-core');
  const { resolver } = require('./vendor/pymeagents/browser/actions/whatsapp-selectors.cjs');
  const wa = require('./vendor/pymeagents/browser/actions/whatsapp.cjs');
  const context = await chromium.launchPersistentContext(resolve(process.env.WHATSAPP_PROFILE_DIR || join(dataDir, 'whatsapp-profile')), { executablePath: process.env.WHATSAPP_BROWSER_PATH || '/usr/bin/google-chrome', headless: false, chromiumSandbox: true, viewport: { width: 1280, height: 860 }, locale: 'es-EC' });
  const page = context.pages()[0] ?? await context.newPage();
  const pause = (min, max) => page.waitForTimeout(min + Math.floor(Math.random() * (max - min)));
  const log = text => stdout.write(`${text}\n`);
  try {
    await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
    if (!(await wa.waitForAuth(page, 90_000))) throw new AgentError('WHATSAPP_NOT_LINKED');
    const found = new Map();
    const allowed = (await readFile(resolve('permitidos.txt'), 'utf8').catch(() => '')).split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.startsWith('#')).slice(0, 100);
    const audit = async (decision, reason, phone) => appendFile(resolve('acceso-chats.log'), `${new Date().toISOString()} ${decision} ${phone ? masked(phone) : '-'} ${reason}\n`, { mode: 0o600 });
    // Each search is either the access word (any matching chat) or one allowlisted name (that exact chat only).
    const searches = [{ term: ACCESS_WORD, exact: null }, ...allowed.map(name => ({ term: name, exact: name }))];
    for (const { term: keyword, exact } of searches) {
      if (found.size >= MAX_CHATS) break;
      let box = await resolver(page, 'buscador', { timeoutMs: 8000 });
      if (!box) {
        // The search box hides while a chat or panel is open: reload the main view and retry.
        await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
        if (!(await wa.waitForAuth(page, 90_000))) throw new AgentError('WHATSAPP_NOT_LINKED');
        await pause(2000, 3500);
        box = await resolver(page, 'buscador', { timeoutMs: 15000 });
        if (!box) { log(`No se encontró el buscador para "${keyword}"; sigo con la siguiente palabra.`); continue; }
      }
      await box.locator.click(); await pause(400, 900);
      await page.keyboard.press('Control+A'); await page.keyboard.press('Backspace');
      await page.keyboard.type(keyword, { delay: 90 + Math.floor(Math.random() * 60) });
      await pause(2500, 4000);
      await page.locator('#pane-side').evaluate(el => el.scrollTo(0, 0)).catch(() => {});
      // Results are a virtual list: walk it by scrolling, remembering which rows were already opened.
      const seenRows = new Set(); let idle = 0; let opened = 0;
      const skipped = { sinChat: 0, grupo: 0, sinNumero: 0, repetido: 0, error: 0 };
      while (idle < 3 && found.size < MAX_CHATS) {
        const rows = page.locator('#pane-side [role=row], #pane-side [role="listitem"]');
        const count = await rows.count();
        let progressed = false;
        for (let i = 0; i < count && found.size < MAX_CHATS; i++) {
          const key = ((await rows.nth(i).textContent().catch(() => '')) || '').slice(0, 120);
          if (!key || seenRows.has(key)) continue;
          seenRows.add(key); progressed = true;
          // An allowlisted name only opens the chat with exactly that title, never other matches.
          if (exact) {
            const rowTitle = ((await rows.nth(i).locator('span[title]').first().getAttribute('title').catch(() => '')) || '').trim();
            if (rowTitle !== exact) { await audit('BLOQUEADO', 'no coincide con el nombre permitido'); continue; }
          }
          try {
            await rows.nth(i).click(); await pause(1500, 2800);
            if (!(await page.locator('#main header').count())) { skipped.sinChat++; continue; }
            // The phone number is shown in the contact info panel; groups show participants instead.
            const phoneTexts = () => page.evaluate(() => [...document.querySelectorAll('span, div')].filter(e => e.childElementCount === 0).map(e => (e.textContent || '').trim()).filter(t => /^\+\d[\d\s()-]{7,20}$/.test(t)));
            const before = new Set(await phoneTexts());
            const title = ((await page.locator('#main header span[title], #main header span[dir="auto"]').first().textContent().catch(() => '')) || '').trim();
            await page.locator('#main header').first().click().catch(() => {}); await pause(1500, 2500);
            const isGroup = await page.evaluate(() => [...document.querySelectorAll('span, div')].some(e => e.childElementCount === 0 && /^\d+ (participantes|members)$/i.test((e.textContent || '').trim())));
            const after = await phoneTexts();
            await page.keyboard.press('Escape').catch(() => {}); await pause(600, 1200);
            const fromTitle = /^\+?[\d\s()-]{8,24}$/.test(title) ? title : null;
            const phone = (after.find(t => !before.has(t)) ?? fromTitle ?? '').replace(/\D/g, '');
            if (isGroup) { skipped.grupo++; continue; }
            if (!/^\d{8,15}$/.test(phone)) { skipped.sinNumero++; continue; }
            if (found.has(phone)) { skipped.repetido++; continue; }
            await audit('ABIERTO', exact ? 'lista de permitidos' : `búsqueda "${ACCESS_WORD}"`, phone);
            // Only for allowed chats: bring older messages from the phone by scrolling up.
            await loadOlder(page, pause);
            const read = await wa.readRecent(page, { limit: 120 });
            const messages = read.ok ? read.messages : [];
            const lead = (await classifyWithLocalModel(messages)) ?? classifyBusinessLead(messages);
            const lastMeta = await page.locator('#main [data-pre-plain-text]').last().getAttribute('data-pre-plain-text').catch(() => '') ?? '';
            found.set(phone, { phone, title: title.slice(0, 80), ...lead, lastMessage: (/\[(.*?)\]/.exec(lastMeta)?.[1] ?? '').trim(), keyword });
            opened++;
            log(`  ${masked(phone)}: ${lead.category}${lead.automantpro ? ' · AutoMantPro' : ''}`);
          } catch { skipped.error++; }
        }
        idle = progressed ? 0 : idle + 1;
        await page.locator('#pane-side').evaluate(el => el.scrollBy(0, el.clientHeight * 0.8)).catch(() => {});
        await pause(1200, 2000);
      }
      log(`Búsqueda "${keyword}": ${seenRows.size} filas, ${opened} chats nuevos (total ${found.size}). Omitidos: ${JSON.stringify(skipped)}`);
      await writeFile(join(dataDir, '..', 'revision-historial.json'), JSON.stringify({ generatedAt: new Date().toISOString(), accessWord: ACCESS_WORD, partial: true, chats: [...found.values()] }, null, 2), { mode: 0o600 });
      await page.keyboard.press('Escape').catch(() => {});
      await pause(1500, 3000);
    }
    const list = [...found.values()].sort((a, b) => Number(b.automantpro) - Number(a.automantpro) || a.category.localeCompare(b.category));
    await mkdir(dataDir, { recursive: true, mode: 0o700 });
    await writeFile(join(dataDir, '..', 'revision-historial.json'), JSON.stringify({ generatedAt: new Date().toISOString(), accessWord: ACCESS_WORD, chats: list }, null, 2), { mode: 0o600 });
    const md = ['# Revisión del historial de WhatsApp (privado, solo en este equipo)', '', 'Marca con una x los chats que quieres importar como contactos "sin consentimiento" y que reciban el mensaje de reactivación.', '', '| Importar | Teléfono | Nombre del chat | Clase | Motivo | Último mensaje |', '|---|---|---|---|---|---|',
      ...list.map(c => `| ${c.automantpro && c.category !== 'personal' ? '[x]' : '[ ]'} | ${c.phone} | ${c.title.replace(/\|/g, ' ')} | ${c.category} | ${c.reasons.join('; ')} | ${c.lastMessage} |`)].join('\n');
    await writeFile(join(dataDir, '..', 'revision-historial.md'), `${md}\n`, { mode: 0o600 });
    const summary = list.reduce((acc, c) => ({ ...acc, [c.category]: (acc[c.category] ?? 0) + 1 }), {});
    log(`Listo: ${list.length} chats revisados. ${JSON.stringify(summary)}. Lista privada en revision-historial.md`);
  } finally { await context.close().catch(() => {}); }
}
main().catch(e => { process.stderr.write(`Revisión detenida: ${e instanceof AgentError ? e.code : e?.message ?? 'ERROR'}\n`); process.exitCode = 1; });
