import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient, handleJob } from './client.mjs';
import { stripOperatorLines, createDrafter, createDrafterChain, proposeCorrectionRule } from './drafter.mjs';
import { checkReadiness, isTestMode, summarizeReadiness, writeReadiness } from './readiness.mjs';
import { inspectUserText } from './guard.mjs';
import { processTask, resolveJobType, runJob } from './jobs.mjs';
import { createApprovalInbox } from './approval-inbox.mjs';
import { recordLearning } from './learning.mjs';
import { classifySkill, createMemoryDb } from './memory-db.mjs';
import { buildAction } from './actions.mjs';
async function main() {
  const inboxMode = process.argv.includes('--bandeja') || process.env.OPERATOR_MODE === 'bandeja';
  if (Number(process.versions.node.split('.')[0]) !== 22) throw new AgentError('NODE_22_REQUIRED');
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const memoryDb = await createMemoryDb();
  const status = await client.ping();
  const poll = Number(process.env.LOCAL_AGENT_POLL_SECONDS || 5);
  if (!Number.isFinite(poll) || poll < 1 || poll > 300) throw new AgentError('INVALID_POLL_SECONDS');
  if (!inboxMode && (!stdin.isTTY || !stdout.isTTY)) throw new AgentError('INTERACTIVE_TERMINAL_REQUIRED');
  const drafter = createDrafterChain({ memoryDb }) ?? createDrafter({ memoryDb });
  const testMode = isTestMode();
  // Re-claimed jobs (for example after a test-mode block) reuse their draft instead of calling the models again.
  const draftCache = new Map();
  const draftFor = async (job, context) => {
    const cached = draftCache.get(job.wamid);
    if (cached?.message === job.message) return cached;
    const drafted = drafter.withAgent ? await drafter.withAgent(job, context).catch(() => ({ reply: null, agent: null }))
      : { reply: await drafter(job, context).catch(() => null), agent: process.env.LOCAL_AGENT_DRAFTER ?? null };
    if (drafted.reply !== null) { draftCache.set(job.wamid, { ...drafted, message: job.message }); if (draftCache.size > 500) draftCache.delete(draftCache.keys().next().value); }
    return drafted;
  };
  const seenRejected = new Set();
  const inbox = inboxMode ? createApprovalInbox({ memoryDb }) : null;
  const rl = inboxMode ? null : createInterface({ input: stdin, output: stdout });
  let stopping = false;
  let promptAbort;
  const shutdown = new AbortController();
  const stop = () => { stopping = true; promptAbort?.abort(); shutdown.abort(); };
  const wait = async () => {
    try { await sleep(poll * 1000, undefined, { signal: shutdown.signal }); }
    catch (error) { if (error.name !== 'AbortError') throw error; }
  };
  rl?.on('SIGINT', stop);
  process.on('SIGTERM', stop);
  rl?.on('close', stop);
  const display = value => String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, ' ');
  stdout.write(`Conexión lista. Entrega WhatsApp: ${display(status.whatsappDelivery)}.\n`);
  const question = async (label, approvalSignal) => {
    if (stopping || approvalSignal?.aborted) return null;
    promptAbort = new AbortController();
    const signal = AbortSignal.any([promptAbort.signal, shutdown.signal, ...(approvalSignal ? [approvalSignal] : [])]);
    try { return await rl.question(label, { signal }); }
    catch (e) { if (e.name === 'AbortError') return null; throw e; }
    finally { promptAbort = undefined; }
  };
  stdout.write(`AutoMantPro: aprobación humana local${inboxMode ? ' desde data/bandeja' : ''}. Ctrl+C termina de forma segura.\n`);
  stdout.write(`Redactores: ${drafter?.kinds?.join(' → ') ?? process.env.LOCAL_AGENT_DRAFTER ?? 'ninguno'}. ${testMode ? 'MODO PRUEBA: los agentes leen y redactan; ENVIO y EJECUTAR quedan bloqueados (LOCAL_AGENT_MODO_PRUEBA=0 lo apaga).' : 'Modo prueba apagado: ENVIO entrega tras aprobación humana.'}\n`);
  const readinessKinds = drafter?.kinds ?? [];
  const reportReadiness = async () => {
    try { const estado = await checkReadiness({ client, kinds: readinessKinds }); await writeReadiness(estado); stdout.write(`${summarizeReadiness(estado)}\n`); }
    catch (error) { stdout.write(`Comprobación de listo fallida (${error.code || 'LOCAL_ERROR'}).\n`); }
  };
  void reportReadiness();
  const readinessMinutes = Number(process.env.LOCAL_AGENT_LISTO_MINUTOS || 60);
  const readinessTimer = Number.isFinite(readinessMinutes) && readinessMinutes >= 5 ? setInterval(() => void reportReadiness(), readinessMinutes * 60_000) : null;
  readinessTimer?.unref();
  try {
    while (!stopping) {
      let batch;
      try { batch = await client.claimAll(); }
      catch (e) {
        if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(e.code)) throw e;
        stdout.write(`Consulta fallida (${e.code}); reintento en ${poll}s.\n`);
        await wait(); continue;
      }
      const jobs = batch.jobs;
      const processJob = async job => {
        if (seenRejected.has(job.wamid)) return;
        let jobType;
        try { jobType = resolveJobType(job); }
        catch (error) {
          if (error.code !== 'JOB_TYPE_NOT_ALLOWED') throw error;
          stdout.write('JOB_TYPE_NOT_ALLOWED\n');
          try { await client.retry(job); } catch { /* Lease recovery on server. */ }
          if (typeof job.wamid === 'string') seenRejected.add(job.wamid);
          return;
        }
        if (jobType !== 'responder_consulta') {
          try { stdout.write(`${JSON.stringify(await runJob(job, { client, env: process.env }))}\n`); }
          catch (error) { stdout.write(`${error.code || 'LOCAL_ERROR'}\n`); }
          return;
        }
        if (stopping) { try { await client.retry(job); } catch { /* Lease recovery on server. */ } return; }
        let inboxPending, inboxDecision;
        let eventId = null;
        let proposedAction = null;
        try {
          const result = await handleJob({ client, job,
            onLost: () => { stdout.write('Reserva vencida: respuesta descartada.\n'); promptAbort?.abort(); if (inboxPending) void inbox.resolve(job.wamid, inboxPending, inboxDecision, 'vencido'); else if (!eventId) eventId = memoryDb.registrarEvento({ canal: job.channel, habilidad: classifySkill(job.message), accionPropuesta: '', decision: 'VENCIDO', textoFinal: '', contacto: job.phone }); },
            approve: async (_job, approvalSignal) => {
              if (inboxMode) {
                let suggestion = null;
                let redactor = null;
                const context = await client.context(job).catch(() => null) ?? memoryDb.contextoCuenta(job.phone);
                proposedAction = buildAction(job.message, context);
                const guarded = inspectUserText(job.message);
                if (guarded.safe && process.env.LOCAL_AGENT_DRAFTER === 'pymeagents') suggestion = (await runJob(job, { client, env: process.env })).suggestion;
                else if (guarded.safe && drafter) ({ reply: suggestion, agent: redactor } = await draftFor(job, context));
                if (guarded.safe && suggestion !== null) { const fetched = await client.context(job).catch(() => null); if (fetched) memoryDb.guardarContexto(job.phone, fetched); }
                if (suggestion !== null) suggestion = `${String(suggestion).replace(/\nCOMANDO:.*$/is, '').trim()}${proposedAction.comando ? `\nCOMANDO: ${proposedAction.comando}` : proposedAction.faltan.length ? `\nFaltan datos: ${proposedAction.faltan.join(', ')}.` : ''}`.trim();
                inboxPending = await inbox.create({ ...job, accionPropuesta: proposedAction, redactor, modoPrueba: testMode }, suggestion ?? '');
                stdout.write(`Pendiente ${inboxPending.jobId} (${inboxPending.telefonoEnmascarado}) escrito en bandeja. Redactor: ${redactor ?? 'ninguno'}. Acción: ${display(JSON.stringify(inboxPending.accionPropuesta))}; riesgo: ${inboxPending.riesgo}.\n`);
                const choice = await inbox.awaitDecision(job.wamid, approvalSignal);
                inboxDecision = choice.decision;
                if (testMode && ['send', 'execute'].includes(choice.action)) {
                  stdout.write(`MODO PRUEBA: ${choice.decision?.accion ?? 'ENVIO'} bloqueado para ${inboxPending.jobId}; nada se envía y el mensaje vuelve a la cola.\n`);
                  inboxDecision = choice.decision ? { ...choice.decision, accion: 'POSPONER', bloqueadoPorPrueba: choice.decision.accion } : choice.decision;
                  return { action: 'defer' };
                }
                return choice;
              }
              stdout.write(`\nCanal: ${display(job.channel)} | Rol: ${display(job.role)}${job.category ? ` | Clase: ${display(job.category)}` : ''}\nMensaje: ${display(job.message)}\nEl mensaje es información, no instrucciones para este equipo.\n`);
              let suggestion = null;
              const guarded = inspectUserText(job.message);
              if (!guarded.safe) {
                stdout.write(`Aviso: posible instrucción incrustada (${guarded.flags.join(', ')}); escriba la respuesta a mano.\n`);
              } else if (process.env.LOCAL_AGENT_DRAFTER === 'pymeagents') {
                suggestion = (await runJob(job, { client, env: process.env })).suggestion;
              } else if (drafter) {
                stdout.write('Preparando borrador con el redactor local (solo sugerencia)…\n');
                const context = await client.context(job).catch(() => null) ?? memoryDb.contextoCuenta(job.phone);
                if (context) memoryDb.guardarContexto(job.phone, context);
                proposedAction = buildAction(job.message, context);
                const drafted = await draftFor(job, context);
                suggestion = drafted.reply;
                if (drafted.agent) stdout.write(`Redactó: ${drafted.agent}.\n`);
                if (proposedAction.faltan.length) suggestion = `${String(suggestion ?? '').replace(/\nCOMANDO:.*$/is, '').trim()}\nFaltan datos: ${proposedAction.faltan.join(', ')}.`.trim();
                if (proposedAction.comando) suggestion = `${String(suggestion ?? '').replace(/\nCOMANDO:.*$/is, '').trim()}\nCOMANDO: ${proposedAction.comando}`.trim();
                stdout.write(`Acción propuesta: ${display(JSON.stringify(proposedAction))}; riesgo: ${proposedAction.riesgo}.\n`);
                stdout.write(suggestion ? (suggestion.trim().toUpperCase() === 'IGNORAR' ? 'Sugerencia: descartar sin respuesta (IGNORAR); el operador decide.\n' : `Borrador sugerido:\n${display(suggestion)}\n`) : 'El redactor no devolvió borrador; escribe la respuesta.\n');
              }
              const suggestedIgnore = suggestion?.trim().toUpperCase() === 'IGNORAR';
              const typed = await question(suggestedIgnore ? 'IGNORAR descarta sin responder; escribe una respuesta para reemplazarlo; Enter o "-" pospone: ' : suggestion ? 'Enter usa el borrador sugerido; escribe otro texto para reemplazarlo; "-" pospone; IGNORAR descarta sin responder: ' : 'Borrador (una línea, máximo 2000; vacío pospone; IGNORAR descarta sin responder): ', approvalSignal);
              if (typed === null || typed.trim() === '-') return { action: 'defer' };
              if (typed.trim().toUpperCase() === 'IGNORAR') { eventId = memoryDb.registrarEvento({ canal: job.channel, habilidad: classifySkill(job.message), accionPropuesta: suggestion ?? '', decision: 'IGNORAR', textoFinal: '', contacto: job.phone }); return { action: 'dismiss' }; }
              const reply = typed.trim() ? typed : (suggestedIgnore ? null : stripOperatorLines(suggestion));
              if (!reply?.trim() || reply.length > 2000) return { action: 'defer' };
              stdout.write(`Vista previa para ENVIO: ${display(reply)}\nAcción propuesta: ${display(JSON.stringify(proposedAction ?? buildAction(job.message)))}; riesgo: ${proposedAction?.riesgo ?? 'bajo'}.\nENVIO: solo respuesta. EJECUTAR requiere confirmar humanamente el comando propuesto.\n`);
              const confirm = await question('Escriba ENVIO o EJECUTAR; EJECUTAR: <comando> permite corregirlo. Otra respuesta pospone: ', approvalSignal);
              if (testMode && (confirm === 'ENVIO' || /^EJECUTAR/.test(confirm ?? ''))) { stdout.write('MODO PRUEBA: envío bloqueado; nada se envía y el mensaje vuelve a la cola.\n'); return { action: 'defer' }; }
              if (confirm === 'ENVIO') { const skill = classifySkill(`${job.message} ${reply}`); eventId = memoryDb.registrarEvento({ canal: job.channel, habilidad: skill, accionPropuesta: suggestion ?? '', decision: suggestion && reply !== suggestion ? 'CORREGIDO' : 'ENVIO', textoFinal: reply, casoEval: { mensaje: job.message, sugerido: suggestion ?? '', final: reply }, contacto: job.phone }); if (suggestion && reply !== suggestion) memoryDb.proponerRegla({ habilidad: skill, texto: await proposeCorrectionRule({ skill, message: job.message, suggested: suggestion, reply }), origenEvento: eventId }); await recordLearning({ message: job.message, suggested: suggestion ?? '', reply, memoryDb }); await memoryDb.guardarResumen(job.phone, `${job.message} → ${reply}`); return { action: 'send', reply }; }
              if (confirm === 'EJECUTAR') {
                if (!proposedAction?.comando || proposedAction.faltan.length) { stdout.write(`No se ejecuta: faltan ${proposedAction?.faltan?.join(', ') || 'datos de contexto'}; el borrador debe pedirlos.\n`); return { action: 'defer' }; }
                if (proposedAction.riesgo === 'alto' && await question('Acción de riesgo alto. Confirme con SI: ', approvalSignal) !== 'SI') return { action: 'defer' };
                eventId = memoryDb.registrarEvento({ canal: job.channel, habilidad: classifySkill(`${job.message} ${proposedAction.comando}`), accionPropuesta: proposedAction.comando, decision: 'EJECUTAR', textoFinal: reply, contacto: job.phone });
                await recordLearning({ message: job.message, suggested: suggestion ?? '', reply, memoryDb });
                await memoryDb.guardarResumen(job.phone, `${job.message} → ${reply}`);
                return { action: 'execute', reply, command: proposedAction.comando };
              }
              const operatorCommand = /^EJECUTAR:\s*(.+)$/.exec(confirm ?? '');
              if (operatorCommand) {
                stdout.write(`Se ejecutará sobre la cuenta del contacto: ${display(operatorCommand[1])}\n`);
                const sure = await question('Confirme con SI: ', approvalSignal);
                if (sure === 'SI' && (!proposedAction?.comando || operatorCommand[1] === proposedAction.comando)) { eventId = memoryDb.registrarEvento({ canal: job.channel, habilidad: classifySkill(`${job.message} ${operatorCommand[1]}`), accionPropuesta: operatorCommand[1], decision: 'EJECUTAR', textoFinal: reply, contacto: job.phone }); await recordLearning({ message: job.message, suggested: suggestion ?? '', reply, memoryDb }); await memoryDb.guardarResumen(job.phone, `${job.message} → ${reply}`); return { action: 'execute', reply, command: operatorCommand[1] }; }
              }
              return { action: 'defer' };
            },
          });
          if (inboxMode) {
            await inbox.resolve(job.wamid, inboxPending, inboxDecision, result.status);
            if (inboxDecision && inboxPending) {
              const action = inboxDecision.accion;
              const finalText = inboxDecision.texto ?? inboxPending.borradorSugerido ?? '';
              const decision = action === 'IGNORAR' ? 'IGNORAR' : action === 'EJECUTAR' ? 'EJECUTAR' : action === 'ENVIO' ? (inboxDecision.texto && inboxDecision.texto !== inboxPending.borradorSugerido ? 'CORREGIDO' : 'ENVIO') : result.status === 'lease-lost' ? 'VENCIDO' : null;
            if (decision) {
                const skill = classifySkill(`${job.message} ${finalText}`);
                const id = memoryDb.registrarEvento({ canal: inboxPending.canal, habilidad: skill, accionPropuesta: inboxPending.accionPropuesta?.comando ?? inboxPending.accionPropuesta?.habilidad ?? '', decision, textoFinal: finalText, casoEval: { mensaje: job.message, sugerido: inboxPending.borradorSugerido, final: finalText }, contacto: job.phone });
                if (decision === 'CORREGIDO') memoryDb.proponerRegla({ habilidad: skill, texto: await proposeCorrectionRule({ skill, message: job.message, suggested: inboxPending.borradorSugerido, reply: finalText }), origenEvento: id });
                if (result.status === 'completed') memoryDb.actualizarResultadoEvento(id, decision === 'EJECUTAR' ? 'ejecutado' : 'entregado');
                else if (decision === 'EJECUTAR') {
                  memoryDb.actualizarResultadoEvento(id, 'fallo');
                  memoryDb.proponerRegla({ habilidad: skill, texto: `Comando rechazado por servidor: volver a pedir contexto y verificar campos antes de proponer ${inboxPending.accionPropuesta?.habilidad ?? 'la acción'}.`, origenEvento: id });
                }
              }
            }
            if (result.status === 'completed' && inboxPending && ['ENVIO', 'EJECUTAR'].includes(inboxDecision?.accion) && !(inboxDecision.accion === 'ENVIO' && inboxPending.tipoSugerencia === 'descartar' && inboxDecision.texto === undefined)) {
              const reply = inboxDecision.texto ?? inboxPending.borradorSugerido;
              await memoryDb.guardarResumen(job.phone, `${job.message} → ${reply}`);
            }
          }
          if (!inboxMode && eventId && ['ENVIO','CORREGIDO','EJECUTAR'].includes(memoryDb.evento(eventId)?.decision)) {
            if (result.status === 'completed') memoryDb.actualizarResultadoEvento(eventId, memoryDb.evento(eventId)?.decision === 'EJECUTAR' ? 'ejecutado' : 'entregado');
            else if (memoryDb.evento(eventId)?.decision === 'EJECUTAR') {
              memoryDb.actualizarResultadoEvento(eventId, 'fallo');
              memoryDb.proponerRegla({ habilidad: classifySkill(job.message), texto: 'Si el servidor rechaza un comando propuesto, verificar el contexto y volver a pedir los campos requeridos antes de repetirlo.', origenEvento: eventId });
            }
          }
          stdout.write(`Resultado: ${result.status === 'completed' ? 'aceptado por servidor; entrega según canal' : result.status === 'dismissed' ? 'descartado sin responder' : result.status}.\n`);
        } catch (e) {
          stdout.write(`Operación no confirmada (${e.code || 'LOCAL_ERROR'}); consulte estado en plataforma.\n`);
          if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(e.code)) throw e;
        }
      };
      if (inboxMode) {
        for (let offset = 0; offset < jobs.length && !stopping; offset += 10) {
          await Promise.all(jobs.slice(offset, offset + 10).map(job => processJob(job)));
        }
      } else {
        for (const job of jobs) { if (stopping) break; await processJob(job); }
      }
      for (const task of batch.tasks) {
        try { await processTask({ client, task, env: process.env }); stdout.write(`Tarea ${task.type}: procesada.\n`); }
        catch (error) { stdout.write(`Tarea no completada (${error.code || 'LOCAL_ERROR'}).\n`); if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(error.code)) throw error; }
      }
      if (!stopping) await wait();
    }
  } finally { if (readinessTimer) clearInterval(readinessTimer); rl?.close(); memoryDb.cerrar(); process.removeListener('SIGTERM', stop); }
}
main().catch(e => {
  process.stderr.write(`Agente detenido: ${e instanceof AgentError ? e.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
