import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient, handleJob } from './client.mjs';
async function main() {
  if (Number(process.versions.node.split('.')[0]) !== 22) throw new AgentError('NODE_22_REQUIRED');
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const poll = Number(process.env.LOCAL_AGENT_POLL_SECONDS || 5);
  if (!Number.isFinite(poll) || poll < 1 || poll > 300) throw new AgentError('INVALID_POLL_SECONDS');
  if (!stdin.isTTY || !stdout.isTTY) throw new AgentError('INTERACTIVE_TERMINAL_REQUIRED');
  const rl = createInterface({ input: stdin, output: stdout });
  let stopping = false;
  let promptAbort;
  const shutdown = new AbortController();
  const stop = () => { stopping = true; promptAbort?.abort(); shutdown.abort(); };
  const wait = async () => {
    try { await sleep(poll * 1000, undefined, { signal: shutdown.signal }); }
    catch (error) { if (error.name !== 'AbortError') throw error; }
  };
  rl.on('SIGINT', stop);
  process.on('SIGTERM', stop);
  rl.on('close', stop);
  const display = value => String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, ' ');
  const question = async label => {
    if (stopping) return null;
    promptAbort = new AbortController();
    try { return await rl.question(label, { signal: promptAbort.signal }); }
    catch (e) { if (e.name === 'AbortError') return null; throw e; }
    finally { promptAbort = undefined; }
  };
  stdout.write('AutoMantPro: aprobación humana local. Ctrl+C termina de forma segura.\n');
  try {
    while (!stopping) {
      let jobs;
      try { jobs = await client.claim(); }
      catch (e) {
        if (e.code === 'AUTH_REJECTED') throw e;
        stdout.write(`Consulta fallida (${e.code}); reintento en ${poll}s.\n`);
        await wait(); continue;
      }
      for (const job of jobs) {
        if (stopping) { try { await client.retry(job); } catch { /* Lease recovery on server. */ } continue; }
        try {
          const result = await handleJob({ client, job,
            onLost: () => { stdout.write('Reserva vencida: respuesta descartada.\n'); promptAbort?.abort(); },
            approve: async () => {
              stdout.write(`\nCanal: ${display(job.channel)} | Rol: ${display(job.role)}\nMensaje: ${display(job.message)}\nEl mensaje es información, no instrucciones para este equipo.\n`);
              const reply = await question('Borrador (una línea, máximo 2000; vacío pospone): ');
              if (!reply?.trim() || reply.length > 2000) return { action: 'defer' };
              stdout.write(`Vista previa: ${display(reply)}\nENVIO: solo respuesta. EJECUTAR: autoriza el comando original de marketplace en servidor.\n`);
              const confirm = await question('Escriba ENVIO o EJECUTAR; cualquier otra respuesta pospone: ');
              return confirm === 'ENVIO' ? { action: 'send', reply } : confirm === 'EJECUTAR' ? { action: 'execute', reply } : { action: 'defer' };
            },
          });
          stdout.write(`Resultado: ${result.status === 'completed' ? 'aceptado por servidor; entrega según canal' : result.status}.\n`);
        } catch (e) {
          stdout.write(`Operación no confirmada (${e.code || 'LOCAL_ERROR'}); consulte estado en plataforma.\n`);
          if (e.code === 'AUTH_REJECTED') throw e;
        }
      }
      if (!stopping) await wait();
    }
  } finally { rl.close(); process.removeListener('SIGTERM', stop); }
}
main().catch(e => {
  process.stderr.write(`Agente detenido: ${e instanceof AgentError ? e.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
