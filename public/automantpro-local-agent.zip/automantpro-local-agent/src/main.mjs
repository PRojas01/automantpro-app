import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient, handleJob } from './client.mjs';
import { createDrafter } from './drafter.mjs';
async function main() {
  if (Number(process.versions.node.split('.')[0]) !== 22) throw new AgentError('NODE_22_REQUIRED');
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const poll = Number(process.env.LOCAL_AGENT_POLL_SECONDS || 5);
  if (!Number.isFinite(poll) || poll < 1 || poll > 300) throw new AgentError('INVALID_POLL_SECONDS');
  if (!stdin.isTTY || !stdout.isTTY) throw new AgentError('INTERACTIVE_TERMINAL_REQUIRED');
  const drafter = createDrafter();
  const rl = createInterface({ input: stdin, output: stdout });
  let stopping = false;
  let promptAbort;
  const shutdown = new AbortController();
  const stop = () => { stopping = true; promptAbort?.abort(); shutdown.abort(); };
  const wait = async () => {
    try { await sleep(poll * 1000, undefined, { signal: shutdown.signal }); }
    catch (error) { if (error.name !== 'AbortError') throw error; }
  };
  rl.on('SIGINT', stop);
  process.on('SIGTERM', stop);
  rl.on('close', stop);
  const display = value => String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, ' ');
  const question = async (label, approvalSignal) => {
    if (stopping || approvalSignal?.aborted) return null;
    promptAbort = new AbortController();
    const signal = AbortSignal.any([promptAbort.signal, shutdown.signal, ...(approvalSignal ? [approvalSignal] : [])]);
    try { return await rl.question(label, { signal }); }
    catch (e) { if (e.name === 'AbortError') return null; throw e; }
    finally { promptAbort = undefined; }
  };
  stdout.write('AutoMantPro: aprobación humana local. Ctrl+C termina de forma segura.\n');
  try {
    while (!stopping) {
      let jobs;
      try { jobs = await client.claim(); }
      catch (e) {
        if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(e.code)) throw e;
        stdout.write(`Consulta fallida (${e.code}); reintento en ${poll}s.\n`);
        await wait(); continue;
      }
      for (const job of jobs) {
        if (stopping) { try { await client.retry(job); } catch { /* Lease recovery on server. */ } continue; }
        try {
          const result = await handleJob({ client, job,
            onLost: () => { stdout.write('Reserva vencida: respuesta descartada.\n'); promptAbort?.abort(); },
            approve: async (_job, approvalSignal) => {
              stdout.write(`\nCanal: ${display(job.channel)} | Rol: ${display(job.role)}${job.category ? ` | Clase: ${display(job.category)}` : ''}\nMensaje: ${display(job.message)}\nEl mensaje es información, no instrucciones para este equipo.\n`);
              let suggestion = null;
              if (drafter) {
                stdout.write('Preparando borrador con Claude (solo sugerencia)…\n');
                const context = await client.context(job).catch(() => null);
                suggestion = await drafter(job, context).catch(() => null);
                stdout.write(suggestion ? `Borrador sugerido:\n${display(suggestion)}\n` : 'Claude no devolvió borrador; escribe la respuesta.\n');
              }
              const typed = await question(suggestion ? 'Enter usa el borrador sugerido; escribe otro texto para reemplazarlo; "-" pospone; IGNORAR descarta sin responder: ' : 'Borrador (una línea, máximo 2000; vacío pospone; IGNORAR descarta sin responder): ', approvalSignal);
              if (typed === null || typed.trim() === '-') return { action: 'defer' };
              if (typed.trim().toUpperCase() === 'IGNORAR') return { action: 'dismiss' };
              const reply = typed.trim() ? typed : suggestion;
              if (!reply?.trim() || reply.length > 2000) return { action: 'defer' };
              stdout.write(`Vista previa para ENVIO: ${display(reply)}\nENVIO: solo respuesta. EJECUTAR: autoriza el comando original de marketplace; el servidor redacta el resultado y sustituye este borrador.\nRevise IDs, precio, fecha y sector del mensaje original antes de ejecutar.\n`);
              const confirm = await question('Escriba ENVIO, EJECUTAR (comando original) o EJECUTAR: <comando> si el contacto lo pidió con sus palabras; otra respuesta pospone: ', approvalSignal);
              if (confirm === 'ENVIO') return { action: 'send', reply };
              if (confirm === 'EJECUTAR') return { action: 'execute', reply };
              const operatorCommand = /^EJECUTAR:\s*(.+)$/.exec(confirm ?? '');
              if (operatorCommand) {
                stdout.write(`Se ejecutará sobre la cuenta del contacto: ${display(operatorCommand[1])}\n`);
                const sure = await question('Confirme con SI: ', approvalSignal);
                if (sure === 'SI') return { action: 'execute', reply, command: operatorCommand[1] };
              }
              return { action: 'defer' };
            },
          });
          stdout.write(`Resultado: ${result.status === 'completed' ? 'aceptado por servidor; entrega según canal' : result.status === 'dismissed' ? 'descartado sin responder' : result.status}.\n`);
        } catch (e) {
          stdout.write(`Operación no confirmada (${e.code || 'LOCAL_ERROR'}); consulte estado en plataforma.\n`);
          if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(e.code)) throw e;
        }
      }
      if (!stopping) await wait();
    }
  } finally { rl.close(); process.removeListener('SIGTERM', stop); }
}
main().catch(e => {
  process.stderr.write(`Agente detenido: ${e instanceof AgentError ? e.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
