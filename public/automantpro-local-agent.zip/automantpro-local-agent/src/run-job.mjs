import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { AgentError, createClient } from './client.mjs';
import { JOB_TYPES, runJob } from './jobs.mjs';

async function main() {
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const type = process.argv[2];
  const allowed = ['correr_pruebas', 'tomar_capturas', 'revisar_diff', 'reporte_estado'];
  if (process.argv.length !== 3 || !JOB_TYPES.includes(type) || !allowed.includes(type)) throw new AgentError('JOB_TYPE_NOT_ALLOWED');
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const result = await runJob({ type }, { client, env: process.env });
  process.stdout.write(`${JSON.stringify(result)}\n`);
}
main().catch(error => {
  process.stderr.write(`${error instanceof AgentError ? error.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
