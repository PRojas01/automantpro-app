import { mkdir, readdir, readFile, stat, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { basename, join, resolve } from 'node:path';
import { stdout } from 'node:process';
import { AgentError } from './client.mjs';
import { classifyBusinessLead, classifyWithLocalModel, masked } from './bridge-core.mjs';

/**
 * Reads chats exported from the phone (WhatsApp → Exportar chat → Sin archivos, .txt files) in the
 * private folder "exportados", classifies them on this computer (local model, rules as fallback)
 * and merges them into the private review list. With --resolver-numeros it looks up, in WhatsApp
 * Web, the phone of chats exported under a contact name. Nothing leaves this computer.
 */
const require = createRequire(import.meta.url);

/** "Chat de WhatsApp con Taller X.txt" → "Taller X". */
export function titleFromFile(file) {
  return basename(file).replace(/\.txt$/i, '').replace(/^(chat de whatsapp con|whatsapp chat with|conversa do whatsapp com)\s+/i, '').trim();
}

/** Android "21/10/25, 14:05 - Nombre: texto" and iOS "[21/10/25, 14:05:33] Nombre: texto". */
export function parseExport(text, title) {
  const line = /^\[?(\d{1,2}\/\d{1,2}\/\d{2,4}),? (\d{1,2}:\d{2}(?::\d{2})?(?:\s?[ap]\.?\s?m\.?)?)\]?\s(?:-\s)?([^:]{1,60}): (.*)$/i;
  const messages = [];
  for (const raw of String(text).split(/\r?\n/)) {
    const m = line.exec(raw.replace(/[‎‏]/g, ''));
    if (m) messages.push({ date: m[1], sender: m[3].trim(), text: m[4], fromMe: null });
    else if (messages.length && raw.trim()) messages.at(-1).text += `\n${raw}`;
  }
  // The contact is the sender named like the chat; anyone else in a one-to-one chat is the owner.
  const norm = s => s.replace(/\s+/g, ' ').trim().toLowerCase();
  const digits = s => s.replace(/\D/g, '');
  for (const m of messages) m.fromMe = !(norm(m.sender) === norm(title) || (digits(title).length >= 8 && digits(m.sender) === digits(title)));
  return messages.filter(m => !/^<(multimedia omitido|media omitted)>$/i.test(m.text.trim()));
}

async function main() {
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const folder = resolve('exportados');
  const files = (await readdir(folder).catch(() => [])).filter(f => /\.txt$/i.test(f));
  if (!files.length) { stdout.write('No hay archivos .txt en exportados/. Exporta los chats desde el teléfono (Sin archivos) y cópialos ahí.\n'); return; }
  const reviewPath = resolve('revision-historial.json');
  const review = JSON.parse(await readFile(reviewPath, 'utf8').catch(() => '{"chats":[]}'));
  const chats = Array.isArray(review.chats) ? review.chats : [];
  const key = c => c.phone || `nombre:${c.title}`;
  const byKey = new Map(chats.map(c => [key(c), c]));
  for (const file of files) {
    const title = titleFromFile(file);
    const messages = parseExport(await readFile(join(folder, file), 'utf8'), title);
    if (!messages.length) { stdout.write(`  ${file}: sin mensajes legibles\n`); continue; }
    const phone = /^\+?[\d\s()-]{8,24}$/.test(title) ? title.replace(/\D/g, '') : null;
    const lead = (await classifyWithLocalModel(messages)) ?? classifyBusinessLead(messages);
    const entry = { phone, title: title.slice(0, 80), ...lead, lastMessage: messages.at(-1)?.date ?? '', keyword: 'exportado' };
    byKey.set(key(entry), { ...(byKey.get(key(entry)) ?? {}), ...entry });
    stdout.write(`  ${phone ? masked(phone) : 'contacto con nombre'}: ${lead.category}${lead.automantpro ? ' · AutoMantPro' : ''}\n`);
  }
  let list = [...byKey.values()];
  if (process.argv.includes('--resolver-numeros') && list.some(c => !c.phone)) list = await resolvePhones(list);
  list.sort((a, b) => Number(b.automantpro) - Number(a.automantpro) || String(a.category).localeCompare(String(b.category)));
  await writeFile(reviewPath, JSON.stringify({ generatedAt: new Date().toISOString(), chats: list }, null, 2), { mode: 0o600 });
  const md = ['# Revisión del historial de WhatsApp (privado, solo en este equipo)', '', 'Marca con una x los chats a importar como contactos "sin consentimiento". Los que no tienen teléfono se completan con: node src/whatsapp-export-scan.mjs --resolver-numeros', '', '| Importar | Teléfono | Nombre del chat | Clase | Motivo | Último mensaje |', '|---|---|---|---|---|---|',
    ...list.map(c => `| ${c.automantpro && c.phone ? '[x]' : '[ ]'} | ${c.phone ?? '(falta)'} | ${String(c.title).replace(/\|/g, ' ')} | ${c.category} | ${(c.reasons ?? []).join('; ').replace(/\|/g, ' ')} | ${c.lastMessage ?? ''} |`)].join('\n');
  await writeFile(resolve('revision-historial.md'), `${md}\n`, { mode: 0o600 });
  const summary = list.reduce((acc, c) => ({ ...acc, [c.category]: (acc[c.category] ?? 0) + 1 }), {});
  stdout.write(`Listo: ${list.length} chats en la lista (${list.filter(c => !c.phone).length} sin teléfono). ${JSON.stringify(summary)}\n`);
}

/** Looks up the phone of named contacts in WhatsApp Web (stop the bridge first). */
async function resolvePhones(list) {
  const dataDir = resolve(process.env.WHATSAPP_DATA_DIR || 'data');
  process.env.HUMAN_DIR = join(dataDir, 'human');
  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  const { chromium } = require('playwright-core');
  const { resolver } = require('./vendor/pymeagents/browser/actions/whatsapp-selectors.cjs');
  const wa = require('./vendor/pymeagents/browser/actions/whatsapp.cjs');
  const context = await chromium.launchPersistentContext(resolve(process.env.WHATSAPP_PROFILE_DIR || join(dataDir, 'whatsapp-profile')), { executablePath: process.env.WHATSAPP_BROWSER_PATH || '/usr/bin/google-chrome', headless: false, chromiumSandbox: true, viewport: { width: 1280, height: 860 }, locale: 'es-EC' });
  const page = context.pages()[0] ?? await context.newPage();
  const pause = (min, max) => page.waitForTimeout(min + Math.floor(Math.random() * (max - min)));
  try {
    await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
    if (!(await wa.waitForAuth(page, 90_000))) throw new AgentError('WHATSAPP_NOT_LINKED');
    for (const chat of list.filter(c => !c.phone)) {
      try {
        const box = await resolver(page, 'buscador', { timeoutMs: 8000 });
        if (!box) { await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' }); await wa.waitForAuth(page, 90_000); continue; }
        await box.locator.click(); await page.keyboard.press('Control+A'); await page.keyboard.press('Backspace');
        await page.keyboard.type(chat.title, { delay: 80 }); await pause(2500, 3500);
        const row = page.locator(`#pane-side span[title="${chat.title.replace(/"/g, '\\"')}"]`).first();
        if (!(await row.count())) { await page.keyboard.press('Escape'); continue; }
        await row.click(); await pause(1500, 2500);
        await page.locator('#main header').first().click(); await pause(1500, 2500);
        const phones = await page.evaluate(() => [...document.querySelectorAll('span, div')].filter(e => e.childElementCount === 0).map(e => (e.textContent || '').trim()).filter(t => /^\+\d[\d\s()-]{7,20}$/.test(t)));
        await page.keyboard.press('Escape'); await pause(800, 1500);
        const phone = (phones.at(-1) ?? '').replace(/\D/g, '');
        if (/^\d{8,15}$/.test(phone)) { chat.phone = phone; stdout.write(`  ${masked(phone)}: número encontrado\n`); }
      } catch { /* next */ }
    }
  } finally { await context.close().catch(() => {}); }
  return list;
}

if (import.meta.url === `file://${process.argv[1]}`) main().catch(e => { process.stderr.write(`Lectura detenida: ${e instanceof AgentError ? e.code : e?.message ?? 'ERROR'}\n`); process.exitCode = 1; });
