import { appendFile, mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { stdout } from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient } from './client.mjs';
import { FORWARDED_CATEGORIES, chatGate, dropBlankOrDeleted, isReplyToService, fromFirstMention, classifyChat, hasPriorChat, classifyWithLocalModel, masked, pacingDelaySeconds, parseAllowlist, pendingIncoming, phoneFromTitle } from './bridge-core.mjs';
import { contactCommand, createContactsStore } from './contacts-store.mjs';
import { recordOrigin } from './approval-inbox.mjs';
import { createMemoryDb } from './memory-db.mjs';

/**
 * WhatsApp Web bridge for the AutoMantPro pilot.
 *
 * Inbound: detects chats that changed, reads what the contact wrote after our last message and
 * hands it to the server queue, where a person approves every reply in the operator terminal.
 * Outbound: delivers only what the server's outbox authorizes (approved replies, marketplace
 * notices to linked users, the fixed welcome), with the human pacing of PYMEAgents.
 * It never starts a conversation on its own and never stores message text on disk.
 */
const require = createRequire(import.meta.url);

async function loadEnv() {
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
}

async function readState(file) {
  try {
    const value = JSON.parse(await readFile(file, 'utf8'));
    const aprobados = Array.isArray(value.aprobados) ? value.aprobados.filter(p => typeof p === 'string' && /^\d{8,15}$/.test(p)).slice(-500) : [];
    return { previas: value.previas && typeof value.previas === 'object' ? value.previas : null, aprobados };
  }
  catch { return { previas: null, aprobados: [] }; }
}
async function writeState(file, state) {
  // Only chat titles and preview hashes; never message text.
  const tmp = `${file}.tmp`;
  await writeFile(tmp, JSON.stringify(state), { mode: 0o600 });
  await rename(tmp, file);
}

async function main() {
  if (Number(process.versions.node.split('.')[0]) !== 22) throw new AgentError('NODE_22_REQUIRED');
  await loadEnv();
  const dataDir = resolve(process.env.WHATSAPP_DATA_DIR || 'data');
  await mkdir(join(dataDir, 'human'), { recursive: true, mode: 0o700 });
  // Pacing and consent files live with this agent, never shared with other WhatsApp tools.
  process.env.HUMAN_DIR = join(dataDir, 'human');
  const wa = require('./vendor/pymeagents/browser/actions/whatsapp.cjs');
  const { exigir } = require('./vendor/pymeagents/browser/actions/whatsapp-selectors.cjs');
  const { escribirComoHumano } = require('./vendor/pymeagents/human/typing.cjs');
  const { calentar } = require('./vendor/pymeagents/human/warmup.cjs');
  const pacing = require('./vendor/pymeagents/human/pacing.cjs');
  const consent = require('./vendor/pymeagents/human/consent.cjs');
  let chromium;
  try { ({ chromium } = require('playwright-core')); } catch { throw new AgentError('PLAYWRIGHT_CORE_REQUIRED'); }

  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const poll = Number(process.env.WHATSAPP_POLL_SECONDS || 20);
  if (!Number.isFinite(poll) || poll < 10 || poll > 600) throw new AgentError('INVALID_POLL_SECONDS');
  const executablePath = process.env.WHATSAPP_BROWSER_PATH || '/usr/bin/google-chrome';
  const profileDir = resolve(process.env.WHATSAPP_PROFILE_DIR || join(dataDir, 'whatsapp-profile'));
  await mkdir(profileDir, { recursive: true, mode: 0o700 });
  const stateFile = join(dataDir, 'bridge-state.json');
  const contacts = createContactsStore(dataDir);
  const memoryDb = await createMemoryDb({ dataDir });

  const context = await chromium.launchPersistentContext(profileDir, { executablePath, headless: false, chromiumSandbox: true, viewport: { width: 1280, height: 860 }, locale: 'es-EC' });
  const page = context.pages()[0] ?? await context.newPage();
  let stopping = false;
  const shutdown = new AbortController();
  const stop = () => { stopping = true; shutdown.abort(); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
  const wait = async seconds => { try { await sleep(seconds * 1000, undefined, { signal: shutdown.signal }); } catch (e) { if (e.name !== 'AbortError') throw e; } };
  const log = text => stdout.write(`[${new Date().toLocaleTimeString('es-EC')}] ${text}\n`);

  await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
  log('WhatsApp Web abierto. Si aparece el código QR, escanéalo con el teléfono del número del piloto.');
  while (!stopping && !(await wa.waitForAuth(page, 60_000))) log('Esperando la sesión de WhatsApp Web (código QR)…');

  async function openByPhone(phone) {
    await page.goto(`https://web.whatsapp.com/send?phone=${phone}`, { waitUntil: 'domcontentloaded' });
    if (!(await wa.waitForAuth(page))) return null;
    try { return (await exigir(page, 'cajaMensaje', { timeoutMs: 25_000 })).locator; } catch { return null; }
  }
  let lastDiag = '';
  async function contactPhoneFromInfo() {
    const diag = [];
    // 1. Message ids in the open chat carry the contact's id (593...@c.us); no extra clicks needed.
    try {
      const ids = await page.locator('#main [data-id]').evaluateAll(els => els.slice(-30).map(e => e.getAttribute('data-id') || ''));
      for (const id of ids) {
        const m = /(?:^|_)(\d{8,15})@(?:c\.us|s\.whatsapp\.net)/.exec(id);
        if (m) return m[1];
      }
      // Only the id kind goes to the log (lid, g.us...), never the id itself.
      const kinds = [...new Set(ids.map(id => (/@([a-z.]+)/.exec(id) || [])[1]).filter(Boolean))];
      // Shape only (letters "a", digits "9") so the id format can be fixed without storing it.
      const idShape = (ids.at(-1) || '').replace(/\p{L}/gu, 'a').replace(/\d/g, '9').slice(0, 80);
      diag.push(`ids=${ids.length}${kinds.length ? ' ' + kinds.join('/') : ''}`, `forma=${idShape}`);
    } catch { diag.push('ids=error'); }
    // 2. Contact info drawer: only text outside the chat and the chat list, and only "+country" numbers.
    try {
      // Click the avatar or the contact title, never the header itself (Business puts the labels menu there).
      const target = page.locator('#main header img, #main header span[dir="auto"][title], #main header div[title]').first();
      if (await target.count()) await target.click(); else await page.locator('#main header span[dir="auto"]').first().click();
      const found = await page.waitForFunction(() => {
        const main = document.querySelector('#main');
        const side = document.querySelector('#side');
        for (const e of document.querySelectorAll('span, div')) {
          if (e.childElementCount || main?.contains(e) || side?.contains(e)) continue;
          const t = (e.textContent || '').trim();
          if (/^\+\d[\d\s().-]{7,20}\d$/.test(t)) return t;
        }
        return null;
      }, null, { timeout: 5000, polling: 400 }).then(h => h.jsonValue()).catch(() => null);
      await page.waitForTimeout(400 + Math.floor(Math.random() * 500));
      if (found) { await page.keyboard.press('Escape').catch(() => {}); return phoneFromTitle(found); }
      diag.push('ficha=sin número visible');
      // Structure-only snapshot to fix selectors: letters become "a" and digits "9", so no name or number is stored.
      const shape = await page.evaluate(() => {
        const mask = t => String(t || '').replace(/\p{L}/gu, 'a').replace(/\d/g, '9').slice(0, 60);
        const main = document.querySelector('#main');
        const side = document.querySelector('#side');
        const out = [];
        for (const e of document.querySelectorAll('span, div, a, button')) {
          if (e.childElementCount || main?.contains(e) || side?.contains(e)) continue;
          const t = (e.textContent || '').trim();
          if (!t) continue;
          out.push({ tag: e.tagName, testid: e.closest('[data-testid]')?.getAttribute('data-testid') || null, dir: e.getAttribute('dir'), texto: mask(t) });
          if (out.length >= 150) break;
        }
        return out;
      }).catch(() => []);
      await writeFile(join(dataDir, 'diag-ficha.json'), JSON.stringify({ fecha: new Date().toISOString(), diag, shape }, null, 1), { mode: 0o600 }).catch(() => {});
      await page.keyboard.press('Escape').catch(() => {});
    } catch { diag.push('ficha=no abrió'); }
    lastDiag = diag.join(', ');
    return null;
  }
  // Chats whose number could not be read are not reopened for 30 minutes (anti-ban: no repeated opening).
  const unresolved = new Map();
  const coolingDown = contacto => (unresolved.get(contacto) || 0) > Date.now();
  const markUnresolved = contacto => unresolved.set(contacto, Date.now() + 30 * 60_000);
  async function deliver(message) {
    // Reply-only: never start a conversation. Without a prior chat the message waits for human review.
    if (!hasPriorChat(message.phone, state.aprobados)) return { ok: false, code: 'NO_PRIOR_CHAT', delay: 3600 };
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Guayaquil', hour: '2-digit', hourCycle: 'h23' }).format(new Date()));
    if (!message.allowedOutsideHours && (hour < 8 || hour >= 21)) return { ok: false, code: 'OUTSIDE_HOURS', delay: 300 };
    const permit = pacing.puedeEnviar({ plataforma: 'whatsapp', mensaje: message.message });
    if (!permit.permitido) return { ok: false, code: 'PACING', delay: pacingDelaySeconds(permit.esperarMs) };
    const box = await openByPhone(message.phone);
    if (!box) return { ok: false, code: 'CHAT_NOT_AVAILABLE', delay: 600 };
    await contacts.add({ digits: message.phone, origen: 'servidor' });
    await calentar(page, 'whatsapp');
    // The server authorized this recipient (linked account or a contact who wrote first).
    consent.registrarSolicitud({ plataforma: 'whatsapp', contacto: message.phone, origen: 'manual', nota: 'autorizado por el servidor de AutoMantPro' });
    const parts = String(message.message).split(/\n{2,}/).map(p => p.trim()).filter(Boolean);
    for (let i = 0; i < parts.length; i++) {
      await escribirComoHumano(box, parts[i], { plataforma: 'whatsapp', saltarLectura: i > 0 });
      await page.waitForTimeout(400 + Math.floor(Math.random() * 700));
      await box.press('Enter');
      if (i < parts.length - 1) await page.waitForTimeout(1200 + Math.floor(Math.random() * 1600));
    }
    pacing.registrarEnvio({ plataforma: 'whatsapp', contacto: message.phone, mensaje: message.message });
    await page.waitForTimeout(1500);
    return { ok: true };
  }

  const state = await readState(stateFile);
  const skipped = new Set();
  let firstSweep = true;
  // Anti-ban: a chat is reopened only when its last line changed, and never more than once a minute.
  const lastOpened = new Map();
  while (!stopping) {
    try {
      if (!(await wa.waitForAuth(page, 15_000))) { log('Sesión de WhatsApp Web no disponible; esperando.'); await wait(poll * (0.8 + Math.random() * 0.6)); continue; }
      // 1. Inbound.
      const seen = await wa.revisarEntrantes(page, { limit: 30, registrar: false, memoria: { previas: state.previas } });
      if (seen.ok) {
        const allowlistText = await Promise.all([readFile(join(dataDir, 'permitidos.txt'), 'utf8').catch(() => ''), readFile(resolve('permitidos.txt'), 'utf8').catch(() => '')]);
        const allowlist = parseAllowlist(allowlistText.join('\n'));
        const allowedNames = [];
        for (const name of allowlist) if (!phoneFromTitle(name)) allowedNames.push(name);
        const manuallyAllowedPhones = allowlist.map(phoneFromTitle).filter(Boolean);
        const managedEntries = await contacts.load();
        const knownName = await contacts.nameMatcher().catch(() => () => false);
        const resolvedNames = new Map();
        const pendingScan = await wa.barrerPendientes(page, { maxAbrir: 12, incluirSinCambios: firstSweep, permitir: chat => {
          if (coolingDown(chat.contacto)) return false;
          const n = phoneFromTitle(chat.contacto);
          if (n) {
            if (managedEntries.some(entry => entry.digits === n && entry.baja) && !manuallyAllowedPhones.includes(n)) return false;
            return chatGate({ title: chat.contacto, preview: chat.vistaPrevia, phone: n, allowlist, approved: state.aprobados.filter(p => !managedEntries.some(entry => entry.digits === p && entry.baja)), contactsAllowed: false }).open;
          }
          // The sweep's preview selector can come back empty; fall back to the last preview the inbound scan saw.
          const preview = chat.vistaPrevia || seen.previas?.[chat.contacto] || state.previas?.[chat.contacto] || '';
          return allowedNames.includes(chat.contacto) || knownName(chat.contacto) || /automant|\bamp-[a-z0-9]{4,6}\b/i.test(preview);
        }, resolverNumero: async fila => {
          const n = phoneFromTitle(fila.contacto);
          if (n) return n;
          const resolved = await contactPhoneFromInfo();
          if (resolved) resolvedNames.set(fila.contacto, resolved); else markUnresolved(fila.contacto);
          return resolved;
        } }).catch(e => { log(`Barrido de pendientes falló (${String(e?.message || e).slice(0, 80)}).`); return { ok: false, pendientes: [] }; });
        if (firstSweep && pendingScan.ok) log(`Barrido inicial: ${pendingScan.candidatas ?? 0} chat(s) permitidos, ${pendingScan.abiertas ?? 0} abiertos, ${pendingScan.count ?? 0} sin responder.`);
        firstSweep = false;
        const chats = new Map();
        for (const chat of [...seen.entrantes, ...(pendingScan.pendientes || [])]) chats.set(chat.contacto, chat);
        for (const chat of chats.values()) {
          const titlePhone = phoneFromTitle(chat.contacto);
          let phone = titlePhone || resolvedNames.get(chat.contacto) || chat.numero;
          const manualName = !titlePhone && (allowedNames.includes(chat.contacto) || knownName(chat.contacto));
          const managed = phone ? managedEntries.find(entry => entry.digits === phone) : null;
          if (managed?.baja && !manuallyAllowedPhones.includes(phone)) continue;
          const auto = phone ? await contacts.isAllowed(phone) : false;
          const gate = chatGate({ title: chat.contacto, preview: chat.vistaPrevia || chat.texto || seen.previas?.[chat.contacto] || state.previas?.[chat.contacto] || "", phone, allowlist, approved: auto || manuallyAllowedPhones.includes(phone) ? state.aprobados : [], contactsAllowed: auto });
          if (!gate.open && !manualName) { if (phone && !skipped.has(phone)) { skipped.add(phone); log(`Chat ${masked(phone)} omitido sin abrir: ${gate.reason}.`); } continue; }
          if (!phone && coolingDown(chat.contacto)) continue;
          if (!phone && seen.entrantes.some(c => c.contacto === chat.contacto)) {
            await wa.abrirChat(page, chat.contacto);
            phone = await contactPhoneFromInfo();
          }
          // A saved-name chat whose number we just read: remember its name (as HMAC) so it is recognized next time.
          if (phone && !titlePhone && await contacts.isAllowed(phone)) await contacts.add({ digits: phone, name: chat.contacto, origen: 'mencion' }).catch(() => {});
          if (!phone) { markUnresolved(chat.contacto); log(`Chat con nombre omitido: número no disponible (${lastDiag || 'sin datos'}). Reintento en 30 min.`); continue; }
          const resolvedPhone = phone;
          const currentPreview = chat.vistaPrevia || chat.texto || seen.previas?.[chat.contacto] || '';
          const before = lastOpened.get(chat.contacto);
          if (before && (before.preview === currentPreview || Date.now() - before.at < 60_000)) continue;
          lastOpened.set(chat.contacto, { preview: currentPreview, at: Date.now() });
          const commands = contactCommand(chat.vistaPrevia);
          if (commands === 'baja') { await contacts.update(resolvedPhone, 'baja'); memoryDb.olvidar(resolvedPhone); }
          if (commands === 'alta') await contacts.update(resolvedPhone, 'alta');
          if (commands === 'baja') continue;
          if (!state.aprobados.includes(resolvedPhone)) state.aprobados = [...state.aprobados, resolvedPhone].slice(-500);
          await appendFile(join(dataDir, 'acceso-chats.log'), `${new Date().toISOString()} ABIERTO ${masked(resolvedPhone)} ${gate.reason}\n`, { mode: 0o600 });
          const read = await wa.readRecent(page, { contact: chat.contacto, limit: 12 });
          if (!read.ok) { log(`No se pudo leer el chat ${masked(resolvedPhone)}.`); continue; }
          if (read.messages.some(message => message.fromMe === false && /automant|\bamp-[a-z0-9]{4,6}\b/i.test(message.text || '')) && !await contacts.isAllowed(resolvedPhone)) {
            await contacts.add({ digits: resolvedPhone, name: chat.contacto, origen: 'mencion' });
          }
          const lastCommand = contactCommand(read.messages.at(-1)?.text);
          if (lastCommand) { await contacts.update(resolvedPhone, lastCommand); if (lastCommand === 'baja') { memoryDb.olvidar(resolvedPhone); continue; } }
          await contacts.touch(resolvedPhone);
          // Classified here: personal chats, groups and notifications never leave this computer.
          // Privacy: classify only what the contact wrote after our last reply. An old AutoMantPro mention in the
          // history must not turn later personal messages (links, photos) into service requests.
          let tailStart = read.messages.length;
          while (tailStart > 0 && read.messages[tailStart - 1]?.fromMe === false) tailStart--;
          const tail = read.messages.slice(tailStart);
          // A reply to our own AutoMantPro message ("Acepto, 1", "tengo un taller") continues that conversation.
          const replyingToUs = isReplyToService(read.messages.at(tailStart - 1));
          const rules = replyingToUs ? { category: 'automantpro', reasons: ['responde a nuestro mensaje de AutoMantPro'] } : classifyChat(tail);
          // Explicit commands need no model; otherwise the local model decides and the rules are the fallback.
          const model = replyingToUs || (rules.category === 'automantpro' && /automantpro|registr|ofertar|[sc]-[0-9a-f]{6}/i.test(rules.reasons[0] ?? '')) ? null : await classifyWithLocalModel(tail);
          const category = model ? (model.automantpro ? 'automantpro' : model.category) : rules.category;
          const reasons = model?.reasons ?? rules.reasons;
          const all = process.env.WHATSAPP_FORWARD === 'all';
          if (!all && !FORWARDED_CATEGORIES.has(category)) { log(`Chat ${masked(phone)}: ${category} (${reasons[0]}); no se envía al operador.`); continue; }
          let sent = 0;
          for (const item of dropBlankOrDeleted(fromFirstMention(pendingIncoming(resolvedPhone, read.messages)))) {
            const result = await client.inbound({ id: item.id, phone: resolvedPhone, text: item.text, category });
            await recordOrigin(join(dataDir, 'bandeja'), `wweb:${item.id}`, resolvedPhone).catch(() => {});
            if (!result.duplicate) sent++;
          }
          if (sent) log(`${sent} mensaje(s) de ${masked(resolvedPhone)} (${category}) en cola para aprobación humana.`);
        }
        if (seen.arranqueEnFrio) log('Primera vuelta: se registró la lista de chats sin responder a nadie.');
        state.previas = seen.previas;
        await writeState(stateFile, state);
      }
      // 2. Outbound.
      for (const message of await client.outbox()) {
        if (stopping) { await client.undelivered(message, 'BRIDGE_STOPPING', 60).catch(() => {}); continue; }
        let outcome;
        try { outcome = await deliver(message); } catch { outcome = { ok: false, code: 'BROWSER_ERROR', delay: 300 }; }
        if (outcome.ok) { await client.delivered(message); log(`Enviado a ${masked(message.phone)} (${message.kind}).`); }
        else { await client.undelivered(message, outcome.code, outcome.delay); log(`Sin enviar a ${masked(message.phone)}: ${outcome.code}.`); }
      }
      // Go back to the chat list so the next inbound scan sees every conversation.
      if (!page.url().endsWith('web.whatsapp.com/')) await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
    } catch (e) {
      if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED', 'WHATSAPP_BRIDGE_DISABLED'].includes(e.code)) throw e;
      log(`Vuelta fallida (${e instanceof AgentError ? e.code : 'BROWSER_ERROR'}); reintento.`);
    }
    await wait(poll * (0.8 + Math.random() * 0.6));
  }
  memoryDb.cerrar();
  await context.close().catch(() => {});
}

main().catch(e => {
  process.stderr.write(`Puente detenido: ${e instanceof AgentError ? e.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
