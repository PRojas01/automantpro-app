import { mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { stdout } from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient } from './client.mjs';
import { FORWARDED_CATEGORIES, classifyChat, classifyWithLocalModel, masked, pacingDelaySeconds, pendingIncoming, phoneFromTitle } from './bridge-core.mjs';

/**
 * WhatsApp Web bridge for the AutoMantPro pilot.
 *
 * Inbound: detects chats that changed, reads what the contact wrote after our last message and
 * hands it to the server queue, where a person approves every reply in the operator terminal.
 * Outbound: delivers only what the server's outbox authorizes (approved replies, marketplace
 * notices to linked users, the fixed welcome), with the human pacing of PYMEAgents.
 * It never starts a conversation on its own and never stores message text on disk.
 */
const require = createRequire(import.meta.url);

async function loadEnv() {
  try {
    const info = await stat(resolve('.env'));
    if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
    process.loadEnvFile(resolve('.env'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
}

async function readState(file) {
  try { const value = JSON.parse(await readFile(file, 'utf8')); return { previas: value.previas && typeof value.previas === 'object' ? value.previas : null }; }
  catch { return { previas: null }; }
}
async function writeState(file, state) {
  // Only chat titles and preview hashes; never message text.
  const tmp = `${file}.tmp`;
  await writeFile(tmp, JSON.stringify(state), { mode: 0o600 });
  await rename(tmp, file);
}

async function main() {
  if (Number(process.versions.node.split('.')[0]) !== 22) throw new AgentError('NODE_22_REQUIRED');
  await loadEnv();
  const dataDir = resolve(process.env.WHATSAPP_DATA_DIR || 'data');
  await mkdir(join(dataDir, 'human'), { recursive: true, mode: 0o700 });
  // Pacing and consent files live with this agent, never shared with other WhatsApp tools.
  process.env.HUMAN_DIR = join(dataDir, 'human');
  const wa = require('./vendor/pymeagents/browser/actions/whatsapp.cjs');
  const { exigir } = require('./vendor/pymeagents/browser/actions/whatsapp-selectors.cjs');
  const { escribirComoHumano } = require('./vendor/pymeagents/human/typing.cjs');
  const pacing = require('./vendor/pymeagents/human/pacing.cjs');
  const consent = require('./vendor/pymeagents/human/consent.cjs');
  let chromium;
  try { ({ chromium } = require('playwright-core')); } catch { throw new AgentError('PLAYWRIGHT_CORE_REQUIRED'); }

  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const poll = Number(process.env.WHATSAPP_POLL_SECONDS || 20);
  if (!Number.isFinite(poll) || poll < 10 || poll > 600) throw new AgentError('INVALID_POLL_SECONDS');
  const executablePath = process.env.WHATSAPP_BROWSER_PATH || '/usr/bin/google-chrome';
  const profileDir = resolve(process.env.WHATSAPP_PROFILE_DIR || join(dataDir, 'whatsapp-profile'));
  await mkdir(profileDir, { recursive: true, mode: 0o700 });
  const stateFile = join(dataDir, 'bridge-state.json');

  const context = await chromium.launchPersistentContext(profileDir, { executablePath, headless: false, chromiumSandbox: true, viewport: { width: 1280, height: 860 }, locale: 'es-EC' });
  const page = context.pages()[0] ?? await context.newPage();
  let stopping = false;
  const shutdown = new AbortController();
  const stop = () => { stopping = true; shutdown.abort(); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
  const wait = async seconds => { try { await sleep(seconds * 1000, undefined, { signal: shutdown.signal }); } catch (e) { if (e.name !== 'AbortError') throw e; } };
  const log = text => stdout.write(`[${new Date().toLocaleTimeString('es-EC')}] ${text}\n`);

  await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
  log('WhatsApp Web abierto. Si aparece el código QR, escanéalo con el teléfono del número del piloto.');
  while (!stopping && !(await wa.waitForAuth(page, 60_000))) log('Esperando la sesión de WhatsApp Web (código QR)…');

  async function openByPhone(phone) {
    await page.goto(`https://web.whatsapp.com/send?phone=${phone}`, { waitUntil: 'domcontentloaded' });
    if (!(await wa.waitForAuth(page))) return null;
    try { return (await exigir(page, 'cajaMensaje', { timeoutMs: 25_000 })).locator; } catch { return null; }
  }
  async function deliver(message) {
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Guayaquil', hour: '2-digit', hourCycle: 'h23' }).format(new Date()));
    if (!message.allowedOutsideHours && (hour < 8 || hour >= 21)) return { ok: false, code: 'OUTSIDE_HOURS', delay: 300 };
    const permit = pacing.puedeEnviar({ plataforma: 'whatsapp', mensaje: message.message });
    if (!permit.permitido) return { ok: false, code: 'PACING', delay: pacingDelaySeconds(permit.esperarMs) };
    const box = await openByPhone(message.phone);
    if (!box) return { ok: false, code: 'CHAT_NOT_AVAILABLE', delay: 600 };
    // The server authorized this recipient (linked account or a contact who wrote first).
    consent.registrarSolicitud({ plataforma: 'whatsapp', contacto: message.phone, origen: 'manual', nota: 'autorizado por el servidor de AutoMantPro' });
    const parts = String(message.message).split(/\n{2,}/).map(p => p.trim()).filter(Boolean);
    for (let i = 0; i < parts.length; i++) {
      await escribirComoHumano(box, parts[i], { plataforma: 'whatsapp', saltarLectura: i > 0 });
      await page.waitForTimeout(400 + Math.floor(Math.random() * 700));
      await box.press('Enter');
      if (i < parts.length - 1) await page.waitForTimeout(1200 + Math.floor(Math.random() * 1600));
    }
    pacing.registrarEnvio({ plataforma: 'whatsapp', contacto: message.phone, mensaje: message.message });
    await page.waitForTimeout(1500);
    return { ok: true };
  }

  const state = await readState(stateFile);
  const skipped = new Set();
  while (!stopping) {
    try {
      if (!(await wa.waitForAuth(page, 15_000))) { log('Sesión de WhatsApp Web no disponible; esperando.'); await wait(poll); continue; }
      // 1. Inbound.
      const seen = await wa.revisarEntrantes(page, { limit: 30, registrar: false, memoria: { previas: state.previas } });
      if (seen.ok) {
        for (const chat of seen.entrantes) {
          const phone = phoneFromTitle(chat.contacto);
          if (!phone) { if (!skipped.has(chat.contacto)) { skipped.add(chat.contacto); log('Chat con nombre guardado omitido: el puente solo identifica por número. No guardes contactos en este teléfono.'); } continue; }
          const read = await wa.readRecent(page, { contact: chat.contacto, limit: 12 });
          if (!read.ok) { log(`No se pudo leer el chat ${masked(phone)}.`); continue; }
          // Classified here: personal chats, groups and notifications never leave this computer.
          const rules = classifyChat(read.messages);
          // Explicit commands need no model; otherwise the local model decides and the rules are the fallback.
          const model = rules.category === 'automantpro' && /automantpro|registr|ofertar|[sc]-[0-9a-f]{6}/i.test(rules.reasons[0] ?? '') ? null : await classifyWithLocalModel(read.messages);
          const category = model ? (model.automantpro ? 'automantpro' : model.category) : rules.category;
          const reasons = model?.reasons ?? rules.reasons;
          const all = process.env.WHATSAPP_FORWARD === 'all';
          if (!all && !FORWARDED_CATEGORIES.has(category)) { log(`Chat ${masked(phone)}: ${category} (${reasons[0]}); no se envía al operador.`); continue; }
          let sent = 0;
          for (const item of pendingIncoming(phone, read.messages)) {
            const result = await client.inbound({ id: item.id, phone, text: item.text, category });
            if (!result.duplicate) sent++;
          }
          if (sent) log(`${sent} mensaje(s) de ${masked(phone)} (${category}) en cola para aprobación humana.`);
        }
        if (seen.arranqueEnFrio) log('Primera vuelta: se registró la lista de chats sin responder a nadie.');
        state.previas = seen.previas;
        await writeState(stateFile, state);
      }
      // 2. Outbound.
      for (const message of await client.outbox()) {
        if (stopping) { await client.undelivered(message, 'BRIDGE_STOPPING', 60).catch(() => {}); continue; }
        let outcome;
        try { outcome = await deliver(message); } catch { outcome = { ok: false, code: 'BROWSER_ERROR', delay: 300 }; }
        if (outcome.ok) { await client.delivered(message); log(`Enviado a ${masked(message.phone)} (${message.kind}).`); }
        else { await client.undelivered(message, outcome.code, outcome.delay); log(`Sin enviar a ${masked(message.phone)}: ${outcome.code}.`); }
      }
      // Go back to the chat list so the next inbound scan sees every conversation.
      if (!page.url().endsWith('web.whatsapp.com/')) await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
    } catch (e) {
      if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED', 'WHATSAPP_BRIDGE_DISABLED'].includes(e.code)) throw e;
      log(`Vuelta fallida (${e instanceof AgentError ? e.code : 'BROWSER_ERROR'}); reintento.`);
    }
    await wait(poll);
  }
  await context.close().catch(() => {});
}

main().catch(e => {
  process.stderr.write(`Puente detenido: ${e instanceof AgentError ? e.code : 'LOCAL_CONFIGURATION_ERROR'}\n`);
  process.exitCode = 1;
});
