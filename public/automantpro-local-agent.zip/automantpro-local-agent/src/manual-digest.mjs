// Digestor de manuales (26/11/2026): convierte el manual del propietario o de taller (PDF o texto) en filas del
// plan por componentes, en el mismo CSV que importa el panel («Importar CSV de mi taller»).
// Todo corre en este equipo: el texto se saca con pdftotext, el modelo local (Ollama) propone las filas y, en modo
// híbrido, Claude revisa solo lo dudoso. Ninguna fila se acepta si su cita y su número no aparecen literalmente
// en la página del manual: así el modelo no puede inventar intervalos. El resultado siempre lo revisa una persona
// antes de importarlo; este módulo no escribe en la base.
import { execFile } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { extname } from 'node:path';

/**
 * Catálogo de componentes (el mismo de packages/api/src/domain/maintenance/system-components.ts; una prueba
 * compara los ids). Cada uno lleva sinónimos en español e inglés, como aparecen en los manuales.
 */
export const MANUAL_COMPONENTS = Object.freeze([
  ['Motor y propulsión', 'mot_aceite', 'Aceite y filtro de aceite', ['aceite de motor', 'aceite del motor', 'filtro de aceite', 'engine oil', 'oil filter', 'lubricante del motor']],
  ['Motor y propulsión', 'mot_filtro_aire', 'Filtro de aire', ['filtro de aire', 'elemento del filtro de aire', 'air filter', 'air cleaner', 'depurador de aire']],
  ['Motor y propulsión', 'mot_bujias', 'Bujías / encendido', ['bujia', 'bujias', 'spark plug', 'spark plugs']],
  ['Motor y propulsión', 'mot_banda', 'Banda de accesorios', ['correa auxiliar', 'banda auxiliar', 'banda de accesorios', 'correa de accesorios', 'correa del alternador', 'correa poly v', 'drive belt', 'accessory belt', 'v-belt', 'banda del ventilador']],
  ['Motor y propulsión', 'mot_distribucion', 'Kit de distribución', ['distribucion', 'correa de distribucion', 'banda de distribucion', 'cadena de distribucion', 'timing belt', 'timing chain', 'tensor de distribucion']],
  ['Motor y propulsión', 'mot_filtro_comb', 'Filtro de combustible', ['filtro de combustible', 'filtro de diesel', 'filtro de gasoil', 'separador de agua', 'fuel filter', 'water separator', 'trampa de agua']],
  ['Motor y propulsión', 'mot_inyectores', 'Inyectores', ['inyector', 'inyectores', 'injector', 'injectors', 'tobera']],
  ['Motor y propulsión', 'mot_bomba_comb', 'Bomba y líneas de combustible', ['tuberia del sistema de combustible', 'sistema de combustible y su fijacion', 'bomba de combustible', 'lineas de combustible', 'tuberias de combustible', 'fuel pump', 'fuel lines', 'bomba de alta presion']],
  ['Motor y propulsión', 'mot_soportes', 'Soportes de motor', ['soportes de motor', 'soporte del motor', 'engine mount', 'engine mounts', 'bases de motor']],
  ['Motor y propulsión', 'mot_bateria_alta', 'Batería de alta tensión', ['bateria de alta tension', 'bateria de traccion', 'bateria hibrida', 'high voltage battery', 'hybrid battery']],
  ['Motor y propulsión', 'mot_inversor', 'Inversor y convertidor', ['inversor', 'convertidor dc/dc', 'inverter']],
  ['Motor y propulsión', 'mot_electrico', 'Motor eléctrico de tracción', ['motor electrico', 'motor de traccion', 'traction motor', 'electric motor']],
  ['Frenos y seguridad activa', 'fre_liquido', 'Líquido de frenos', ['liquido de frenos', 'liquido de freno', 'brake fluid', 'liquido del embrague y frenos']],
  ['Frenos y seguridad activa', 'fre_pastillas', 'Pastillas', ['pastillas', 'pastillas de freno', 'brake pads', 'pads']],
  ['Frenos y seguridad activa', 'fre_discos', 'Discos', ['discos de freno', 'disco de freno', 'brake disc', 'brake discs', 'rotor']],
  ['Frenos y seguridad activa', 'fre_mangueras', 'Mangueras y líneas de freno', ['tuberia del sistema de frenos', 'mangueras de freno', 'tuberias de freno', 'lineas de freno', 'brake lines', 'brake hoses', 'brake pipes']],
  ['Frenos y seguridad activa', 'fre_bomba', 'Bomba y cilindros de freno', ['bomba de freno', 'cilindro maestro', 'cilindros de rueda', 'master cylinder', 'wheel cylinder', 'servofreno']],
  ['Frenos y seguridad activa', 'fre_tambores', 'Balatas y tambores', ['tambor', 'tambores', 'zapatas', 'balatas', 'brake drum', 'brake shoes']],
  ['Frenos y seguridad activa', 'fre_mano', 'Freno de mano y su cable', ['freno de mano', 'freno de estacionamiento', 'parking brake', 'hand brake', 'cable del freno']],
  ['Suspensión y dirección', 'sus_amortiguadores', 'Amortiguadores', ['amortiguador', 'amortiguadores', 'shock absorber', 'shock absorbers']],
  ['Suspensión y dirección', 'sus_rotulas', 'Rótulas y terminales', ['rotulas', 'rotula', 'terminales de direccion', 'ball joint', 'tie rod', 'varillaje de direccion', 'steering linkage']],
  ['Suspensión y dirección', 'sus_bujes', 'Bujes y barras estabilizadoras', ['retenciones de la suspension', 'casquillo de la suspension', 'bujes', 'barra estabilizadora', 'stabilizer', 'bushings', 'brazos de suspension']],
  ['Suspensión y dirección', 'sus_cremallera', 'Cremallera / caja de dirección', ['direccion asistida', 'servodireccion', 'liquido de la direccion', 'cremallera', 'caja de direccion', 'direccion hidraulica', 'liquido de direccion', 'steering gear', 'power steering', 'steering fluid']],
  ['Suspensión y dirección', 'sus_resortes', 'Resortes y ballestas', ['ballesta', 'resortes', 'ballestas', 'muelles', 'leaf spring', 'coil spring', 'paquete de muelles']],
  ['Suspensión y dirección', 'sus_copelas', 'Soportes de amortiguador (copelas)', ['copelas', 'soporte de amortiguador', 'strut mount']],
  ['Transmisión y tren motriz', 'tra_aceite', 'Aceite de caja', ['lubricante de la transmision', 'palanca de cambios', 'aceite de caja', 'aceite de la transmision', 'aceite de transmision', 'transmission oil', 'gear oil', 'manual transmission', 'caja de cambios', 'transmission fluid']],
  ['Transmisión y tren motriz', 'tra_filtro', 'Filtro de caja automática', ['filtro de caja automatica', 'filtro de la transmision automatica', 'atf filter']],
  ['Transmisión y tren motriz', 'tra_embrague', 'Embrague', ['embrague', 'clutch', 'pedal del embrague', 'liquido de embrague']],
  ['Transmisión y tren motriz', 'tra_homocineticas', 'Semiejes y juntas homocinéticas', ['union universal del semieje', 'homocinetica', 'homocineticas', 'semieje', 'semiejes', 'cv joint', 'drive shaft', 'arbol de transmision', 'cardan', 'propeller shaft', 'crucetas']],
  ['Transmisión y tren motriz', 'tra_diferencial', 'Aceite del diferencial', ['lubricante del eje', 'diferencial', 'differential', 'caja de transferencia', 'transfer case', 'eje trasero', 'rear axle']],
  ['Transmisión y tren motriz', 'tra_soportes', 'Soportes de la caja', ['soportes de la caja', 'soporte de transmision', 'transmission mount']],
  ['Enfriamiento', 'enf_bomba', 'Bomba de agua', ['bomba de agua', 'water pump']],
  ['Enfriamiento', 'enf_termostato', 'Termostato', ['termostato', 'thermostat']],
  ['Enfriamiento', 'enf_radiador', 'Radiador', ['radiador', 'radiator', 'intercooler']],
  ['Enfriamiento', 'enf_tapa', 'Tapa del radiador / depósito', ['tapa del radiador', 'radiator cap', 'tapa de presion']],
  ['Enfriamiento', 'enf_deposito', 'Depósito de expansión', ['tuberia del sistema de refrigeracion', 'deposito de expansion', 'deposito del refrigerante', 'reservorio', 'expansion tank', 'coolant reservoir']],
  ['Enfriamiento', 'enf_mangueras', 'Mangueras', ['mangueras del radiador', 'mangueras de refrigeracion', 'mangueras del sistema de enfriamiento', 'coolant hoses', 'radiator hoses']],
  ['Enfriamiento', 'enf_abrazaderas', 'Abrazaderas', ['abrazaderas', 'clamps']],
  ['Enfriamiento', 'enf_canerias', 'Cañerías del circuito', ['canerias', 'tuberias de refrigeracion', 'coolant pipes']],
  ['Enfriamiento', 'enf_refrigerante', 'Refrigerante', ['refrigerante', 'anticongelante', 'liquido refrigerante', 'coolant', 'antifreeze', 'engine coolant']],
  ['Enfriamiento', 'enf_bateria_alta', 'Enfriamiento de la batería de alta tensión', ['refrigeracion de la bateria de alta tension', 'refrigerante de la bateria de alta tension', 'high voltage battery coolant', 'battery cooling']],
  ['Eléctrico y electrónica', 'ele_bateria', 'Batería', ['bateria', 'battery', 'bornes de la bateria']],
  ['Eléctrico y electrónica', 'ele_alternador', 'Alternador', ['alternador', 'alternator', 'generador']],
  ['Eléctrico y electrónica', 'ele_arranque', 'Motor de arranque', ['motor de arranque', 'arrancador', 'starter']],
  ['Eléctrico y electrónica', 'ele_luces', 'Luces y señalización', ['senales luminosas', 'luces', 'faros', 'iluminacion', 'lights', 'lamps', 'headlamps', 'senalizacion']],
  ['Eléctrico y electrónica', 'ele_fusibles', 'Fusibles y relés', ['fusibles', 'reles', 'fuses', 'relays']],
  ['Eléctrico y electrónica', 'ele_cables', 'Cables y bornes', ['mazo de cables', 'cables', 'cableado', 'arnes', 'wiring', 'harness', 'bujias de precalentamiento', 'glow plugs']],
  ['Llantas y ruedas', 'lla_rotacion', 'Rotación', ['rotacion', 'rotacion de neumaticos', 'rotacion de llantas', 'tire rotation', 'rotate tires']],
  ['Llantas y ruedas', 'lla_alineacion', 'Alineación y balanceo', ['alineacion', 'balanceo', 'wheel alignment', 'alignment', 'balancing', 'convergencia']],
  ['Llantas y ruedas', 'lla_presion', 'Presión y desgaste', ['presion de neumaticos', 'presion de inflado', 'desgaste de neumaticos', 'tire pressure', 'tire wear', 'estado de los neumaticos']],
  ['Llantas y ruedas', 'lla_cambio', 'Neumáticos', ['neumaticos', 'llantas', 'tires', 'tyres']],
  ['Llantas y ruedas', 'lla_valvulas', 'Válvulas y tapas', ['valvulas de neumatico', 'valve stem', 'tapas de valvula']],
  ['Llantas y ruedas', 'lla_rodamientos', 'Rodamientos de rueda', ['cojinetes de las ruedas', 'rodamientos', 'rodamiento de rueda', 'cojinete de rueda', 'wheel bearing', 'wheel bearings', 'manzanas', 'mangueta']],
  ['Carrocería, confort y visibilidad', 'car_escobillas', 'Escobillas', ['escobillas', 'plumillas', 'limpiaparabrisas', 'wiper', 'wipers', 'liquido lavaparabrisas']],
  ['Carrocería, confort y visibilidad', 'car_parabrisas', 'Parabrisas', ['parabrisas', 'windshield', 'windscreen']],
  ['Carrocería, confort y visibilidad', 'car_filtro_cabina', 'Filtro de cabina', ['sistema de ventilacion de a/a', 'elemento de ventilacion del a/a', 'filtro de cabina', 'filtro de polen', 'filtro del aire acondicionado', 'cabin filter', 'cabin air filter', 'pollen filter']],
  ['Carrocería, confort y visibilidad', 'car_aire', 'Aire acondicionado', ['aire acondicionado', 'gas refrigerante del a/c', 'air conditioning', 'a/c system', 'compresor del a/c']],
  ['Carrocería, confort y visibilidad', 'car_escape', 'Mofle y escape', ['escape', 'mofle', 'silenciador', 'tubo de escape', 'exhaust', 'muffler', 'catalizador']],
  ['Carrocería, confort y visibilidad', 'car_cerraduras', 'Cerraduras y bisagras', ['cerraduras', 'bisagras', 'locks', 'hinges', 'chapas']],
  ['Carrocería, confort y visibilidad', 'car_sellos', 'Sellos y gomas de puertas', ['sellos de puertas', 'gomas de puertas', 'burletes', 'door seals', 'weatherstrip']],
].map(([system, id, name, synonyms]) => Object.freeze({ system, id, name, synonyms: Object.freeze(synonyms) })));

export const fold = s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

/** Componente del catálogo para el nombre que trae el manual; el sinónimo más largo que aparezca gana. */
export function matchComponent(name) {
  const text = ` ${fold(name).replace(/[^a-z0-9/ ]+/g, ' ').replace(/\s+/g, ' ')} `;
  let best = null, bestLen = 0;
  for (const c of MANUAL_COMPONENTS) for (const syn of [c.name, ...c.synonyms]) {
    const s = fold(syn).replace(/[^a-z0-9/ ]+/g, ' ').trim();
    if (s && text.includes(` ${s} `) && s.length > bestLen) { best = c; bestLen = s.length; }
  }
  return best;
}

/** Texto del manual por página. PDF con pdftotext (argumentos en arreglo, sin shell); texto plano tal cual. */
export async function extractPages(path, { run = execFile, pdftotext = process.env.PDFTOTEXT || 'pdftotext' } = {}) {
  if (extname(path).toLowerCase() !== '.pdf') {
    const text = await readFile(path, 'utf8');
    return text.split('\f').map((t, i) => ({ page: i + 1, text: t }));
  }
  const out = await new Promise((resolve, reject) => run(pdftotext, ['-layout', '-enc', 'UTF-8', path, '-'], { maxBuffer: 64 * 1024 * 1024, windowsHide: true }, (err, stdout) => err ? reject(new Error(err.code === 'ENOENT' ? 'Falta pdftotext. En Ubuntu: sudo apt install poppler-utils (o define PDFTOTEXT con su ruta).' : `No se pudo leer el PDF con pdftotext: ${err.message}`)) : resolve(String(stdout))));
  const pages = out.split('\f').map((t, i) => ({ page: i + 1, text: t })).filter(p => p.text.trim());
  if (!pages.length) throw new Error('El PDF no tiene texto (parece escaneado). Pásalo antes por OCR: ocrmypdf -l spa+eng manual.pdf manual-ocr.pdf');
  return pages;
}

const KEYWORDS = ['mantenimiento', 'periodico', 'intervalo', 'cada', 'reemplazar', 'cambiar', 'inspeccionar', 'revisar', 'km', 'meses', 'maintenance', 'schedule', 'replace', 'inspect', 'interval', 'months', 'miles'];
/** Puntaje de una página: palabras de mantenimiento y números con forma de kilometraje. Las tablas puntúan alto. */
export function pageScore(text) {
  const t = fold(text);
  const words = KEYWORDS.reduce((n, k) => n + (t.split(k).length - 1), 0);
  const kms = (t.match(/\b\d{1,3}(?:[.,  ]\d{3})+\b|\b\d{4,6}\s?km\b/g) || []).length;
  const comps = MANUAL_COMPONENTS.filter(c => c.synonyms.some(s => t.includes(fold(s)))).length;
  return words + 2 * kms + 2 * comps;
}
export function relevantPages(pages, { min = 25, max = 40 } = {}) {
  return pages.map(p => ({ ...p, score: pageScore(p.text) })).filter(p => p.score >= min).sort((a, b) => b.score - a.score).slice(0, max).sort((a, b) => a.page - b.page);
}

/** Tabla en matriz: columnas «x1000 km» y una marca (R, I…) por columna en cada operación. */
export const isMatrixPage = text => /x\s?1[.,  ]?000\b/i.test(String(text ?? ''));
/** pdftotext -layout rellena con espacios: se encogen para que la página entera quepa en la pregunta. */
const dense = text => String(text ?? '').replace(/[ \t]{3,}/g, '  ');

export function extractionPrompt(page) {
  return [
    'Eres un asistente que extrae el plan de mantenimiento de un manual de vehículo. Lee SOLO el texto de abajo.',
    'Devuelve JSON: {"filas":[{"componente":"","accion":"","km":null,"meses":null,"cita":"","sistema":"","codigo_sistema":"","codigo":"","severo":false,"operacion":"","seccion":"","especificacion":"","torque":"","repuestos":[{"nombre":"","codigo":"","cantidad":1}]}]}.',
    '- severo: true solo si ese intervalo es el de uso o condiciones severas.',
    '- operacion: resumen propio y corto (máximo 200 caracteres) de lo que se hace; no copies párrafos del manual. Vacío si no lo describe.',
    '- seccion, especificacion (fluido, norma o capacidad), torque y repuestos (con su número de parte): solo si están impresos en la página, tal como aparecen.',
    '- sistema, codigo_sistema y codigo: el nombre del sistema o capítulo y los códigos tal como los imprime el manual para ese renglón; cadena vacía si no los trae.',
    '- componente: la pieza o el líquido tal como lo nombra el manual.',
    '- accion: reemplazar, inspeccionar, ajustar, limpiar o rotar.',
    '- km y meses: el intervalo como número entero (sin puntos), o null si el manual no lo da. Si el manual da millas y km, usa km.',
    '- cita: copia EXACTA, de 8 a 160 caracteres, del renglón del manual donde está el dato.',
    '- Si dice «a los X km y luego cada Y km», el intervalo es Y.',
    ...(isMatrixPage(page.text) ? ['- La página es una TABLA EN MATRIZ: la cabecera lista kilometrajes en miles y meses, y cada operación lleva marcas (R reemplazar, I inspeccionar) por columna. Devuelve UNA sola fila por operación, nunca una por columna: si las marcas se repiten en columnas seguidas, el intervalo es el paso entre columnas (normalmente 10000 km y 12 meses). Las operaciones con intervalo escrito en su frase usan ese intervalo.'] : []),
    'No inventes nada. Si la página no trae intervalos, devuelve {"filas":[]}.',
    `Texto de la página ${page.page}:`,
    dense(page.text).slice(0, 9000),
  ].join('\n');
}

/** Modelo local (Ollama) con salida JSON; null si no responde. */
export async function askOllama(prompt, { fetchImpl = fetch, url = process.env.LOCAL_AGENT_OLLAMA_URL || 'http://127.0.0.1:11434', model = process.env.MANUAL_OLLAMA_MODEL || process.env.LOCAL_AGENT_OLLAMA_MODEL || 'qwen2.5:7b', timeoutMs = Number(process.env.MANUAL_OLLAMA_TIMEOUT_MS) || 900_000 } = {}) {
  // Sin GPU, un 7B tarda minutos por página: el tope es amplio y configurable.
  try {
    const res = await fetchImpl(`${url}/api/generate`, { method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(timeoutMs),
      body: JSON.stringify({ model, prompt, stream: false, format: 'json', keep_alive: '30m', options: { temperature: 0, num_predict: 1200, num_ctx: 8192 } }) });
    if (!res.ok) return null;
    const data = await res.json();
    return typeof data?.response === 'string' ? data.response : null;
  } catch { return null; }
}

export function parseRows(raw) {
  if (!raw) return [];
  const m = String(raw).match(/\{[\s\S]*\}/);
  if (!m) return [];
  try { const j = JSON.parse(m[0]); return Array.isArray(j?.filas) ? j.filas.filter(r => r && typeof r === 'object') : []; } catch { return []; }
}

const squash = s => fold(s).replace(/[^a-z0-9]+/g, '');
const digits = n => String(n).replace(/\D/g, '');
/** El número aparece en el texto (con o sin separador de miles: 10000, 10.000, 10 000, 10,000). */
export function numberInText(n, text) {
  if (n === null || n === undefined) return true;
  const d = digits(n); if (!d) return false;
  const pattern = d.length > 3 ? d.replace(/\B(?=(\d{3})+(?!\d))/g, '[.,   ]?') : d;
  return new RegExp(`(^|\\D)${pattern}(\\D|$)`).test(text);
}
const wholeOrNull = v => { if (v === null || v === undefined || v === '') return null; const n = Number(String(v).replace(/[.,\s]/g, '')); return Number.isInteger(n) && n > 0 ? n : NaN; };

const compact = (v, max) => String(v ?? '').replace(/[|;\r\n]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
/** Referencia, especificación, par de apriete y repuestos: solo lo que está impreso en la página. */
export function detailsOf(row, page) {
  const text = squash(page.text);
  const printed = (v, max) => { const s = compact(v, max); return s && squash(s) && text.includes(squash(s)) ? s : ''; };
  const repuestos = (Array.isArray(row.repuestos) ? row.repuestos : []).slice(0, 12).flatMap(p => {
    const nombre = printed(p?.nombre, 80); if (!nombre) return [];
    const cantidad = Number(p?.cantidad);
    return [{ nombre, codigo: printed(p?.codigo, 40), cantidad: Number.isInteger(cantidad) && cantidad > 1 && cantidad < 100 && numberInText(cantidad, page.text) ? cantidad : 1 }];
  });
  // El resumen lo redacta el modelo: se descarta si es largo o copia un párrafo del manual.
  const operacion = compact(row.operacion, 600);
  return { severo: row.severo === true && /sever|extrem|arduo|dusty|heavy/i.test(fold(page.text)), operacion: operacion.length <= 200 && !(operacion.length > 90 && text.includes(squash(operacion))) ? operacion : '',
    seccion: printed(row.seccion, 80), especificacion: printed(row.especificacion, 200), torque: /\d/.test(String(row.torque ?? '')) ? printed(row.torque, 120) : '', repuestos };
}

/**
 * Valida una fila contra su página: la cita debe estar en la página y el número en la cita (o en la página si la
 * tabla separa la cabecera del renglón). Devuelve la fila con su estado: aceptada, sin_mapear o descartada.
 */
export function checkRow(row, page) {
  const km = wholeOrNull(row.km), months = wholeOrNull(row.meses);
  const cita = String(row.cita ?? '').trim().slice(0, 200);
  const base = { page: page.page, componente: String(row.componente ?? '').trim().slice(0, 120), accion: String(row.accion ?? '').trim().slice(0, 40), km, months, cita };
  // Los códigos y el sistema solo se aceptan si están impresos en la página.
  const printed = (v, max) => { const s = String(v ?? '').trim().slice(0, max); return s && squash(page.text).includes(squash(s)) ? s : ''; };
  Object.assign(base, { sistemaFabricante: printed(row.sistema, 100), codigoSistema: printed(row.codigo_sistema, 40), codigoItem: printed(row.codigo, 40), ...detailsOf(row, page) });
  // Si la propia cita dice que es para uso severo, no puede pasar como intervalo normal.
  if (/condiciones (de uso )?severas|uso severo|servicio severo/.test(fold(cita))) base.severo = true;
  if (Number.isNaN(km) || Number.isNaN(months)) return { ...base, estado: 'descartada', motivo: 'intervalo no numérico' };
  if (km === null && months === null) return { ...base, estado: 'descartada', motivo: 'sin intervalo' };
  if (km !== null && (km < 500 || km > 500_000)) return { ...base, estado: 'descartada', motivo: 'km fuera de rango' };
  if (months !== null && months > 240) return { ...base, estado: 'descartada', motivo: 'meses fuera de rango' };
  if (cita.length < 6 || !squash(page.text).includes(squash(cita))) return { ...base, estado: 'descartada', motivo: 'la cita no aparece en la página' };
  const near = `${cita}\n${page.text}`;
  // En una matriz «x1000» la cabecera imprime 10 y no 10.000.
  const enMiles = km !== null && isMatrixPage(page.text) && km % 1000 === 0 && numberInText(km / 1000, page.text);
  if ((!numberInText(km, near) && !enMiles) || !numberInText(months, near)) return { ...base, estado: 'descartada', motivo: 'el número no aparece en el manual' };
  const comp = matchComponent(`${base.componente} ${cita}`);
  if (!comp) return { ...base, estado: 'sin_mapear', motivo: 'componente fuera del catálogo' };
  return { ...base, estado: 'aceptada', componentId: comp.id, sistema: comp.system, item: comp.name, enCita: numberInText(km, cita) && numberInText(months, cita) };
}

const INSPECT = /inspec|revis|verific|comprob|check/i;
const DETAILS = ['operacion', 'seccion', 'especificacion', 'torque'];

/**
 * Une las filas de un componente. El cambio (o la acción principal), la revisión y el uso severo son intervalos
 * distintos; solo hay «conflicto» si dos páginas dan cifras diferentes para el mismo de los tres.
 */
/** Matriz leída columna por columna (10.000, 20.000, 30.000… del mismo renglón): queda el paso, el menor. */
export function collapseColumns(rows) {
  const by = new Map();
  for (const r of rows) {
    const key = `${r.page}|${r.componentId}|${squash(r.cita)}|${r.severo}|${INSPECT.test(r.accion ?? '')}`;
    (by.get(key) ?? by.set(key, []).get(key)).push(r);
  }
  return [...by.values()].flatMap(group => {
    const step = Math.min(...group.map(r => r.km ?? Infinity));
    const columns = group.length > 1 && Number.isFinite(step) && group.every(r => r.km && r.km % step === 0);
    return columns ? [group.find(r => r.km === step)] : group;
  });
}

export function mergeRows(rows) {
  const by = new Map();
  for (const r of collapseColumns(rows.filter(x => x.estado === 'aceptada'))) {
    // Con código propio, cada operación del manual es una fila aparte.
    const key = r.codigoItem ? `${r.componentId}|${r.codigoSistema}|${r.codigoItem}` : r.componentId;
    (by.get(key) ?? by.set(key, []).get(key)).push(r);
  }
  return [...by.values()].map(group => {
    const normal = group.filter(r => !r.severo), severe = group.filter(r => r.severo);
    const changes = normal.filter(r => !INSPECT.test(r.accion ?? '')), checks = normal.filter(r => INSPECT.test(r.accion ?? ''));
    const main = changes.length ? changes : checks.length ? checks : severe;
    const out = { ...main[0], paginas: [...new Set(group.map(r => r.page))] };
    delete out.severo;
    const clash = list => list.filter(r => r.km !== list[0].km || r.months !== list[0].months);
    const different = [main, changes.length ? checks : [], main === severe ? [] : severe].flatMap(list => (list.length ? clash(list) : []));
    if (different.length) { out.estado = 'conflicto'; out.motivo = `valores distintos en págs. ${out.paginas.join(', ')}`; out.alternativas = different.map(r => ({ km: r.km, months: r.months, page: r.page, cita: r.cita })); }
    if (changes.length && checks.length) { out.inspeccionKm = checks[0].km; out.inspeccionMeses = checks[0].months; }
    if (severe.length && main !== severe) { out.severoKm = severe[0].km; out.severoMeses = severe[0].months; }
    for (const field of DETAILS) out[field] = group.map(r => r[field]).find(Boolean) ?? '';
    out.repuestos = [...new Map(group.flatMap(r => r.repuestos ?? []).map(p => [`${fold(p.nombre)}|${p.codigo}`, p])).values()].slice(0, 12);
    return out;
  });
}

/** Pregunta híbrida: Claude confirma o corrige una fila dudosa contra la misma página (solo texto del manual). */
export function verifyPrompt(row, page) {
  return [
    'Verifica un dato del plan de mantenimiento contra el texto del manual. Responde solo JSON {"ok":true|false,"km":null|entero,"meses":null|entero}.',
    `Componente: ${row.item} (${row.componente}). Propuesto: km=${row.km}, meses=${row.months}. Cita: «${row.cita}».`,
    'ok=true solo si el texto confirma ese intervalo para ese componente; si da otro, ok=false con el valor correcto.',
    `Texto de la página ${page.page}:`, page.text.slice(0, 6000),
  ].join('\n');
}

const csvCell = v => { const s = String(v ?? '').replace(/[\r\n]+/g, ' '); const safe = /^[=+\-@\t]/.test(s) ? `'${s}` : s; return /[",;]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe; };
export const CSV_HEADER = ['sistema', 'item', 'marca', 'modelo', 'anio_desde', 'anio_hasta', 'combustible', 'intervalo_km', 'intervalo_meses', 'fuente', 'url', 'fecha', 'codigo_sistema', 'sistema_fabricante', 'codigo_item', 'item_fabricante', 'accion', 'pagina', 'cita',
  'inspeccion_km', 'inspeccion_meses', 'severo_km', 'severo_meses', 'operacion', 'ref_procedimiento', 'repuestos', 'especificacion', 'torque', 'tipo_manual'];
const procedureRef = (r, meta) => [r.seccion, r.procedimientoPag ? `pág. ${r.procedimientoPag}` : r.seccion ? `pág. ${r.page}` : ''].filter(Boolean).join(', ') + (r.seccion || r.procedimientoPag ? ` (${meta.tipo === 'taller' ? 'manual de taller' : 'manual del propietario'})` : '');
const partsCell = parts => (parts ?? []).map(p => `${p.nombre} | ${p.codigo} | ${p.cantidad}`).join('; ');
/** CSV para «Importar CSV de mi taller»: solo filas aceptadas; las de conflicto quedan en la revisión. */
export function toCsv(rows, meta) {
  const lines = [CSV_HEADER.join(',')];
  for (const r of rows.filter(x => x.estado === 'aceptada' || x.estado === 'sin_mapear')) {
    const outside = r.estado === 'sin_mapear';
    const fuente = `${meta.titulo}, pág. ${r.paginas?.join(', ') ?? r.page}`;
    lines.push([outside ? '' : r.sistema, outside ? '' : r.item, meta.marca, meta.modelo, meta.anioDesde, meta.anioHasta, meta.combustible ?? '', r.km ?? '', r.months ?? '', fuente, meta.url ?? '', meta.fecha,
      r.codigoSistema ?? '', r.sistemaFabricante || (outside ? 'Sin sistema en el manual' : ''), r.codigoItem ?? '', r.sistemaFabricante || r.codigoItem || outside ? r.componente : '', r.accion ?? '', r.page ?? '', r.cita ?? '',
      r.inspeccionKm ?? '', r.inspeccionMeses ?? '', r.severoKm ?? '', r.severoMeses ?? '', r.operacion ?? '', procedureRef(r, meta), partsCell(r.repuestos), r.especificacion ?? '', r.torque ?? '', meta.tipo ?? ''].map(csvCell).join(','));
  }
  return `${lines.join('\n')}\n`;
}

const PROCEDURE = /procedimiento|desmontaje|montaje|instalacion|reemplazo|torque|par de apriete|n\s?[·.]?\s?m\b|removal|installation|tightening/;
export function procedurePrompt(row, page) {
  return [
    `Lee SOLO el texto de abajo, de un manual de taller. Busca el procedimiento de: ${row.item} (${row.componente}).`,
    'Devuelve JSON: {"filas":[{"operacion":"","seccion":"","especificacion":"","torque":"","repuestos":[{"nombre":"","codigo":"","cantidad":1}]}]}.',
    'operacion: resumen propio y corto (máximo 200 caracteres). Lo demás, solo si está impreso en la página, tal como aparece.',
    'Si la página no trata de ese componente, devuelve {"filas":[]}.',
    `Texto de la página ${page.page}:`, page.text.slice(0, 7000),
  ].join('\n');
}

/**
 * Manual de taller: los procedimientos están en páginas sin intervalos. Para cada componente del plan se leen
 * hasta dos de esas páginas y se completa lo que falte (referencia, especificación, par de apriete, repuestos).
 */
export async function addProcedures(rows, pages, already, { ask, log = () => {}, perComponent = 2, maxPages = 60 } = {}) {
  const read = new Set(already.map(p => p.page)), used = new Set();
  const candidates = pages.filter(p => !read.has(p.page) && PROCEDURE.test(fold(p.text)));
  for (const row of rows) {
    const names = [...(MANUAL_COMPONENTS.find(c => c.id === row.componentId)?.synonyms ?? [])].map(fold);
    for (const page of candidates.filter(p => names.some(n => fold(p.text).includes(n))).slice(0, perComponent)) {
      if (!used.has(page.page) && used.size >= maxPages) break;
      used.add(page.page); log(`procedimiento de ${row.item}: página ${page.page}`);
      const found = parseRows(await ask(procedurePrompt(row, page)))[0];
      if (!found) continue;
      const extra = detailsOf(found, page);
      for (const field of DETAILS) row[field] ||= extra[field];
      if (!row.repuestos?.length) row.repuestos = extra.repuestos;
      row.procedimientoPag ||= page.page;
    }
  }
  return [...used].sort((a, b) => a - b);
}

/**
 * Digestión completa. `ask` = modelo local; `verify` (opcional, híbrido) = Claude para las filas cuyo número no
 * está en la propia cita o que quedaron en conflicto. Devuelve filas, páginas leídas y el CSV.
 */
export async function digestManual(pages, meta, { ask = askOllama, verify = null, log = () => {} } = {}) {
  const chosen = relevantPages(pages, meta.paginas ? { min: 0, max: 1000 } : undefined).filter(p => !meta.paginas || meta.paginas.includes(p.page));
  const raw = [];
  for (const page of chosen) {
    log(`página ${page.page} (puntaje ${page.score})`);
    const rows = parseRows(await ask(extractionPrompt(page)));
    for (const r of rows) raw.push(checkRow(r, page));
  }
  let merged = mergeRows(raw);
  if (verify) {
    for (const r of merged.filter(x => x.estado === 'conflicto' || !x.enCita)) {
      const page = chosen.find(p => p.page === r.page);
      const v = parseRows(`{"filas":[${(String(await verify(verifyPrompt(r, page)) ?? '').match(/\{[\s\S]*\}/) ?? ['null'])[0]}]}`)[0];
      if (!v) { r.revision = 'sin respuesta'; continue; }
      const km = wholeOrNull(v.km), months = wholeOrNull(v.meses);
      if (v.ok === true) { r.revision = 'confirmada'; if (r.estado === 'conflicto') r.estado = 'aceptada'; }
      else if (!Number.isNaN(km) && !Number.isNaN(months) && (km !== null || months !== null) && numberInText(km, page.text) && numberInText(months, page.text)) { r.revision = `corregida (antes ${r.km ?? '-'} km / ${r.months ?? '-'} meses)`; r.km = km; r.months = months; r.estado = 'aceptada'; }
      else { r.revision = 'rechazada'; r.estado = 'conflicto'; }
    }
  }
  const procedurePages = meta.tipo === 'taller' ? await addProcedures(merged.filter(x => x.estado === 'aceptada'), pages, chosen, { ask, log }) : [];
  const all = [...merged, ...raw.filter(x => x.estado !== 'aceptada')];
  const outside = [...new Map(raw.filter(x => x.estado === 'sin_mapear').map(r => [`${r.codigoSistema}|${r.codigoItem}|${fold(r.componente)}`, r])).values()];
  return { pagesRead: [...chosen.map(p => p.page), ...procedurePages], rows: all, csv: toCsv([...merged, ...outside], meta), counts: { aceptadas: merged.filter(x => x.estado === 'aceptada').length, conflicto: merged.filter(x => x.estado === 'conflicto').length, sin_mapear: raw.filter(x => x.estado === 'sin_mapear').length, descartadas: raw.filter(x => x.estado === 'descartada').length } };
}
