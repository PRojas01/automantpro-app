// Paquetes de planes (26/11/2026): un .zip, una carpeta o un .csv. Solo se leen archivos .csv con la fila de
// títulos de un plan; el zip se lee en memoria (nada se extrae al disco ni se ejecuta). Importar es acumulativo:
// el servidor agrega lo nuevo y actualiza lo repetido, nunca borra.
import { readdir, readFile, stat } from 'node:fs/promises';
import { basename, join, relative } from 'node:path';
import { inflateRawSync } from 'node:zlib';

export const LIMITS = { zipBytes: 20 * 1024 * 1024, csvBytes: 4 * 1024 * 1024, files: 200, chunkBytes: 190_000, chunkRows: 1_900, depth: 4 };
const HEADER = /^﻿?sistema[,;]item[,;]marca[,;]modelo/i;

/** Entradas .csv de un zip (métodos «sin comprimir» y «deflate»). */
export function zipCsvEntries(buffer) {
  let end = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 66_000); i--) if (buffer.readUInt32LE(i) === 0x06054b50) { end = i; break; }
  if (end < 0) throw new Error('El zip está dañado o no es un zip.');
  const total = buffer.readUInt16LE(end + 10);
  let at = buffer.readUInt32LE(end + 16);
  const out = [];
  for (let n = 0; n < total; n++) {
    if (buffer.readUInt32LE(at) !== 0x02014b50) throw new Error('El zip está dañado.');
    const method = buffer.readUInt16LE(at + 10), packed = buffer.readUInt32LE(at + 20), size = buffer.readUInt32LE(at + 24);
    const nameLength = buffer.readUInt16LE(at + 28), extra = buffer.readUInt16LE(at + 30), comment = buffer.readUInt16LE(at + 32);
    const local = buffer.readUInt32LE(at + 42), name = buffer.toString('utf8', at + 46, at + 46 + nameLength);
    at += 46 + nameLength + extra + comment;
    if (!/\.csv$/i.test(name)) continue;
    if (size > LIMITS.csvBytes) throw new Error(`«${name}» supera ${LIMITS.csvBytes / 1048576} MB.`);
    const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28);
    const raw = buffer.subarray(start, start + packed);
    if (method !== 0 && method !== 8) throw new Error(`«${name}» usa una compresión no admitida.`);
    out.push({ name, text: (method === 8 ? inflateRawSync(raw, { maxOutputLength: LIMITS.csvBytes }) : raw).toString('utf8') });
    if (out.length > LIMITS.files) throw new Error('Demasiados archivos en el paquete.');
  }
  return out;
}

async function walk(dir, root, depth, out) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) { if (depth < LIMITS.depth && !/^kit-/i.test(entry.name)) await walk(path, root, depth + 1, out); }
    else if (entry.isFile() && /\.zip$/i.test(entry.name) && !/^kit-/i.test(entry.name)) out.push(...(await fromZip(path)).map(f => ({ ...f, name: `${relative(root, path)} › ${f.name}` })));
    else if (entry.isFile() && /\.csv$/i.test(entry.name) && !/^ejemplo/i.test(entry.name)) out.push({ name: relative(root, path), text: await readCsv(path) });
    if (out.length > LIMITS.files) throw new Error('Demasiados archivos en el paquete.');
  }
  return out;
}
async function fromZip(path) {
  if ((await stat(path)).size > LIMITS.zipBytes) throw new Error(`«${basename(path)}» supera ${LIMITS.zipBytes / 1048576} MB.`);
  return zipCsvEntries(await readFile(path));
}
async function readCsv(path) {
  if ((await stat(path)).size > LIMITS.csvBytes) throw new Error(`«${basename(path)}» supera ${LIMITS.csvBytes / 1048576} MB.`);
  return readFile(path, 'utf8');
}

/** Archivos del paquete: los que son planes y los que se omiten (otros csv, como sistemas.csv). */
export async function readPackage(path) {
  const info = await stat(path);
  let files;
  if (info.isDirectory()) files = await walk(path, path, 0, []);
  else if (/\.zip$/i.test(path)) files = await fromZip(path);
  else if (/\.csv$/i.test(path)) files = [{ name: basename(path), text: await readCsv(path) }];
  else throw new Error('Entrega un .zip, una carpeta o un .csv.');
  return { plans: files.filter(f => HEADER.test(f.text)), skipped: files.filter(f => !HEADER.test(f.text)).map(f => f.name) };
}

/** Parte un CSV grande en trozos con su fila de títulos, sin cortar celdas entre comillas. */
export function splitCsv(text) {
  const rows = [];
  let row = '', quoted = false;
  for (const c of text.replace(/^﻿/, '')) {
    if (c === '"') quoted = !quoted;
    if (c === '\n' && !quoted) { if (row.trim()) rows.push(row.replace(/\r$/, '')); row = ''; } else row += c;
  }
  if (row.trim()) rows.push(row.replace(/\r$/, ''));
  const [header, ...body] = rows;
  const chunks = [];
  let part = [], bytes = 0;
  const flush = () => { if (part.length) chunks.push([header, ...part].join('\n') + '\n'); part = []; bytes = 0; };
  for (const line of body) {
    const size = Buffer.byteLength(line) + 1;
    if (part.length >= LIMITS.chunkRows || bytes + size + Buffer.byteLength(header) > LIMITS.chunkBytes) flush();
    part.push(line); bytes += size;
  }
  flush();
  return chunks;
}

/**
 * Envía cada plan del paquete. `send(csv, action)` es la llamada al canal de operador. Devuelve el detalle por
 * archivo y los totales; con `save` las filas con error se omiten (el resto se guarda).
 */
export async function importPackage(path, send, { save = false } = {}) {
  const { plans, skipped } = await readPackage(path);
  if (!plans.length) throw new Error('El paquete no trae ningún plan (CSV con títulos sistema,item,marca,modelo,…).');
  const files = [], total = { nueva: 0, actualizada: 0, sin_cambio: 0, error: 0, referenciales: 0, guardadas: 0 };
  for (const plan of plans) {
    const item = { archivo: plan.name, nueva: 0, actualizada: 0, sin_cambio: 0, error: 0, referenciales: 0, guardadas: 0, modelos: [], errores: [] };
    for (const chunk of splitCsv(plan.text)) {
      const r = await send(chunk, save ? 'save' : 'preview');
      for (const k of ['nueva', 'actualizada', 'sin_cambio', 'error']) item[k] += r.counts?.[k] ?? 0;
      item.referenciales += r.referenciales ?? 0;
      item.guardadas += r.saved ?? 0;
      item.modelos = [...new Set([...item.modelos, ...(r.models ?? [])])].slice(0, 10);
      item.errores = [...item.errores, ...(r.fatal ? [r.fatal] : []), ...(r.errors ?? []).map(e => `línea ${e.line}: ${e.errors.join('; ')}`)].slice(0, 5);
    }
    for (const k of Object.keys(total)) total[k] += item[k];
    files.push(item);
  }
  return { modo: save ? 'guardado' : 'vista previa (nada se guardó)', archivos: files, omitidos: skipped, total };
}
