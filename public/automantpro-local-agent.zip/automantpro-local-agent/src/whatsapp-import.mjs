import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { AgentError, createClient } from './client.mjs';

/**
 * Imports the chats marked with [x] in revision-historial.md as contacts "sin consentimiento" and,
 * with --reactivar <archivo>, queues the owner's reactivation text for them after a typed "SI".
 * Only phone, chat name, class, reason and last date are sent; never message text.
 */
async function main() {
  const info = await stat(resolve('.env'));
  if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600');
  process.loadEnvFile(resolve('.env'));
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const md = await readFile(resolve('revision-historial.md'), 'utf8');
  const review = JSON.parse(await readFile(resolve('revision-historial.json'), 'utf8'));
  const marked = new Set(md.split('\n').filter(l => /^\|\s*\[x\]/i.test(l)).map(l => l.split('|')[2]?.trim()).filter(p => /^\d{8,15}$/.test(p ?? '')));
  const contacts = review.chats.filter(c => marked.has(c.phone)).map(c => ({ phone: c.phone, name: (c.title || '').slice(0, 80) || null, category: c.category, reason: (c.reasons || []).join('; ').slice(0, 191) || null, lastMessage: (c.lastMessage || '').slice(0, 40) || null }));
  if (!contacts.length) { stdout.write('No hay chats marcados con [x] en revision-historial.md.\n'); return; }
  const result = await client.request('whatsapp/contacts/import', { contacts });
  stdout.write(`Importados: ${result.imported}; ya existentes u omitidos: ${result.skipped}.\n`);
  const at = process.argv.indexOf('--reactivar');
  if (at < 0) return;
  const message = (await readFile(resolve(process.argv[at + 1] || 'reactivacion.txt'), 'utf8')).trim();
  stdout.write(`\nMensaje para ${contacts.length} contactos:\n\n${message}\n\n(Se agrega al final cómo pedir la BAJA. Salen uno por uno con ritmo humano: máximo 10 por hora y 30 por día.)\n`);
  const rl = createInterface({ input: stdin, output: stdout });
  const name = (await rl.question('Tu nombre (queda en la auditoría): ')).trim();
  const sure = await rl.question('Escribe SI para enviarlo: ');
  rl.close();
  if (sure !== 'SI' || name.length < 2) { stdout.write('No se envió nada.\n'); return; }
  const sent = await client.request('whatsapp/contacts/reactivate', { message, phones: contacts.map(c => c.phone), approvedBy: name });
  stdout.write(`En cola: ${sent.queued}; omitidos (ya contactados o dados de baja): ${sent.skipped}.\n`);
}
main().catch(e => { process.stderr.write(`Importación detenida: ${e instanceof AgentError ? e.code : e?.code ?? 'ERROR'}\n`); process.exitCode = 1; });
