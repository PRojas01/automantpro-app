export const JOB_TYPES = Object.freeze(['responder_consulta', 'clasificar_mensaje', 'enviar_aviso_whatsapp', 'correr_pruebas', 'tomar_capturas', 'revisar_diff', 'reporte_estado']);
