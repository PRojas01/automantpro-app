import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';
import { AgentError, createClient } from './client.mjs';
import { processTask } from './jobs.mjs';
async function loadEnv() {
  try { const info = await stat(resolve('.env')); if (process.platform !== 'win32' && (info.mode & 0o077)) throw new AgentError('ENV_PERMISSIONS_REQUIRE_0600'); process.loadEnvFile(resolve('.env')); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
}
export async function runTaskWorker({ client, env = process.env, signal, pollSeconds = Number(env.LOCAL_AGENT_POLL_SECONDS || 5) }) {
  if (!Number.isFinite(pollSeconds) || pollSeconds < 1 || pollSeconds > 300) throw new AgentError('INVALID_POLL_SECONDS');
  while (!signal?.aborted) {
    try {
      const tasks = await client.claimTasks();
      for (const task of tasks) {
        if (signal?.aborted) break;
        try { await processTask({ client, task, env }); }
        catch (error) { if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(error.code)) throw error; }
      }
    } catch (error) { if (['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED'].includes(error.code)) throw error; }
    if (!signal?.aborted) try { await sleep(pollSeconds * 1000, undefined, { signal }); } catch (error) { if (error.name !== 'AbortError') throw error; }
  }
}
async function main() {
  await loadEnv();
  const client = createClient({ baseUrl: process.env.LOCAL_AGENT_URL, token: process.env.LOCAL_AGENT_TOKEN });
  const stop = new AbortController(); const end = () => stop.abort();
  process.on('SIGINT', end); process.on('SIGTERM', end);
  try { await runTaskWorker({ client, signal: stop.signal }); }
  finally { process.removeListener('SIGINT', end); process.removeListener('SIGTERM', end); }
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) main().catch(error => { process.stderr.write(`Worker detenido: ${error instanceof AgentError ? error.code : 'LOCAL_CONFIGURATION_ERROR'}\n`); process.exitCode = 1; });
