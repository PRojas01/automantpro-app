/** Cola de uno en uno: el modelo local en CPU no atiende dos borradores a la vez sin pasarse del tiempo límite. */
export function enSerie() {
  let cola = Promise.resolve();
  return fn => { const turno = cola.then(fn, fn); cola = turno.catch(() => {}); return turno; };
}

/**
 * Atiende trabajos sin frenar la consulta de la cola: un pendiente que espera aprobación en la bandeja ya no
 * retiene a los mensajes nuevos (cada uno conserva su reserva con su propio latido). Un error fatal se
 * vuelve a lanzar en la vuelta siguiente con `revisar()`.
 */
export function createDispatcher(procesar) {
  const enCurso = new Map();
  let fatal = null;
  return {
    despachar(job) {
      if (enCurso.has(job.wamid)) return;
      const tarea = Promise.resolve().then(() => procesar(job))
        .catch(error => { fatal ??= error; })
        .finally(() => enCurso.delete(job.wamid));
      enCurso.set(job.wamid, tarea);
    },
    revisar() { if (fatal) { const error = fatal; fatal = null; throw error; } },
    get activos() { return enCurso.size; },
    esperar: () => Promise.allSettled([...enCurso.values()]),
  };
}
