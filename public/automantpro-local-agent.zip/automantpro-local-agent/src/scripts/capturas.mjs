import { mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.env.LOCAL_AGENT_REPO_DIR;
const rawUrl = process.env.LOCAL_AGENT_URL;
let url;
try { url = new URL(rawUrl); } catch { process.stderr.write('LOCAL_AGENT_URL inválida.\n'); process.exit(2); }
if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname) || !['http:', 'https:'].includes(url.protocol)) {
  process.stderr.write('Las capturas requieren una URL localhost.\n'); process.exit(2);
}
let chromium;
try { ({ chromium } = await import('playwright-core')); }
catch { process.stderr.write('Falta playwright-core.\n'); process.exit(2); }
if (!root) { process.stderr.write('LOCAL_AGENT_REPO_DIR requerido.\n'); process.exit(2); }
// data/ is git-ignored and excluded from the ZIP.
const output = fileURLToPath(new URL('../../data/captures/', import.meta.url));
await mkdir(output, { recursive: true, mode: 0o700 });
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage();
  for (const path of ['/', '/pruebas']) {
    await page.goto(new URL(path, url.origin).href, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.screenshot({ path: resolve(output, `${path === '/' ? 'home' : 'pruebas'}.png`), fullPage: true });
  }
} finally { await browser.close(); }
