import { JOB_TYPES } from './task-types.mjs';

export class AgentError extends Error {
  constructor(code) { super(code); this.code = code; }
}
export function validateBaseUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new AgentError('INVALID_URL'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if ((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username ||
      url.password || url.search || url.hash || url.pathname !== '/') throw new AgentError('HTTPS_OR_LOCALHOST_REQUIRED');
  return url.origin;
}
export function createClient({ baseUrl, token, fetchImpl = fetch, timeoutMs = 15000 }) {
  const origin = validateBaseUrl(baseUrl);
  if (!token || /[\r\n]/.test(token) || token === 'replace-with-dedicated-server-token') throw new AgentError('TOKEN_REQUIRED');
  async function post(path, body) { return request(`jobs/${path}`, body, 'POST'); }
  async function request(path, body, method = 'POST') {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const headers = { authorization: `Bearer ${token}` };
      const options = { method, redirect: 'error', signal: controller.signal, headers };
      if (method !== 'GET') { headers['content-type'] = 'application/json'; options.body = JSON.stringify(body ?? {}); }
      const response = await fetchImpl(`${origin}/api/v1/local-agent/${path}`, options);
      if ([401, 403].includes(response.status)) throw new AgentError('AUTH_REJECTED');
      if (response.status === 503) {
        // Only this known code is safe to report; never expose arbitrary server bodies.
        const body = await response.json().catch(() => null);
        if (['LOCAL_AGENT_DISABLED', 'WHATSAPP_BRIDGE_DISABLED'].includes(body?.error?.code)) throw new AgentError(body.error.code);
      }
      if ([403, 404, 409, 422].includes(response.status)) {
        // Business rejections carry a bounded code the operator needs (e.g. NO_NEARBY_BUSINESSES);
        // anything else in the body is never shown.
        const error = (await response.json().catch(() => null))?.error;
        const code = error?.code;
        const rejection = new AgentError(typeof code === 'string' && /^[A-Z_]{1,64}$/.test(code) ? code : `HTTP_${response.status}`);
        // The server's short chat message for that code (e.g. «El kilometraje debe ser…») becomes the operator's draft.
        // Only plain bounded text is kept: no links, no control characters.
        const message = error?.message;
        if (rejection.code === code && typeof message === 'string' && message !== code && message.length <= 400 && !/[\u0000-\u001f\u007f]|https?:\/\//i.test(message)) rejection.detail = message.trim();
        throw rejection;
      }
      if (!response.ok) throw new AgentError(`HTTP_${response.status}`);
      let envelope;
      try { envelope = await response.json(); } catch { throw new AgentError('INVALID_RESPONSE'); }
      if (!envelope?.data || envelope.error) throw new AgentError('INVALID_RESPONSE');
      return envelope.data;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError(controller.signal.aborted ? 'REQUEST_TIMEOUT' : 'NETWORK_ERROR');
    } finally { clearTimeout(timer); }
  }
  const validTasks = tasks => {
    if (!Array.isArray(tasks) || tasks.some(t => !t || typeof t.id !== 'string' || !t.id || !JOB_TYPES.includes(t.type) || typeof t.leaseToken !== 'string' || !t.leaseToken || !(t.payload === null || t.payload === undefined || (typeof t.payload === 'object' && !Array.isArray(t.payload))))) throw new AgentError('INVALID_TASKS');
  };
  const path = (job, op) => `${encodeURIComponent(job.wamid)}/${op}`;
  return {
    async ping() {
      const data = await request('ping', undefined, 'GET');
      if (data?.ok !== true || typeof data.whatsappDelivery !== 'string') throw new AgentError('INVALID_RESPONSE');
      return { ok: true, whatsappDelivery: data.whatsappDelivery };
    },
    async claim() {
      const data = await post('claim', {});
      if (!Array.isArray(data.jobs) || data.jobs.some(j => !j || typeof j.wamid !== 'string' || !j.wamid ||
        typeof j.leaseToken !== 'string' || !j.leaseToken || typeof j.message !== 'string' ||
        typeof j.userId !== 'string' || !['pilot', 'whatsapp'].includes(j.channel))) throw new AgentError('INVALID_JOBS');
      return data.jobs;
    },
    async claimAll() {
      const data = await post('claim', {});
      if (!Array.isArray(data.jobs) || data.jobs.some(j => !j || typeof j.wamid !== 'string' || !j.wamid || typeof j.leaseToken !== 'string' || !j.leaseToken || typeof j.message !== 'string' || typeof j.userId !== 'string' || !['pilot', 'whatsapp'].includes(j.channel))) throw new AgentError('INVALID_JOBS');
      // Older servers send no tasks field.
      const tasks = data.tasks ?? [];
      validTasks(tasks);
      return { jobs: data.jobs, tasks };
    },
    async claimTasks() {
      const data = await request('tasks/claim', {});
      validTasks(data.tasks);
      return data.tasks;
    },
    completeTask: (task, result) => request(`tasks/${encodeURIComponent(task.id)}/complete`, { leaseToken: task.leaseToken, result: String(result).slice(0, 8000) }),
    failTask: (task, code) => request(`tasks/${encodeURIComponent(task.id)}/fail`, { leaseToken: task.leaseToken, errorCode: /^[A-Z_]{1,64}$/.test(code) ? code : 'LOCAL_ERROR' }),
    heartbeat: job => post(path(job, 'heartbeat'), { leaseToken: job.leaseToken }),
    context: job => post(path(job, 'context'), { leaseToken: job.leaseToken }),
    dismiss: job => post(path(job, 'dismiss'), { leaseToken: job.leaseToken }),
    request,
    complete: (job, reply, executeCommand, command) => post(path(job, 'complete'), { leaseToken: job.leaseToken, reply, executeCommand, ...(command ? { command } : {}) }),
    retry: job => post(path(job, 'retry'), { leaseToken: job.leaseToken, errorCode: 'OPERATOR_DEFERRED', delaySeconds: 60 }),
    // WhatsApp Web bridge: the server decides who may receive what; the bridge only delivers.
    inbound: ({ id, phone, text, category, image }) => request('whatsapp/inbound', { id, phone, text, ...(category ? { category } : {}), ...(image ? { image } : {}) }),
    async outbox() {
      const data = await request('whatsapp/outbox/claim', {});
      if (!Array.isArray(data.messages) || data.messages.some(m => !m || typeof m.id !== 'string' || typeof m.leaseToken !== 'string' ||
        !/^\d{6,32}$/.test(String(m.phone)) || typeof m.message !== 'string' || !m.message)) throw new AgentError('INVALID_OUTBOX');
      return data.messages;
    },
    delivered: m => request(`whatsapp/outbox/${encodeURIComponent(m.id)}/sent`, { leaseToken: m.leaseToken }),
    undelivered: (m, errorCode, delaySeconds = 120) => request(`whatsapp/outbox/${encodeURIComponent(m.id)}/failed`, { leaseToken: m.leaseToken, errorCode: /^[A-Z_]{1,64}$/.test(errorCode) ? errorCode : 'DELIVERY_FAILED', delaySeconds: Math.min(3600, Math.max(60, Math.round(delaySeconds))) }),
  };
}
// Codes that mean "not delivered / not authorized", never a business rejection the contact should hear about.
const NOT_A_REJECTION = new Set(['AUTH_REJECTED', 'LOCAL_AGENT_DISABLED', 'WHATSAPP_BRIDGE_DISABLED', 'INVALID_RESPONSE', 'REQUEST_TIMEOUT', 'NETWORK_ERROR', 'INVALID_DECISION']);
export const isBusinessRejection = error => error instanceof AgentError && /^[A-Z_]{1,64}$/.test(error.code) && !error.code.startsWith('HTTP_') && !NOT_A_REJECTION.has(error.code);
async function completeOrReject(client, job, decision) {
  if (typeof decision.reply !== 'string' || !decision.reply.trim() || decision.reply.length > 2000) throw new AgentError('INVALID_DECISION');
  const command = typeof decision.command === 'string' && decision.command.trim() ? decision.command.trim().slice(0, 2000) : undefined;
  try {
    const result = await client.complete(job, decision.reply.trim(), true, command);
    return { status: result.accepted === true ? 'completed' : 'lease-lost' };
  } catch (error) {
    if (!isBusinessRejection(error)) throw error;
    return { rejected: true, code: error.code, detail: error.detail ?? '' };
  }
}
export async function handleJob({ client, job, approve, heartbeatMs = 30000, onLost = () => {}, maxRejections = 3 }) {
  let lost = false;
  // While the command is being completed, a refused heartbeat means the server closed the job, not a lost lease.
  let closing = false;
  let pending = Promise.resolve();
  const approval = new AbortController();
  const markLost = () => { if (!lost && !closing) { lost = true; approval.abort(); onLost(); } };
  // Un corte de red o un equipo saturado no es perder el turno: el servidor lo guarda 5 minutos. Se da por
  // perdido si lo rechaza, o tras tres latidos seguidos sin respuesta (el primero sí es estricto).
  let failures = 0, started = false;
  const pulse = () => {
    pending = pending.then(async () => {
      if (lost) return;
      try { if ((await client.heartbeat(job)).accepted !== true) markLost(); else failures = 0; }
      catch { if (!started || ++failures >= 3) markLost(); }
      started = true;
    });
    return pending;
  };
  await pulse();
  if (lost) return { status: 'lease-lost' };
  const timer = setInterval(() => { void pulse(); }, heartbeatMs);
  try {
    let decision = await approve(job, approval.signal);
    // A business rejection (the server rolled the command back) keeps the lease: the operator gets the
    // server's reason as a new draft instead of the job silently failing and coming back with the same decision.
    for (let rejections = 0; ; rejections++) {
      if (lost || decision?.action !== 'execute' || rejections >= maxRejections) break;
      closing = true;
      const outcome = await completeOrReject(client, job, decision);
      // Completed: the server already closed the job, so a heartbeat now would be refused and look like a lost lease.
      if (!outcome.rejected) { clearInterval(timer); return outcome; }
      closing = false;
      decision = await approve(job, approval.signal, { code: outcome.code, detail: outcome.detail });
    }
    clearInterval(timer);
    await pulse();
    if (lost) return { status: 'lease-lost' };
    if (decision?.action === 'dismiss') {
      const result = await client.dismiss(job);
      return { status: result.accepted === true ? 'dismissed' : 'lease-lost' };
    }
    if (!decision || decision.action === 'defer') {
      const result = await client.retry(job);
      return { status: result.accepted === false ? 'lease-lost' : 'deferred' };
    }
    if (!['send', 'execute'].includes(decision.action) || typeof decision.reply !== 'string' ||
        !decision.reply.trim() || decision.reply.length > 2000) throw new AgentError('INVALID_DECISION');
    const command = decision.action === 'execute' && typeof decision.command === 'string' && decision.command.trim() ? decision.command.trim().slice(0, 2000) : undefined;
    const result = await client.complete(job, decision.reply.trim(), decision.action === 'execute', command);
    return { status: result.accepted === true ? 'completed' : 'lease-lost' };
  } finally { clearInterval(timer); await pending; }
}
