import { JOB_TYPES } from './task-types.mjs';

export class AgentError extends Error {
  constructor(code) { super(code); this.code = code; }
}
export function validateBaseUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new AgentError('INVALID_URL'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if ((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username ||
      url.password || url.search || url.hash || url.pathname !== '/') throw new AgentError('HTTPS_OR_LOCALHOST_REQUIRED');
  return url.origin;
}
export function createClient({ baseUrl, token, fetchImpl = fetch, timeoutMs = 15000 }) {
  const origin = validateBaseUrl(baseUrl);
  if (!token || /[\r\n]/.test(token) || token === 'replace-with-dedicated-server-token') throw new AgentError('TOKEN_REQUIRED');
  async function post(path, body) { return request(`jobs/${path}`, body, 'POST'); }
  async function request(path, body, method = 'POST') {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const headers = { authorization: `Bearer ${token}` };
      const options = { method, redirect: 'error', signal: controller.signal, headers };
      if (method !== 'GET') { headers['content-type'] = 'application/json'; options.body = JSON.stringify(body ?? {}); }
      const response = await fetchImpl(`${origin}/api/v1/local-agent/${path}`, options);
      if ([401, 403].includes(response.status)) throw new AgentError('AUTH_REJECTED');
      if (response.status === 503) {
        // Only this known code is safe to report; never expose arbitrary server bodies.
        const body = await response.json().catch(() => null);
        if (['LOCAL_AGENT_DISABLED', 'WHATSAPP_BRIDGE_DISABLED'].includes(body?.error?.code)) throw new AgentError(body.error.code);
      }
      if ([403, 404, 409, 422].includes(response.status)) {
        // Business rejections carry a bounded code the operator needs (e.g. NO_NEARBY_BUSINESSES);
        // anything else in the body is never shown.
        const code = (await response.json().catch(() => null))?.error?.code;
        throw new AgentError(typeof code === 'string' && /^[A-Z_]{1,64}$/.test(code) ? code : `HTTP_${response.status}`);
      }
      if (!response.ok) throw new AgentError(`HTTP_${response.status}`);
      let envelope;
      try { envelope = await response.json(); } catch { throw new AgentError('INVALID_RESPONSE'); }
      if (!envelope?.data || envelope.error) throw new AgentError('INVALID_RESPONSE');
      return envelope.data;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError(controller.signal.aborted ? 'REQUEST_TIMEOUT' : 'NETWORK_ERROR');
    } finally { clearTimeout(timer); }
  }
  const validTasks = tasks => {
    if (!Array.isArray(tasks) || tasks.some(t => !t || typeof t.id !== 'string' || !t.id || !JOB_TYPES.includes(t.type) || typeof t.leaseToken !== 'string' || !t.leaseToken || !(t.payload === null || t.payload === undefined || (typeof t.payload === 'object' && !Array.isArray(t.payload))))) throw new AgentError('INVALID_TASKS');
  };
  const path = (job, op) => `${encodeURIComponent(job.wamid)}/${op}`;
  return {
    async ping() {
      const data = await request('ping', undefined, 'GET');
      if (data?.ok !== true || typeof data.whatsappDelivery !== 'string') throw new AgentError('INVALID_RESPONSE');
      return { ok: true, whatsappDelivery: data.whatsappDelivery };
    },
    async claim() {
      const data = await post('claim', {});
      if (!Array.isArray(data.jobs) || data.jobs.some(j => !j || typeof j.wamid !== 'string' || !j.wamid ||
        typeof j.leaseToken !== 'string' || !j.leaseToken || typeof j.message !== 'string' ||
        typeof j.userId !== 'string' || !['pilot', 'whatsapp'].includes(j.channel))) throw new AgentError('INVALID_JOBS');
      return data.jobs;
    },
    async claimAll() {
      const data = await post('claim', {});
      if (!Array.isArray(data.jobs) || data.jobs.some(j => !j || typeof j.wamid !== 'string' || !j.wamid || typeof j.leaseToken !== 'string' || !j.leaseToken || typeof j.message !== 'string' || typeof j.userId !== 'string' || !['pilot', 'whatsapp'].includes(j.channel))) throw new AgentError('INVALID_JOBS');
      // Older servers send no tasks field.
      const tasks = data.tasks ?? [];
      validTasks(tasks);
      return { jobs: data.jobs, tasks };
    },
    async claimTasks() {
      const data = await request('tasks/claim', {});
      validTasks(data.tasks);
      return data.tasks;
    },
    completeTask: (task, result) => request(`tasks/${encodeURIComponent(task.id)}/complete`, { leaseToken: task.leaseToken, result: String(result).slice(0, 8000) }),
    failTask: (task, code) => request(`tasks/${encodeURIComponent(task.id)}/fail`, { leaseToken: task.leaseToken, errorCode: /^[A-Z_]{1,64}$/.test(code) ? code : 'LOCAL_ERROR' }),
    heartbeat: job => post(path(job, 'heartbeat'), { leaseToken: job.leaseToken }),
    context: job => post(path(job, 'context'), { leaseToken: job.leaseToken }),
    dismiss: job => post(path(job, 'dismiss'), { leaseToken: job.leaseToken }),
    request,
    complete: (job, reply, executeCommand, command) => post(path(job, 'complete'), { leaseToken: job.leaseToken, reply, executeCommand, ...(command ? { command } : {}) }),
    retry: job => post(path(job, 'retry'), { leaseToken: job.leaseToken, errorCode: 'OPERATOR_DEFERRED', delaySeconds: 60 }),
    // WhatsApp Web bridge: the server decides who may receive what; the bridge only delivers.
    inbound: ({ id, phone, text, category, image }) => request('whatsapp/inbound', { id, phone, text, ...(category ? { category } : {}), ...(image ? { image } : {}) }),
    async outbox() {
      const data = await request('whatsapp/outbox/claim', {});
      if (!Array.isArray(data.messages) || data.messages.some(m => !m || typeof m.id !== 'string' || typeof m.leaseToken !== 'string' ||
        !/^\d{6,32}$/.test(String(m.phone)) || typeof m.message !== 'string' || !m.message)) throw new AgentError('INVALID_OUTBOX');
      return data.messages;
    },
    delivered: m => request(`whatsapp/outbox/${encodeURIComponent(m.id)}/sent`, { leaseToken: m.leaseToken }),
    undelivered: (m, errorCode, delaySeconds = 120) => request(`whatsapp/outbox/${encodeURIComponent(m.id)}/failed`, { leaseToken: m.leaseToken, errorCode: /^[A-Z_]{1,64}$/.test(errorCode) ? errorCode : 'DELIVERY_FAILED', delaySeconds: Math.min(3600, Math.max(60, Math.round(delaySeconds))) }),
  };
}
export async function handleJob({ client, job, approve, heartbeatMs = 30000, onLost = () => {} }) {
  let lost = false;
  let pending = Promise.resolve();
  const approval = new AbortController();
  const markLost = () => { if (!lost) { lost = true; approval.abort(); onLost(); } };
  const pulse = () => {
    pending = pending.then(async () => {
      if (lost) return;
      try { if ((await client.heartbeat(job)).accepted !== true) markLost(); } catch { markLost(); }
    });
    return pending;
  };
  await pulse();
  if (lost) return { status: 'lease-lost' };
  const timer = setInterval(() => { void pulse(); }, heartbeatMs);
  try {
    const decision = await approve(job, approval.signal);
    clearInterval(timer);
    await pulse();
    if (lost) return { status: 'lease-lost' };
    if (decision?.action === 'dismiss') {
      const result = await client.dismiss(job);
      return { status: result.accepted === true ? 'dismissed' : 'lease-lost' };
    }
    if (!decision || decision.action === 'defer') {
      const result = await client.retry(job);
      return { status: result.accepted === false ? 'lease-lost' : 'deferred' };
    }
    if (!['send', 'execute'].includes(decision.action) || typeof decision.reply !== 'string' ||
        !decision.reply.trim() || decision.reply.length > 2000) throw new AgentError('INVALID_DECISION');
    const command = decision.action === 'execute' && typeof decision.command === 'string' && decision.command.trim() ? decision.command.trim().slice(0, 2000) : undefined;
    const result = await client.complete(job, decision.reply.trim(), decision.action === 'execute', command);
    return { status: result.accepted === true ? 'completed' : 'lease-lost' };
  } finally { clearInterval(timer); await pending; }
}
