export class AgentError extends Error {
  constructor(code) { super(code); this.code = code; }
}
export function validateBaseUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new AgentError('INVALID_URL'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if ((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username ||
      url.password || url.search || url.hash || url.pathname !== '/') throw new AgentError('HTTPS_OR_LOCALHOST_REQUIRED');
  return url.origin;
}
export function createClient({ baseUrl, token, fetchImpl = fetch, timeoutMs = 15000 }) {
  const origin = validateBaseUrl(baseUrl);
  if (!token || /[\r\n]/.test(token) || token === 'replace-with-dedicated-server-token') throw new AgentError('TOKEN_REQUIRED');
  async function post(path, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetchImpl(`${origin}/api/v1/local-agent/jobs/${path}`, {
        method: 'POST', redirect: 'error', signal: controller.signal,
        headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' }, body: JSON.stringify(body),
      });
      if ([401, 403].includes(response.status)) throw new AgentError('AUTH_REJECTED');
      if (!response.ok) throw new AgentError(`HTTP_${response.status}`);
      let envelope;
      try { envelope = await response.json(); } catch { throw new AgentError('INVALID_RESPONSE'); }
      if (!envelope?.data || envelope.error) throw new AgentError('INVALID_RESPONSE');
      return envelope.data;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError(controller.signal.aborted ? 'REQUEST_TIMEOUT' : 'NETWORK_ERROR');
    } finally { clearTimeout(timer); }
  }
  const path = (job, op) => `${encodeURIComponent(job.wamid)}/${op}`;
  return {
    async claim() {
      const data = await post('claim', {});
      if (!Array.isArray(data.jobs) || data.jobs.some(j => !j || typeof j.wamid !== 'string' || !j.wamid ||
        typeof j.leaseToken !== 'string' || !j.leaseToken || typeof j.message !== 'string' ||
        typeof j.userId !== 'string' || !['pilot', 'whatsapp'].includes(j.channel))) throw new AgentError('INVALID_JOBS');
      return data.jobs;
    },
    heartbeat: job => post(path(job, 'heartbeat'), { leaseToken: job.leaseToken }),
    complete: (job, reply, executeCommand) => post(path(job, 'complete'), { leaseToken: job.leaseToken, reply, executeCommand }),
    retry: job => post(path(job, 'retry'), { leaseToken: job.leaseToken, errorCode: 'OPERATOR_DEFERRED', delaySeconds: 60 }),
  };
}
export async function handleJob({ client, job, approve, heartbeatMs = 30000, onLost = () => {} }) {
  let lost = false;
  let pending = Promise.resolve();
  const markLost = () => { if (!lost) { lost = true; onLost(); } };
  const pulse = () => {
    pending = pending.then(async () => {
      if (lost) return;
      try { if ((await client.heartbeat(job)).accepted !== true) markLost(); } catch { markLost(); }
    });
    return pending;
  };
  await pulse();
  if (lost) return { status: 'lease-lost' };
  const timer = setInterval(() => { void pulse(); }, heartbeatMs);
  try {
    const decision = await approve(job);
    clearInterval(timer);
    await pulse();
    if (lost) return { status: 'lease-lost' };
    if (!decision || decision.action === 'defer') {
      const result = await client.retry(job);
      return { status: result.accepted === false ? 'lease-lost' : 'deferred' };
    }
    if (!['send', 'execute'].includes(decision.action) || typeof decision.reply !== 'string' ||
        !decision.reply.trim() || decision.reply.length > 2000) throw new AgentError('INVALID_DECISION');
    const result = await client.complete(job, decision.reply.trim(), decision.action === 'execute');
    return { status: result.accepted === true ? 'completed' : 'lease-lost' };
  } finally { clearInterval(timer); await pending; }
}
