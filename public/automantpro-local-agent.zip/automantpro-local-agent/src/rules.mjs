import { appendFile, mkdir, chmod } from 'node:fs/promises';
import { dirname, join } from 'node:path';

const skills = ['registro','plan','busqueda','historial','servicio','negocio','otro'];
export async function approveRule(db, id, { memoryDir = new URL('../memoria/', import.meta.url).pathname, mejorasPath = join(dirname(memoryDir), 'MEJORAS.md') } = {}) {
  const rule = db.regla(id);
  if (!rule || rule.estado !== 'propuesta') return false;
  if (!skills.includes(rule.habilidad) || rule.texto.length > 200) throw new Error('INVALID_RULE');
  if (!db.decidirRegla(id, 'aprobada')) return false;
  const date = rule.creado.slice(0, 10);
  const path = join(memoryDir, 'aprendidas.md');
  await mkdir(memoryDir, { recursive: true, mode: 0o700 });
  const handle = await import('node:fs/promises').then(fs => fs.open(path, 'a', 0o600));
  try { await handle.write(`\n## ${rule.habilidad} / ${date}\n- ${rule.texto}\n`); await handle.sync(); } finally { await handle.close(); }
  await chmod(path, 0o600);
  const mejoras = `\n| ${date} | Regla aprobada (${rule.habilidad}): ${rule.texto.replaceAll('|','/')} | memoria/aprendidas.md | Evento ${rule.origen_evento ?? 'manual'} |\n`;
  await appendFile(mejorasPath, mejoras, { mode: 0o600 });
  return true;
}
