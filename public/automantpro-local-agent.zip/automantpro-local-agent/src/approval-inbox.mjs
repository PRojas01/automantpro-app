import { stripOperatorLines } from './drafter.mjs';
import { createHash } from 'node:crypto';
import { chmod, mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { unlink, readdir } from 'node:fs/promises';
import { anonymize, neutralize } from './drafter.mjs';
import { masked } from './bridge-core.mjs';
import { recordLearning } from './learning.mjs';
import { buildAction } from './actions.mjs';

const digest = (jobId, mensaje, borrador, accion = null, riesgo = '') => createHash('sha256').update(`${jobId}${mensaje}${borrador}${JSON.stringify(accion)}${riesgo}`).digest('hex');
const safeId = id => typeof id === 'string' && id.length > 0 && id.length <= 512 && !/[\\/\0]/.test(id) && id !== '.' && id !== '..';
const fileId = id => Buffer.from(id, 'utf8').toString('base64url');

async function atomicJson(path, data) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const tmp = `${path}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tmp, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  await chmod(tmp, 0o600);
  await rename(tmp, path);
  await chmod(path, 0o600);
}

/** The bridge notes which chat (masked number only) each forwarded message came from. */
export async function recordOrigin(root, jobId, phone) {
  await mkdir(root, { recursive: true, mode: 0o700 });
  await writeFile(join(root, 'origen.jsonl'), `${JSON.stringify({ jobId, chat: masked(phone) })}\n`, { mode: 0o600, flag: 'a' });
}
async function originOf(root, jobId) {
  const text = await readFile(join(root, 'origen.jsonl'), 'utf8').catch(() => '');
  let chat = '';
  for (const line of text.split('\n')) { try { const row = JSON.parse(line); if (row.jobId === jobId) chat = row.chat; } catch { /* línea incompleta */ } }
  return chat || '…';
}
export function createApprovalInbox({ root = join(process.cwd(), 'data', 'bandeja'), now = () => Date.now(), uid = typeof process.getuid === 'function' ? process.getuid() : null, memoryDb = null } = {}) {
  const pendingDir = join(root, 'pendientes'), decisionsDir = join(root, 'decisiones'), doneDir = join(root, 'hechos');
  const pendingPath = id => join(pendingDir, `${fileId(id)}.json`), decisionPath = id => join(decisionsDir, `${fileId(id)}.json`);
  const fresh = async () => { for (const dir of [pendingDir, decisionsDir, doneDir]) await mkdir(dir, { recursive: true, mode: 0o700 }); };
  return {
    async create(job, borradorSugerido = '') {
      await fresh();
      const jobId = job.wamid;
      if (!safeId(jobId)) throw new Error('INVALID_JOB_ID');
      const mensaje = neutralize(job.message, 2000);
      const draft = neutralize(borradorSugerido, 2000);
      const accion = job.accionPropuesta ?? buildAction(mensaje, job.context ?? null, job.chatSummary ?? '');
      const pending = { jobId, canal: job.channel, rol: job.role, clase: job.category ?? null,
        telefonoEnmascarado: (job.phone ?? job.telefono) ? masked(job.phone ?? job.telefono) : await originOf(root, jobId), mensaje, borradorSugerido: draft,
        accionPropuesta: accion, riesgo: accion.riesgo,
        tipoSugerencia: draft.trim().toUpperCase() === 'IGNORAR' ? 'descartar' : 'respuesta',
        comandoSugerido: accion.comando ?? (draft.match(/COMANDO:\s*(.*)/i)?.[1] ?? '').slice(0, 2000),
        creado: new Date(now()).toISOString(), huella: digest(jobId, mensaje, draft, accion, accion.riesgo) };
      await atomicJson(pendingPath(jobId), pending);
      return pending;
    },
    async awaitDecision(jobId, signal, pollMs = 500) {
      const path = pendingPath(jobId);
      while (!signal?.aborted) {
        let pending;
        try {
          pending = JSON.parse(await readFile(path, 'utf8'));
          const pstat = await stat(path);
          if ((pstat.mode & 0o777) !== 0o600 || (uid !== null && pstat.uid !== uid)) return { action: 'defer', invalid: true, pending };
        } catch { return { action: 'defer', expired: true }; }
        if (now() - Date.parse(pending.creado) > 24 * 60 * 60 * 1000) return { action: 'defer', expired: true, pending };
        try {
          const decision = JSON.parse(await readFile(decisionPath(jobId), 'utf8'));
          const info = await stat(decisionPath(jobId));
          if ((info.mode & 0o777) !== 0o600 || (uid !== null && info.uid !== uid) || decision.jobId !== jobId ||
            decision.huella !== pending.huella || !['ENVIO', 'IGNORAR', 'POSPONER', 'EJECUTAR'].includes(decision.accion) ||
            decision.aprobadoPor !== 'chat' || (decision.accion === 'EJECUTAR' && decision.confirmar !== 'SI')) continue;
          if (decision.accion === 'IGNORAR') return { action: 'dismiss', pending, decision };
          if (decision.accion === 'POSPONER') return { action: 'defer', pending, decision };
          if (decision.accion === 'EJECUTAR') {
            const reply = neutralize(decision.texto, 2001);
            if (!reply.trim() || reply.length > 2000) continue;
            if (!pending.accionPropuesta?.comando || pending.accionPropuesta.faltan?.length || decision.texto !== pending.accionPropuesta.comando) continue;
            return { action: 'execute', reply: reply.trim(), command: decision.texto, pending, decision, accionPropuesta: pending.accionPropuesta, riesgo: pending.riesgo };
          }
          const reply = decision.texto === undefined ? stripOperatorLines(pending.borradorSugerido) : neutralize(decision.texto, 2001);
          if (pending.tipoSugerencia === 'descartar' && decision.texto === undefined) continue;
          if (!reply.trim() || reply.length > 2000 || /https?:\/\/\S+/gi.test(reply) && [...reply.matchAll(/https?:\/\/\S+/gi)].length > 1) continue;
          return { action: 'send', reply: reply.trim(), pending, decision };
        } catch { /* Wait until a complete decision file is available. */ }
        await new Promise(resolve => {
          const timer = setTimeout(resolve, pollMs);
          signal?.addEventListener('abort', () => { clearTimeout(timer); resolve(); }, { once: true });
        });
      }
      return { action: 'defer' };
    },
    async resolve(jobId, pending, decision, result) {
      await fresh();
      if (result === 'completed' && pending && ['ENVIO', 'EJECUTAR'].includes(decision?.accion)) {
        const reply = decision.texto === undefined ? pending.borradorSugerido : neutralize(decision.texto, 2000);
        if (memoryDb) await recordLearning({ message: pending.mensaje, suggested: pending.borradorSugerido, reply, memoryDb });
        else await recordLearning({ message: pending.mensaje, suggested: pending.borradorSugerido, reply });
      }
      const summary = { jobId, resultado: result, resuelto: new Date(now()).toISOString() };
      for (const [kind, source] of [['pendiente', pendingPath(jobId)], ['decision', decisionPath(jobId)]]) {
        try {
          const content = kind === 'pendiente' ? pending : decision ?? JSON.parse(await readFile(source, 'utf8'));
          const target = join(doneDir, `${fileId(jobId)}.${kind}.json`);
          await atomicJson(target, { ...content, ...summary });
          await unlink(source).catch(() => {});
        } catch { /* A decision may not exist when the lease is lost. */ }
      }
      await writeFile(join(root, 'registro.log'), `${summary.resuelto} ${jobId} ${pending?.telefonoEnmascarado ?? '…'} ${result}\n`, { mode: 0o600, flag: 'a' });
      await chmod(join(root, 'registro.log'), 0o600);
    },
    async list() {
      await fresh();
      const files = await readdir(pendingDir);
      const pending = await Promise.all(files.filter(f => f.endsWith('.json')).map(async f => JSON.parse(await readFile(join(pendingDir, f), 'utf8'))));
      return [...pending, ...(memoryDb?.listarReglas?.('propuesta') ?? []).map(rule => ({ tipo: 'regla-propuesta', ...rule, texto: anonymize(rule.texto) }))];
    },
    dirs: { pendingDir, decisionsDir, doneDir },
  };
}

export async function writeInboxDecision({ root = join(process.cwd(), 'data', 'bandeja'), jobId, accion, texto, confirmar }) {
  const inbox = createApprovalInbox({ root });
  if (!safeId(jobId)) throw new Error('INVALID_JOB_ID');
  const path = join(inbox.dirs.pendingDir, `${fileId(jobId)}.json`);
  const pending = JSON.parse(await readFile(path, 'utf8'));
  const pstat = await stat(path);
  if ((pstat.mode & 0o777) !== 0o600 || (typeof process.getuid === 'function' && pstat.uid !== process.getuid())) throw new Error('INVALID_PENDING_PERMISSIONS');
  if (pending.jobId !== jobId) throw new Error('INVALID_JOB_ID');
  if (Date.now() - Date.parse(pending.creado) > 24 * 60 * 60 * 1000) throw new Error('PENDING_EXPIRED');
  if (pending.huella !== digest(jobId, pending.mensaje, pending.borradorSugerido, pending.accionPropuesta ?? null, pending.riesgo ?? '')) throw new Error('INVALID_FINGERPRINT');
  if (!['ENVIO', 'IGNORAR', 'POSPONER', 'EJECUTAR'].includes(accion)) throw new Error('INVALID_ACTION');
  if (accion === 'EJECUTAR' && confirmar !== 'SI') throw new Error('EXECUTE_REQUIRES_SI');
  if (accion === 'EJECUTAR' && (!pending.accionPropuesta?.comando || pending.accionPropuesta.faltan?.length)) throw new Error('NO_EXECUTABLE_PROPOSAL');
  if (accion === 'ENVIO') {
    if (pending.tipoSugerencia === 'descartar' && texto === undefined) throw new Error('TEXT_REQUIRED_FOR_IGNORE_SUGGESTION');
    const finalText = texto === undefined ? pending.borradorSugerido : neutralize(texto, 2001);
    if (!finalText.trim() || finalText.length > 2000 || [...finalText.matchAll(/https?:\/\/\S+/gi)].length > 1) throw new Error('INVALID_TEXT');
    texto = finalText.trim();
  }
  if (accion === 'EJECUTAR' && (!texto?.trim() || texto.length > 2000)) throw new Error('INVALID_EXECUTE_TEXT');
  if (accion === 'EJECUTAR') {
    const command = neutralize(texto, 2001);
    if (!command.trim() || command.length > 2000 || [...command.matchAll(/https?:\/\/\S+/gi)].length > 1) throw new Error('INVALID_EXECUTE_TEXT');
    texto = command.trim();
    if (!pending.accionPropuesta?.comando || pending.accionPropuesta.faltan?.length || texto !== pending.accionPropuesta.comando) throw new Error('COMMAND_DOES_NOT_MATCH_PROPOSAL');
  }
  await atomicJson(join(inbox.dirs.decisionsDir, `${fileId(jobId)}.json`), { jobId, huella: pending.huella, accion, ...(texto !== undefined ? { texto: neutralize(texto, 2000).trim() } : {}), ...(confirmar ? { confirmar } : {}), aprobadoPor: 'chat' });
}
