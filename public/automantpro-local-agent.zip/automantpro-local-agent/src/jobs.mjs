import { execFile as nodeExecFile } from 'node:child_process';
import { promisify } from 'node:util';
import { stat } from 'node:fs/promises';
import { isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AgentError } from './client.mjs';
import { inspectUserText } from './guard.mjs';
import { classifyMessage } from './vendor/pymeagents/automantpro/agent.mjs';

export const JOB_TYPES = Object.freeze(['responder_consulta', 'clasificar_mensaje', 'enviar_aviso_whatsapp', 'correr_pruebas', 'tomar_capturas', 'revisar_diff', 'reporte_estado']);
const TYPE_SET = new Set(JOB_TYPES);
const CAPTURES_SCRIPT = fileURLToPath(new URL('./scripts/capturas.mjs', import.meta.url));
export const DEV_COMMANDS = Object.freeze({
  correr_pruebas: Object.freeze(['npm', Object.freeze(['test'])]),
  revisar_diff: Object.freeze(['git', Object.freeze(['diff', '--stat'])]),
  tomar_capturas: Object.freeze(['node', Object.freeze([CAPTURES_SCRIPT])]),
});
const execFile = promisify(nodeExecFile);

export function resolveJobType(job) {
  if (job && typeof job === 'object' && typeof job.wamid === 'string' && !Object.hasOwn(job, 'type')) return 'responder_consulta';
  const type = job?.type;
  if (typeof type !== 'string' || ['__proto__', 'constructor'].includes(type) || !TYPE_SET.has(type)) throw new AgentError('JOB_TYPE_NOT_ALLOWED');
  return type;
}

function cleanOutput(value) {
  return String(value || '').replace(/[\x00-\x08\x0b-\x1f\x7f-\x9f]/g, '').slice(-4000);
}
// Child commands never receive the broker token.
function childEnv(env) {
  const merged = { ...process.env, ...env };
  delete merged.LOCAL_AGENT_TOKEN;
  return merged;
}
async function runDev(type, ctx) {
  const repo = ctx?.env?.LOCAL_AGENT_REPO_DIR;
  if (ctx?.env?.LOCAL_AGENT_DEV_JOBS !== 'true' || typeof repo !== 'string' || !isAbsolute(repo)) throw new AgentError('DEV_JOBS_DISABLED');
  try { if (!(await stat(repo)).isDirectory()) throw new Error('not directory'); } catch { throw new AgentError('DEV_JOBS_DISABLED'); }
  const [command, args] = DEV_COMMANDS[type];
  const run = ctx.execFile || execFile;
  try {
    const result = await run(command, [...args], { cwd: resolve(repo), timeout: 10 * 60 * 1000, maxBuffer: 1024 * 1024, windowsHide: true, env: childEnv(ctx.env) });
    return { type, code: 0, stdout: cleanOutput(result?.stdout), stderr: cleanOutput(result?.stderr) };
  } catch (error) {
    return { type, code: Number.isInteger(error?.code) ? error.code : 1, stdout: cleanOutput(error?.stdout), stderr: cleanOutput(error?.stderr) };
  }
}

export async function runJob(job, ctx = {}) {
  const type = resolveJobType(job);
  switch (type) {
    case 'responder_consulta': {
      const guarded = inspectUserText(job.message);
      if (!guarded.safe) return { type, suggestion: null, flags: guarded.flags };
      const classified = classifyMessage(guarded.text);
      return { type, suggestion: classified.draft, intent: classified.intent };
    }
    case 'clasificar_mensaje': {
      const guarded = inspectUserText(job.message ?? job.text);
      const classified = classifyMessage(guarded.text);
      return { intent: classified.intent, flags: guarded.flags };
    }
    case 'enviar_aviso_whatsapp': return { delivered: false, reason: 'SERVER_OUTBOX_ONLY' };
    case 'correr_pruebas': case 'tomar_capturas': case 'revisar_diff': return runDev(type, ctx);
    case 'reporte_estado': {
      const status = await ctx.client.ping();
      return { ok: status.ok, whatsappDelivery: status.whatsappDelivery, node: process.versions.node, jobTypes: JOB_TYPES };
    }
    default: throw new AgentError('JOB_TYPE_NOT_ALLOWED');
  }
}
